package igaedrewriter;

import org.semanticweb.owlapi.model.OWLOntology;
import igaedrewriter.fol.*;
import igaedrewriter.fol.PredicateAtom.PredicateArityException;
import igaedrewriter.fol.Term.TermTypeException;
import igaedrewriter.fol.OntologyPredicateAtom;
import igaedrewriter.policy.OntologyConjunctiveQuery;

import java.net.URISyntaxException;
import java.util.*;

public class AtomRewriter {
    private final OWLOntology ontology;
    private final Set<String> reservedVarNames;

    public AtomRewriter(OWLOntology ontology, Set<String> reservedVarNames) {
        this.ontology = ontology;
        this.reservedVarNames = reservedVarNames;
    }

    public AtomRewriter(OWLOntology ontology) {
        this.ontology = ontology;
        this.reservedVarNames = new HashSet<>();
    }

    public Formula rewrite(Formula formula) throws AtomRewriterException, URISyntaxException, PredicateArityException, TermTypeException {
        return recursiveRewrite(formula.clone());
    }

    private Formula recursiveRewrite(Formula formula) throws AtomRewriterException, URISyntaxException, PredicateArityException, TermTypeException {
        if (formula instanceof ManyFormulasContainer) {
            ManyFormulasContainer newFormula = (ManyFormulasContainer) formula.clone();
            newFormula.clear();
            for (Formula subFormula : ((ManyFormulasContainer) formula).getFormulas()) {
                newFormula.add(recursiveRewrite(subFormula));
            }
            return newFormula;
        } else if (formula instanceof OntologyPredicateAtom) {
            return rewriteAtom((OntologyPredicateAtom) formula);
        } else if (formula instanceof SingleFormulaContainer) {
            SingleFormulaContainer newFormula = (SingleFormulaContainer) formula.clone();
            Formula content = newFormula.getContent();
            newFormula.setContent(recursiveRewrite(content));
            return newFormula;
        } else if (formula instanceof PredicateAtom) {
            throw new AtomRewriterException("AtomRewrite is an algorithm for ontologies! Please use OntologyPredicateAtom instead of PredicateAtom.");
        } else return formula;
    }

    /** ???
     * This method computes the expansion of an atom.
     * @param atom The atom to be expanded.
     * @return a {@link Disjunction disjunction} of {@link PredicateAtom predicate atoms}.
     */
    private Disjunction rewriteAtom(OntologyPredicateAtom atom) throws URISyntaxException, PredicateArityException, TermTypeException, AtomRewriterException {
        if (atom.getPredicateIRI().equals("http://www.w3.org/2002/07/owl#Thing")) {
            return new Disjunction(atom);	// it is useless to rewrite the TOP concept, and the function rewriteAtom(OntologyPredicateAtom,ITBox) does not support it
        }
        Disjunction res = new Disjunction();

        Collection<OntologyPredicateAtom> collection = new HashSet<>();
        collection.add(atom);
        OntologyConjunctiveQuery ocq = new OntologyConjunctiveQuery(collection, atom.getVariables());
        String sparql = ocq.toSparql();
        Set<OntologyConjunctiveQuery> rewritings = TreeWitnessClient.rewriteQuery(sparql, ontology, true);

        for (OntologyConjunctiveQuery rewriting : rewritings){
            rewriting.explicitNondistinguishedNonsharedVariables(null, reservedVarNames);
            OntologyPredicateAtom a = rewriting.getAllPredicateAtoms().iterator().next();
            ArrayList<Variable> newFreeVars = rewriting.getQuantifiedVariables();
            Formula formula = !newFreeVars.isEmpty() ? new Exist(a, newFreeVars) : a;
            res.add(formula);
        }
        return res;
    }

    public static class AtomRewriterException extends Exception {
        public AtomRewriterException() {
            super();
        }
        public AtomRewriterException(String s) {
            super(s);
        }
    }
}
