package igaedrewriter;

import org.ini4j.Ini;
import org.ini4j.IniPreferences;
import igaedrewriter.util.Utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.prefs.Preferences;

public class Configuration {
	public String inputPath;
	public String policyFilename;
	public String ontologyFilename;
	public String ontologyIRI;
	public String queryFilename;

	//Sql
	public String dbUser;
	public String dbPassword;
	public String dbName;
	public String dbPortNumber;
	public String jdbcDriver;
	public String jdbcConnectionOptions;
	
	public String viewNameSuffix = "";
	public String columnNamePrefix = "obj";
	public String columnAliasPrefix = "X";

	public final String defaultJdbcDriver = "com.mysql.cj.jdbc.Driver";

	public boolean storeLogs;

	private String defaultJdbcDriver() {
		Logger.info("Setting default JDBC driver: " + defaultJdbcDriver);
		return defaultJdbcDriver;
	}
	
	/**
	 * This method tries to initialize the local fields from a configuration file.
	 * @param configFilePath The path of the configuration file.
	 */
	public Configuration(String configFilePath) throws IOException {
		File f = new File(configFilePath);
		if (!f.exists() || !f.isFile()) {
			throw new FileNotFoundException("Configuration file '" + configFilePath + "' not found");
		}
		
		Ini ini = new Ini(f);
		java.util.prefs.Preferences prefs = new IniPreferences(ini);
		
		Preferences dbPrefs = prefs.node("db-settings");	// header [db-settings]
		dbUser = dbPrefs.get("dbUser", null);
		dbPassword = dbPrefs.get("dbPassword", null);
		dbName = dbPrefs.get("dbName", null);
		dbPortNumber = dbPrefs.get("dbPortNumber", "3306");
		jdbcDriver = dbPrefs.get("jdbcDriver", defaultJdbcDriver());
		jdbcConnectionOptions = dbPrefs.get("jdbcConnectionOptions", null);
		
		Preferences ioPrefs = prefs.node("io-settings");	// header [io-settings]
		inputPath = Utils.appendSlashIfMissing(ioPrefs.get("resourcesPath", null));
		ontologyFilename = ioPrefs.get("ontologyFilename", null);
		ontologyIRI = ioPrefs.get("ontologyIRI", null);
		policyFilename = ioPrefs.get("policyFilename", null);
		queryFilename = ioPrefs.get("testQueryFilename", null);

		Preferences namingPrefs = prefs.node("naming");		// header [naming]
		viewNameSuffix = namingPrefs.get("viewNameSuffix", viewNameSuffix);
		columnNamePrefix = namingPrefs.get("columnNamePrefix", columnNamePrefix);
		columnAliasPrefix = namingPrefs.get("columnAliasPrefix", columnAliasPrefix);
	}
	
	@Override
	public String toString() {
		return
				"inputPath: " + inputPath +
				"\npolicyFilename: " + policyFilename +
				"\nqueryFilename: " + queryFilename +
				"\nontologyFilename: " + ontologyFilename +
				"\nontologyIRI: " + ontologyIRI +
				"\ndbUser: " + dbUser +
				"\ndbPassword: " + dbPassword +
				"\ndbName: " + dbName +
				"\ndbPortNumber: " + dbPortNumber +
				"\njdbcDriver: " + jdbcDriver +
				"\njdbcConnectionOptions: " + jdbcConnectionOptions +
				"\nviewNameSuffix: " + viewNameSuffix +
				"\ncolumnNamePrefix: " + columnNamePrefix +
				"\ncolumnAliasPrefix: " + columnAliasPrefix;
	}
	
	public String getViewName(String predicateName) {
		return predicateName + viewNameSuffix;
	}
	
	public String prependInputPath(String fileName) {
		return Utils.appendSlashIfMissing(inputPath) + fileName;
	}
}
