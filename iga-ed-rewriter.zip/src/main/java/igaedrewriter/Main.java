package igaedrewriter;

import org.semanticweb.owlapi.model.*;
import org.jetbrains.annotations.NotNull;
import org.xml.sax.SAXException;
import igaedrewriter.fol.PredicateAtom;
import igaedrewriter.fol.Term;
import igaedrewriter.parser.ParserException;
import igaedrewriter.db.SQLCompiler;

import java.io.*;
import java.net.URISyntaxException;
import java.sql.SQLException;

public class Main {
	
	public static void main(@NotNull String[] args) throws IOException, OWLOntologyCreationException, URISyntaxException, IllegalAccessException, SQLException, SAXException, ClassNotFoundException, ParserException, PredicateAtom.PredicateArityException, Term.TermTypeException, SQLCompiler.SQLificationException, OWLOntologyStorageException, AtomRewriter.AtomRewriterException {
		// Print help message
		if (args.length > 0 && (args[0].equals("-h") || args[0].equals("--help"))) {
			printHelpMessageAndExit();
		}
		
		// Default values for command-line arguments
		String CONFIG_FILENAME = "config.ini";
		boolean STORE_LOG = true;
		
		// Read command-line arguments
		for (String arg : args) {
			if (arg.startsWith("-sl:")) STORE_LOG = !arg.substring(4).equalsIgnoreCase("false");
			else if (arg.startsWith("-c:")) CONFIG_FILENAME = arg.substring(3);
			else if (arg.equals("-h") || arg.equals("--help")) printHelpMessage();
		}
		
		// Import configurations
		Configuration config = new Configuration(CONFIG_FILENAME);
		
		if (STORE_LOG) Logger.setLogPath(config.inputPath);
		Logger.setLogLevel(Logger.INFO);
		
		QueryChecker qc = new QueryChecker(config);
		String rewriting = qc.igaEntails();
		
		qc.sqlExecution(rewriting);
		
		Logger.info("Done");
	}
	
	public static void printHelpMessage() {
		System.out.println("Please call this program as follows:" +
				"\n\tjava -jar igaedrewriter.jar [-c:CONFIG_FILE_NAME] [-sl:STORE_LOG]" +
				"\nwhere:" +
				"\n- CONFIG_FILE_NAME is the name (or full path) of the configuration file (default: \"./config.ini\")" +
				"\n- STORE_LOG can be \"true\" or \"false\" (default is true)"
		);
	}
	
	public static void printHelpMessageAndExit() {
		printHelpMessage();
		System.exit(1);
	}
}