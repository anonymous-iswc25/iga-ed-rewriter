package igaedrewriter;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import igaedrewriter.db.DBSchema;
import igaedrewriter.db.SQLCompiler;
import igaedrewriter.db.SQLConnection;
import igaedrewriter.db.Table;
import igaedrewriter.fol.*;
import igaedrewriter.parser.BCQParser;
import igaedrewriter.parser.DatalogBCQParser;
import igaedrewriter.parser.ParserException;
import igaedrewriter.policy.DependencyGraph;
import igaedrewriter.policy.EpistemicDependency;
import igaedrewriter.policy.OntologyConjunctiveQuery;
import igaedrewriter.util.OntologyUtils;
import igaedrewriter.util.Utils;

import java.sql.*;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static igaedrewriter.fol.MostGeneralUnifier.findMGU;
import static igaedrewriter.policy.EpistemicDependency.IND_AUX_PRED_NAME;
import static igaedrewriter.util.IOUtils.loadJsonArrayAsStringList;
import static igaedrewriter.util.OntologyUtils.loadOntology;

public class QueryChecker {
    private static String ONTOLOGY_IRI;
    Configuration configuration;
    String queryFilePath;
    OWLOntology tbox;
    ArrayList<EpistemicDependency> expandedPolicy;
    ArrayList<ArrayList<OntologyPredicateAtom>> orderedBodies;
    ArrayList<Map<String, Integer>> occurenciesInBodies;
    ArrayList<ArrayList<String>> predicateOrderInBodies;
    boolean OPTIMIZED = true;
    Integer relevantPaddings; //Just for logging

    public QueryChecker(Configuration config) throws OWLOntologyCreationException, ParserException, Term.TermTypeException, IOException, URISyntaxException, PredicateAtom.PredicateArityException {
        this.relevantPaddings = 0;
        this.configuration = config;
        this.ONTOLOGY_IRI = config.ontologyIRI;
        this.queryFilePath = config.prependInputPath(config.queryFilename);
        
        //Compute expanded policy
        Set<EpistemicDependency> policy = loadEDPolicyFromJson(config.prependInputPath(config.policyFilename), config.prependInputPath(config.ontologyFilename));
        OWLOntology tempTbox = loadOntology(config.prependInputPath(config.ontologyFilename));
        OntologyUtils.prepareTBox(tempTbox);
        if (!isFullPolicy(policy)) {
            throw new IOException("The policy must be full. Please ensure that all the variables " +
                    "used in the head of the epistemic dependencies also occur among the frontier variables " +
                    "(i.e. the universally quantified variables shared between the body and the head)." +
                    "For example: if the ED's head is 'Q(x) :- myPredicate(y) .', then the ED is not full.");
        }
        boolean linear = true; //Just for logging
        if (isLinearPolicy(policy)) {
            this.expandedPolicy = expandLinearPolicy(policy, tempTbox);
        }
        else if (isAcyclicPolicy(policy, tempTbox)) {
            this.expandedPolicy = expandAcyclicPolicy(policy, tempTbox);
            linear = false;
        }
        else{
            throw new IOException("Policy must be linear or acyclic.");
        }
        this.tbox = loadOntology(config.prependInputPath(config.ontologyFilename));
        OntologyUtils.prepareTBox(tbox);

        //Store some useful objects
        orderedBodies = new ArrayList<>();
        occurenciesInBodies = new ArrayList<>();
        predicateOrderInBodies = new ArrayList<>();
        for (EpistemicDependency ed : expandedPolicy){
            OntologyConjunctiveQuery renamedBody1 = ed.getBody().changeQuantifiedVariablesNames("quantifiedBT"); //Preserves the notion of quantification needed for the mappings
            OntologyConjunctiveQuery renamedBody2 = renamedBody1.changeFreeVariablesNames("freeBT"); //Avoids casual matchings during mapping computation
            ArrayList<OntologyPredicateAtom> orderedBody = new ArrayList<>();
            orderedBody.addAll(renamedBody2.getAllPredicateAtoms());
            orderedBody.sort(Comparator.comparing(OntologyPredicateAtom::getPredicateIRI));
            Map<String, Integer> occurenciesInBody = new HashMap<>();
            ArrayList<String> predOrdInBody = new ArrayList<>();
            predOrdInBody.add(orderedBody.get(0).getPredicateIRI()); //The first is pre-inserted to prevent index out of range inside the loop
            for (OntologyPredicateAtom opa : orderedBody){
                String iri = opa.getPredicateIRI();
                if (!predOrdInBody.get(predOrdInBody.size()-1).equals(iri)) predOrdInBody.add(iri);
                if(occurenciesInBody.containsKey(iri)){
                    Integer tmp = occurenciesInBody.get(iri);
                    occurenciesInBody.replace(iri, tmp+1);
                }
                else{
                    occurenciesInBody.put(iri, 1);
                }
            }
            orderedBodies.add(orderedBody);
            occurenciesInBodies.add(occurenciesInBody);
            predicateOrderInBodies.add(predOrdInBody);
        }

        //Just some prints
        File file = new File(queryFilePath);
        Scanner myReader = new Scanner(file);
        StringBuilder data = new StringBuilder();
        while (myReader.hasNextLine()) data.append(myReader.nextLine());
        Logger.info("DATABASE: " + config.dbName);
        Logger.info("QUERY FILE: " + file.getAbsolutePath());
        Logger.info("QUERY");
        Logger.info(data.toString());
        File policyFile = new File(config.prependInputPath(config.policyFilename));
        Logger.info("POLICY FILE: " + policyFile.getAbsolutePath());
        File tboxFile = new File(config.prependInputPath(config.ontologyFilename));
        Logger.info("TBOX POLICY FILE: " + tboxFile.getAbsolutePath());
        /*Logger.info("TBOX:");
        for (OWLAxiom axiom : tbox.getAxioms()) Logger.info(axiom.toString());*/

        if (linear) {
            Logger.info("INPUT POLICY SIZE: " + policy.size() + " (LINEAR)");
        }
        else{
            Logger.info("INPUT POLICY SIZE: " + policy.size() + " (ACYCLIC)");
        }
        Logger.info("EXPANDED POLICY SIZE: " + expandedPolicy.size());
    }

    //GETTER (for logging)

    public Integer getRelevantPaddings() {
        return relevantPaddings;
    }

    //POLICY DISAMBIGUATION

    public static Set<EpistemicDependency> loadEDPolicyFromJson(String policyFilePath, String ontologyFilePath) throws IOException, ParserException, Term.TermTypeException, OWLOntologyCreationException {
        OWLOntology ontology = loadOntology(ontologyFilePath);
        BCQParser policyParser = new DatalogBCQParser(ontology);
        Set<EpistemicDependency> policySet = new HashSet<>();
        ObjectMapper objectMapper = new ObjectMapper();
        for (String s : loadJsonArrayAsStringList(policyFilePath)) {
            Map<String, String> map = objectMapper.readValue(s, Map.class);
            OntologyConjunctiveQuery head = policyParser.OntologyConjunctiveQuery(map.get("head"));
            OntologyConjunctiveQuery body = policyParser.OntologyConjunctiveQuery(map.get("body"));
            EpistemicDependency ed = new EpistemicDependency(body, head, body.getFreeVariables()); //UQVs are read from the body, but could also be read from the head
            policySet.add(ed);
        }
        return policySet;
    }

    private boolean isAcyclicPolicy(Set<EpistemicDependency> policy, OWLOntology tbox) throws IOException {
        DependencyGraph dg = new DependencyGraph(policy, tbox);
        return dg.isPolicyAcyclic();
    }
    
    private boolean isLinearPolicy(Set<EpistemicDependency> policy) {
        for (EpistemicDependency ed : policy){
            if(!ed.isLinear() && !ed.isDenial()) return false;
        }
        return true;
    }
    
    private boolean isFullPolicy(Set<EpistemicDependency> policy) {
        for (EpistemicDependency ed : policy){
            if(!ed.isFull()) return false;
        }
        return true;
    }

    //POLICY EXPANSION

    private ArrayList<EpistemicDependency> expandLinearPolicy(Set<EpistemicDependency> policy, OWLOntology ontology) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        Logger.info("LINEAR EXPANSION");
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        Set<EpistemicDependency> tgdPolicySet = new HashSet<>();
        for (EpistemicDependency ed : policy){
            tgdPolicySet.add(ed.createCorrespondingTGD(ONTOLOGY_IRI));
            if(!ed.isDenial()) manager.addAxiom(ontology, ed.toOWLAxiom());
        }
        Set<EpistemicDependency> ClosedPolicySet = rewriteEDPolicyWrtTbox(tgdPolicySet, ontology);
        ArrayList<EpistemicDependency> ClosedPolicySetWithoutInd = new ArrayList<>();
        for (EpistemicDependency ed : ClosedPolicySet){
            ClosedPolicySetWithoutInd.add(ed.removePredicateFromBody(IND_AUX_PRED_NAME));
        }
        return ClosedPolicySetWithoutInd;
    }

    private ArrayList<EpistemicDependency> expandAcyclicPolicy(Set<EpistemicDependency> policy, OWLOntology ontology) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        Logger.info("ACYCLIC EXPANSION");
        //First expansion: Expand P wrt T, get P'
        Set<EpistemicDependency> tgdPolicySet = new HashSet<>();
        for (EpistemicDependency ed : policy) tgdPolicySet.add(ed.createCorrespondingTGD(ONTOLOGY_IRI));
        Set<EpistemicDependency> intermediatePolicySet = rewriteEDPolicyWrtTbox(tgdPolicySet, ontology);
        Set<EpistemicDependency> intermediatePolicySetWithoutInd = new HashSet<>();
        for (EpistemicDependency ed : intermediatePolicySet){
            intermediatePolicySetWithoutInd.add(ed.removePredicateFromBody(IND_AUX_PRED_NAME));
        }
        //Second expansion: Expand P' wrt P', get P''
        return rewriteEDPolicyWrtItself(intermediatePolicySetWithoutInd);
    }

    public static Set<EpistemicDependency> rewriteEDPolicyWrtTbox(Set<EpistemicDependency> policy, OWLOntology ontology) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        Set<EpistemicDependency> extendedPolicySet = new HashSet<>();
        for (EpistemicDependency ed : policy) {
            String sparql = ed.getBody().toSparql();
            Set<OntologyConjunctiveQuery> reformulatedQueries = TreeWitnessClient.rewriteQuery(sparql, ontology);
            for (OntologyConjunctiveQuery inferredCQ : reformulatedQueries) {
                inferredCQ.explicitNondistinguishedNonsharedVariables();
                ArrayList<Variable> uqv = ed.getHead().getFreeVariables(); //The free variables are read from the head because those of the rewriting could have been renamed
                OntologyConjunctiveQuery newBody = inferredCQ.changeFreeVariablesNames(uqv);
                extendedPolicySet.add(new EpistemicDependency(newBody, ed.getHead(), uqv));
            }
        }
        return extendedPolicySet;
    }

    private ArrayList<EpistemicDependency> rewriteEDPolicyWrtItself(Set<EpistemicDependency> policy) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        ArrayList<EpistemicDependency> res = new ArrayList<>(policy);
        int oldsize = res.size();
        int newsize = oldsize+1;
        while(newsize > oldsize){
            res = expansionRound(res);
            oldsize = newsize;
            newsize = res.size();
        }
        return res;
    }

    private ArrayList<EpistemicDependency> expansionRound(ArrayList<EpistemicDependency> policy) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        ArrayList<EpistemicDependency> res = new ArrayList<>(policy);
        for (EpistemicDependency ed1Original : policy){
            if (ed1Original.isDenial()) continue;
            for (EpistemicDependency ed2Original : policy){
                //Renaming to prevent undesired matchings
                EpistemicDependency ed1 = ed1Original.changeAllVariablesNames("ed1");
                EpistemicDependency ed2 = ed2Original.changeAllVariablesNames("ed2");
                //Prepare the PredicateAtoms for attempting a macthing
                Set<OntologyPredicateAtom> paSet2 = ed2.getBody().getOntologyPredicateAtoms();
                PredicateAtom head1 = ed1.getHead().getPredicateAtoms().iterator().next();
                head1.unbindVariables();
                for (OntologyPredicateAtom pa2 : paSet2){
                    //Look for a substitution that unifies a predicate atom of ed2 with the head of ed1
                    pa2.unbindVariables();
                    PredicateAtom[] arg = new PredicateAtom[2];
                    arg[0] = head1;
                    arg[1] = pa2;
                    Substitution mgu = findMGU(arg);
                    if (mgu != null){
                        //Apply the unificator to both eds, so that variables are unified in body, head and UQVs
                        EpistemicDependency ed1s = mgu.applyToED(ed1);
                        EpistemicDependency ed2s = mgu.applyToED(ed2);
                        OntologyPredicateAtom pa2s = mgu.applyToOntologyPredicateAtom(pa2);
                        //Create the new ED -- newBody
                        Set<OntologyPredicateAtom> newBodyAtomsTemp = ed2s.getBody().getOntologyPredicateAtoms();
                        Set<OntologyPredicateAtom> newBodyAtoms = new HashSet<>();
                        //The copy is necessary for HashSet.remove to work
                        for (OntologyPredicateAtom opa : newBodyAtomsTemp) {
                            opa.unbindVariables();
                            if(!opa.equals(pa2s)) newBodyAtoms.add(opa);
                        }
                        Set<OntologyPredicateAtom> temp = ed1s.getBody().getOntologyPredicateAtoms();
                        for(OntologyPredicateAtom opa : temp) opa.unbindVariables();
                        newBodyAtoms.addAll(temp);
                        //newHead
                        Set<OntologyPredicateAtom> newHeadAtoms = ed2s.getHead().getOntologyPredicateAtoms();
                        for(OntologyPredicateAtom opa : newHeadAtoms) opa.unbindVariables();
                        //newUQV
                        ArrayList<Variable> newUQV = ed2s.getUniversallyQuantifiedVariables();
                        newUQV.addAll(ed1s.getUniversallyQuantifiedVariables());
                        HashSet<Variable> tempSet = new HashSet<>(newUQV);
                        newUQV = new ArrayList<>(tempSet);

                        OntologyConjunctiveQuery newBody = new OntologyConjunctiveQuery(newBodyAtoms, newUQV);
                        //Manage denials
                        OntologyConjunctiveQuery newHead;
                        if (newHeadAtoms.isEmpty()) {
                            newHead = new OntologyConjunctiveQuery(new HashSet<>(Arrays.asList(new False())), newUQV);
                        }
                        else{
                            newHead = new OntologyConjunctiveQuery(newHeadAtoms, newUQV);
                        }

                        EpistemicDependency newEDOriginal = new EpistemicDependency(newBody, newHead, newUQV);
                        EpistemicDependency newED = newEDOriginal.changeAllVariablesNames(null); //restore nice names
                        if (!containsED(res, newED)) res.add(newED);
                    }
                }
            }
        }
        return res;
    }

    //Set containment using ED.isEquivalent instead of equals
    private boolean containsED(ArrayList<EpistemicDependency> policy, EpistemicDependency ed) {
        for (EpistemicDependency p : policy){
            if (p.isEquivalentTo(ed)) return true;
        }
        return false;
    }

    //CORE METHODS

    public String igaEntails() throws IOException, ParserException, Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException, SQLCompiler.SQLificationException, AtomRewriter.AtomRewriterException {
        //Compute the rewritings of q
        relevantPaddings = 0; //Logging
        long startRewritngTime = System.nanoTime(); //Logging
        String query = new String(Files.readAllBytes(Paths.get(queryFilePath)));
        Set<OntologyConjunctiveQuery> inputQueryRewritings = TreeWitnessClient.rewriteQuery(query, this.tbox, true);
        Disjunction res = new Disjunction();
        for (OntologyConjunctiveQuery cq : inputQueryRewritings) {
            cq.explicitNondistinguishedNonsharedVariables();
            Conjunction innerConjunction = new Conjunction();
            ArrayList<Variable> existentialVars = cq.getQuantifiedVariables();
            Conjunction qr = cq.getBody();
            innerConjunction.add(qr);
            Set<List<OntologyPredicateAtom>> paddings = computePolicyPaddings(expandedPolicy, cq);
            for (List<OntologyPredicateAtom> pad : paddings) {
                Formula clashOutput = clash(pad, qr);
                if (clashOutput instanceof False) continue;
                relevantPaddings = relevantPaddings + 1;
                Negation clashNegation = new Negation(clashOutput);
                innerConjunction.add(clashNegation);
            }
            if (!existentialVars.isEmpty()) {
                res.add(new Exist((Formula) innerConjunction, existentialVars));
            } else {
                res.add(innerConjunction);
            }
        }

        //Convert query in SQL
        //Initialize schema
        Set<Table> tables = new HashSet<>();
        for (OWLAxiom a : tbox.getAxioms()) {
            if (a instanceof OWLDeclarationAxiom) {
                OWLDeclarationAxiom oda = (OWLDeclarationAxiom) a;
                OWLEntity entity = oda.getEntity();
                if (entity.isOWLClass()) {
                    List<String> attributesNames = new ArrayList<>();
                    attributesNames.add("attr1");
                    tables.add(new Table(entity.getIRI().getShortForm(), attributesNames));
                } else if (entity.isOWLObjectProperty() || entity.isOWLDataProperty()) {
                    List<String> attributesNames = new ArrayList<>();
                    attributesNames.add("attr1");
                    attributesNames.add("attr2");
                    tables.add(new Table(entity.getIRI().getShortForm(), attributesNames));
                }
            }
        }
        DBSchema schema = new DBSchema("dbName", tables); //Any name could be applied here
        //SQL conversion
        Formula f = (Formula) res;
        f.unbindVariables();
        if (OPTIMIZED) {
            f.optimize();
            Logger.info("Optimized FO-rewriting:");
            Logger.info(f.toString());
        }
        else{
            Logger.info("FO-rewriting:");
            Logger.info(f.toString());
        }
        boolean distinct = true;
        String q = new SQLCompiler(schema).sqlify(f, new HashMap<>(), distinct);
        String q1 = cleanConstantsName(q); //Remove http... prefixes
        Logger.info("SQL QUERY:");
        Logger.info(q1);

        //Logging
        long endRewritngTime = System.nanoTime();
        Logger.info("QUERY PROCESSING TIME (Excluded policy expansion): " +
                (endRewritngTime-startRewritngTime)/1_000_000 + " milliseconds");

        return q1;
    }

    public Formula clash(List<OntologyPredicateAtom> padding, Conjunction qr) throws ParserException, Term.TermTypeException,PredicateAtom.PredicateArityException, URISyntaxException, AtomRewriter.AtomRewriterException {
        /*Logger.info("Executing clash with padding: " + zSet.toString());
        Logger.info("and rewriting: " + query.toString());*/
        ArrayList<Variable> yVars = new ArrayList<>();
        for (OntologyPredicateAtom opa : padding){
            for (Variable variable : opa.getVariables()){
                variable.unbind();
                yVars.add(variable);
            }
        }
        Set<String> reservedVarNames = yVars.stream().map(Variable::getName).collect(Collectors.toSet());
        reservedVarNames.addAll(qr.getVariablesNames());
        Conjunction f1 = isDiscl(padding, new Conjunction(), reservedVarNames);
        Conjunction f2 = isDiscl(padding, qr, reservedVarNames);
        if (OPTIMIZED && f1.equals(f2)) return new False();
        if (OPTIMIZED) {
            Set<Formula> f1Formulae = f1.getFormulas();
            for (Formula f : f2.getFormulas()) {
                if (f1Formulae.contains(f)) f2.remove(f);
            }
        }
        Conjunction conjunction = new Conjunction();
        conjunction.add(f1);
        conjunction.add(new Negation(f2));
        //Adding zRewriting
        for (OntologyPredicateAtom opa : padding) {
            AtomRewriter ar = new AtomRewriter(tbox, new HashSet<>(reservedVarNames));
            Formula atomRewriting = ar.rewrite(opa);
            conjunction.add(atomRewriting);
        }
        if (!yVars.isEmpty()) return new Exist(conjunction, yVars);
        else return conjunction;
    }

    public Conjunction isDiscl(List<OntologyPredicateAtom> padding, Conjunction q, Set<String> reservedVarNames) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        Conjunction res = new Conjunction();
        ArrayList<OntologyPredicateAtom> unionSet = new ArrayList<>();
        unionSet.addAll(padding);
        for (Formula formula : q.getFormulas()){
            if(formula instanceof OntologyPredicateAtom) unionSet.add((OntologyPredicateAtom) formula);
        }
        for (int i = 0; i < expandedPolicy.size(); i++){
            EpistemicDependency edTemp = expandedPolicy.get(i);
            EpistemicDependency ed = edTemp.changeFreeVariablesNames("freeBT");
            ArrayList<Substitution> mappings = generateMappings(i, unionSet);
            //Compute paddingTerms for discarding mappings that do not affect them
            Set<Term> paddingTerms = new HashSet<>();
            for (OntologyPredicateAtom opa : padding){
                for (Term t : opa.getTerms()){
                    if (t instanceof Variable){
                        Variable v = (Variable) t;
                        Variable clone = v.clone();
                        clone.unbind();
                        paddingTerms.add(clone);
                    }
                    else{
                        paddingTerms.add(t);
                    }
                }
            }
            for (Substitution mapping : mappings){
                Set<Equality> equalities = getRelevantEqualities(mapping, unionSet);
                //Check if the mapping uses the padding set (the empty padding is preserved)
                Boolean found = true;
                if (!padding.isEmpty()) {
                    found = false;
                    for (Equality e : equalities){
                        if (paddingTerms.contains(e.getRightTerm()) || paddingTerms.contains(e.getLeftTerm())){
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) continue;

                Conjunction equalitiesConjunction = new Conjunction(equalities);
                Disjunction implication = new Disjunction();
                if (!equalitiesConjunction.getFormulas().isEmpty()) implication.add(new Negation(equalitiesConjunction));
                if(!ed.isDenial()) {
                    OntologyConjunctiveQuery headSubstituted = mapping.applyToOntologyConjunctiveQuery(ed.getHead());
                    //Expand head
                    //Note: In our representation the head of the ED may contain unused UQVs variables
                    //The rewriting could delete such variables
                    //Here we prefer it as we don't use the rewritings as heads for new EDs.
                    //But if it will ever be the case, all the variables must be restored.
                    String sparql = headSubstituted.toSparql();
                    Set<OntologyConjunctiveQuery> reformulatedQueries = TreeWitnessClient.rewriteQuery(sparql, tbox);
                    Disjunction inferred = new Disjunction();
                    for (OntologyConjunctiveQuery cq : reformulatedQueries) {
                        cq.explicitNondistinguishedNonsharedVariables(null, new HashSet<>(reservedVarNames));
                        //Coherency with body
                        ArrayList<Variable> uqv = mapping.applyToUQV(ed.getBody().getFreeVariables());
                        OntologyConjunctiveQuery newHead = cq.changeFreeVariablesNames(uqv);
                        inferred.add(newHead.toFormula());
                    }
                    implication.add(inferred);
                }
                res.add(implication);
            }
        }
        return res;
    }

    //SQL EXECUTION

    public int sqlExecution(String sqlQuery) throws SQLConnection.DriverNotFoundException, SQLException, IOException {
        Connection connection = new SQLConnection(configuration).getConnection();
        Statement stmt = connection.createStatement();
        stmt.setQueryTimeout(3600); // 1 hour
        ResultSet rs = null;
        long startExecutionTime = System.nanoTime(); //Logging
        try {
            rs = stmt.executeQuery(sqlQuery);
        } catch (SQLException e) { //Timeout management
            if (e.getMessage().toLowerCase().contains("timeout")) {
                Logger.info("SQL EXECUTION TIME: TIMEOUT REACHED");
                return -1;
            }
            e.printStackTrace();
        }
        Logger.info("Query executed");

        //Logging
        long endExecutionTime = System.nanoTime();
        Logger.info("SQL EXECUTION TIME: " +
                (endExecutionTime - startExecutionTime) / 1_000_000 + " milliseconds");

        int counter = 0;
        while (rs.next()) {
            //Logger.info(rs.getString(1)); //print first column of the output table
            counter++;
        }
        Logger.info("Output size: " + counter);

        return counter;
    }

    private String cleanConstantsName(String s) {
        String regex = "\"[^\\s#]+#([^\\s#]+)\"";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(s);
        while (matcher.find()) {
            String constantName = matcher.group(1);
            s = s.replace(matcher.group(), '"' + constantName + '"');
        }
        return s;
    }

    //PADDING COMPUTATION

    private Set<List<OntologyPredicateAtom>> computePolicyPaddings(ArrayList<EpistemicDependency> policy, OntologyConjunctiveQuery query) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        Set<Set<OntologyPredicateAtom>> unorderedResult = new HashSet<>();
        unorderedResult.add(new HashSet<>()); //Always consider the empty padding as the query could match an ED body itself
        for (EpistemicDependency ed : policy){
            ArrayList<String> predicateIRIs = new ArrayList<>();
            for (OntologyPredicateAtom EDopa : ed.getBody().getAllPredicateAtoms()){
                predicateIRIs.add(EDopa.getPredicateIRI());
            }
            for (OntologyPredicateAtom opa: query.getOntologyPredicateAtoms()){
                Set<Set<OntologyPredicateAtom>> paddings = computeEDPaddings(predicateIRIs, opa);
                unorderedResult.addAll(paddings);
            }
        }
        Set<List<OntologyPredicateAtom>> result = new HashSet<>();
        for (Set<OntologyPredicateAtom> unorderedSet : unorderedResult){
            List<OntologyPredicateAtom> orderedVersion = new ArrayList<>(unorderedSet);
            orderedVersion.sort(Comparator.comparing(OntologyPredicateAtom::getPredicateIRI));
            result.add(orderedVersion);
        }
        return result;
    }

    //Given the list l of IRIs in the body of an ED and an predicate qp with iri i
    //if l contains i, removes an occurrence of it from l,
    //computes al the subsets of l and returns the corresponding sets of OPA.
    //Else returns an empty set.
    private Set<Set<OntologyPredicateAtom>> computeEDPaddings(List<String> EDiris, OntologyPredicateAtom queryAtom) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        String queryAtomIRI = queryAtom.getPredicateIRI();
        if (!EDiris.contains(queryAtomIRI)) return new HashSet<>();
        EDiris.remove(queryAtomIRI);
        Set<OntologyPredicateAtom> dummyPredicates = new HashSet<>();
        int i = 0; //A padding cannot contain two variables with the same name
        Collections.sort(EDiris); //To avoid creating more paddings that only differ in the names of the variables
        for (String iri : EDiris){
            OntologyPredicateAtom.Type type = OntologyPredicateAtom.getType(iri, this.tbox);
            ArrayList<Variable> newTerms = new ArrayList<>();
            newTerms.add(new Variable("dum" + i));
            i = i+1;
            if (type.equals(OntologyPredicateAtom.Type.ROLE)){
                newTerms.add(new Variable("dum" + i));
                i = i+1;
            }
            dummyPredicates.add(new OntologyPredicateAtom(iri, newTerms, this.tbox));
        }
        return Utils.getSubsetsSmallerThenK(dummyPredicates, dummyPredicates.size()+1);
    }

    //ISDISCL AUX

    private Set<Equality> getRelevantEqualities(Substitution substitution, Collection<OntologyPredicateAtom> unionSet) {
        Set<Equality> res = new HashSet<Equality>();
        Set<Variable> unionVariables = new HashSet<>();
        for(OntologyPredicateAtom opa : unionSet) {
            for (Variable v : opa.getVariables()){
                Variable v1 = v.clone();
                v1.unbind();
                unionVariables.add(v1);
            }
        }
        for (Equality e : substitution.getEqualities()){
            Term leftTerm = e.getLeftTerm();
            if (leftTerm instanceof Variable) {
                Variable left = (Variable) leftTerm;
                left.unbind();
                if (unionVariables.contains(left)) res.add(e.clone());
            }
        }
        return res;
    }

    //MAPPING COMPUTATION

    public ArrayList<Substitution> generateMappings(Integer edIndex, List<OntologyPredicateAtom> unionList) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        ArrayList<OntologyPredicateAtom> body = orderedBodies.get(edIndex);
        Map<String, Integer> occurencies = occurenciesInBodies.get(edIndex);
        ArrayList<String> predicateOrder = predicateOrderInBodies.get(edIndex);
        Map<String, List<Integer>> buckets = generateBuckets(occurencies.keySet(), unionList);
        //Buckets ex.: {R -> [1, 3], S -> [2]}
        //Occurencies ex: {R -> 1, S -> 1}
        //Subsequences ex.: {[(1, 1), (1, 3), (3, 1), (3, 3)], [(2)]} (all square parenthesis)
        List<List<List<Integer>>> subsequences = new ArrayList<>();
        for (String iri : predicateOrder){
            List<Integer> values = buckets.get(iri);
            Integer cardinality = occurencies.get(iri);
            subsequences.add(Utils.dispositionsWithRepetitions(values, cardinality));
        }
        //Cartesian product. A first evaluation is done runtime to avoid storing useless candidates.
        List<Set<Set<Term>>> equivalenceClassesSets = new ArrayList<>();
        cartesianProductWithEvaluation(subsequences, 0, new ArrayList<>(), equivalenceClassesSets, body, unionList);

        Set<Term> unionTerms = new HashSet<>();
        for (OntologyPredicateAtom opa : unionList) unionTerms.addAll(opa.getTerms());
        ArrayList<Substitution> res = new ArrayList<>();
        for(Set<Set<Term>> ecs : equivalenceClassesSets) {
            Map<Variable, Term> mapping = new HashMap<>();
            for (Set<Term> ec : ecs) {
                Term key = null; //Choose key, the set contains at most one constant and no variables QBT
                for (Term t : ec) {
                    if (t instanceof Constant) {
                        key = t;
                        break;
                    }
                    else if (unionTerms.contains(t)) key = t;
                }
                //Populate map
                Term unboundKey;
                if (key instanceof Variable) {
                    Variable tmp = (Variable) key;
                    tmp.unbind();
                    unboundKey = tmp.clone();
                }
                else{
                    unboundKey = key.clone();
                }
                for (Term t : ec) {
                    if (t instanceof Variable) {
                        Variable v = (Variable) t;
                        v.unbind();
                        if (!v.equals(key)) mapping.put(v.clone(),unboundKey);
                    }
                }
            }
            res.add(new Substitution(mapping));
        }
        return res;
    }

    //Compute a map between IRIs and OPA indexes
    private Map<String, List<Integer>> generateBuckets(Set<String> keys, List<OntologyPredicateAtom> unionList) {
        Map<String, List<Integer>> res = new HashMap<>();
        for (String s : keys) res.put(s, new ArrayList<>());
        for (int i = 0; i < unionList.size(); i++){
            OntologyPredicateAtom opa = unionList.get(i);
            String iri = opa.getPredicateIRI();
            if(keys.contains(iri)) {
                ArrayList<Integer> tmp = new ArrayList<>();
                tmp.addAll(res.get(iri));
                tmp.add(i);
                res.replace(iri, tmp);
            }
        }
        return res;
    }

    private static void cartesianProductWithEvaluation(List<List<List<Integer>>> sets, int index, List<List<Integer>> current, List<Set<Set<Term>>> result, ArrayList<OntologyPredicateAtom> bodyToMatch, List<OntologyPredicateAtom> unionList) {
        if (index == sets.size()) { //Base case
            List<List<Integer>> candidateIndexes = new ArrayList(current);
            ArrayList<OntologyPredicateAtom> candidate = new ArrayList<>();
            for (List<Integer> l : candidateIndexes){
                for (Integer i : l) candidate.add(unionList.get(i));
            }
            Set<Set<Term>> newEC = equivalenceClassesBetweenAlignedSequences(candidate, bodyToMatch);
            if(newEC != null) result.add(newEC);
            return;
        }
        //Recursive case
        List<List<Integer>> set = sets.get(index);
        for (List<Integer> element : set) {
            current.add(element);
            cartesianProductWithEvaluation(sets, index + 1, current, result, bodyToMatch, unionList);
            current.remove(current.size() - 1);
        }
    }

    //Predicate names must be aligned.
    //Quantified variables' names in Q must begin with "quantifiedBT"
    public static Set<Set<Term>> equivalenceClassesBetweenAlignedSequences(ArrayList<OntologyPredicateAtom> sequenceQ, ArrayList<OntologyPredicateAtom> sequenceZ){
        ArrayList<Term> termsQ = getOrderedTerms(sequenceQ);
        ArrayList<Term> termsZ = getOrderedTerms(sequenceZ);
        int n = termsZ.size();
        Set<Set<Term>> equivalenceClasses = new HashSet<>();
        for (int i = 0; i < n; i++) {
            Term termQ = termsQ.get(i);
            Term termZ = termsZ.get(i);
            int err = unifyTerms(termQ,termZ,equivalenceClasses);
            if(err != 0) return null;
        }
        Set<Set<Term>> equivalenceClassesClone = new HashSet<>();
        for (Set<Term> ec : equivalenceClasses){ //Check presence of two equals constants and delete QBT
            Term foundConstant = null;
            Set<Term> ecClone = new HashSet<>();
            for (Term t : ec){
                if (t instanceof Constant) {
                    if (foundConstant == null) foundConstant = t;
                    else if (!foundConstant.equals(t)) return null;
                }
                if (!quantifiedInBodyTau(t)) ecClone.add(t);
            }
            equivalenceClassesClone.add(ecClone);
        }
        return equivalenceClassesClone;
    }

    private static int unifyTerms(Term termQ, Term termZ, Set<Set<Term>> buckets) {
        if(termQ.equals(termZ)) return 0; //equal constants or equal variables
        else if(termQ instanceof Constant && termZ instanceof Constant) return 1; //different constants can't be unified
        else if(termQ instanceof Constant) insertInBucket(termQ, termZ, buckets); //only q is a constant
        else if(termZ instanceof Constant) insertInBucket(termZ, termQ, buckets); //only z is a constant
        else if(!quantifiedInBodyTau(termQ)) joinBuckets(termQ, termZ, buckets); //both useful variables
        insertInBucket(termQ, termZ, buckets);
        return 0;
    }

    private static void joinBuckets(Term termQ, Term termZ, Set<Set<Term>> buckets) {
        Set<Term> setQ = findBucket(buckets, termQ);
        Set<Term> setZ = findBucket(buckets, termZ);
        if (setQ == null) {
            setQ = new HashSet<>();
            setQ.add(termQ);
        }
        else buckets.remove(setQ);
        if (setZ == null) {
            setZ = new HashSet<>();
            setZ.add(termZ);
        }
        else buckets.remove(setZ);
        Set<Term> newBucket = new HashSet<>();
        newBucket.addAll(setQ);
        newBucket.addAll(setZ);
        buckets.add(newBucket);
    }

    private static void insertInBucket(Term toAdd, Term key, Set<Set<Term>> buckets) {
        Set<Term> bucket = findBucket(buckets, key);
        if(bucket!=null){
            bucket.add(toAdd);
        }
        else {
            Set<Term> newBucket = new HashSet<>();
            newBucket.add(toAdd);
            newBucket.add(key);
            buckets.add(newBucket);
        }
    }

    private static Set<Term> findBucket(Set<Set<Term>> buckets, Term key) {
        for (Set<Term> b : buckets){
            for (Term t : b){
                if (t.equals(key)) return b;
            }
        }
        return null;
    }

    private static ArrayList<Term> getOrderedTerms(ArrayList<OntologyPredicateAtom> predicates) {
        ArrayList<Term> res = new ArrayList<>();
        for(OntologyPredicateAtom opa : predicates) {
            res.addAll(opa.getTerms());
        }
        return res;
    }

    private static boolean quantifiedInBodyTau(Term t){
        if(t instanceof Variable) {
            Variable v = (Variable) t;
            String name = v.getName();
            return name.length() > 11 && name.startsWith("quantifiedBT");
        }
        return false;
    }
}
