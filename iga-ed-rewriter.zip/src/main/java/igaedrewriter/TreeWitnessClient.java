package igaedrewriter;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.sparql.core.TriplePath;
import com.hp.hpl.jena.sparql.syntax.Element;
import com.hp.hpl.jena.sparql.syntax.ElementPathBlock;
import com.hp.hpl.jena.sparql.syntax.ElementVisitorBase;
import com.hp.hpl.jena.sparql.syntax.ElementWalker;
import org.apache.xerces.util.URI;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import igaedrewriter.fol.ObjectConstant;
import igaedrewriter.fol.OntologyPredicateAtom;
import igaedrewriter.fol.PredicateAtom;
import igaedrewriter.policy.OntologyConjunctiveQuery;
import igaedrewriter.util.OntologyUtils;
import uk.ac.bbk.dcs.obda.model.*;
import uk.ac.bbk.dcs.obda.twrewriting.DatalogQueryServices;
import uk.ac.bbk.dcs.obda.twrewriting.MinimalCQProducer;
import uk.ac.bbk.dcs.obda.twrewriting.TreeWitnessReasonerLite;
import uk.ac.bbk.dcs.obda.twrewriting.TreeWitnessRewriter;

import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CREDITS:
 * Adapted from the tw-rewriter interface by Roman Kontchakov
 * https://titan.dcs.bbk.ac.uk/~roman/tw-rewriting/
 **/

public class TreeWitnessClient {
	private static final IRI queryURI = IRI.create("http://q");
	
	public static Set<OntologyConjunctiveQuery> rewriteQuery(String sparql, OWLOntology ontology, boolean importQueryPrefixesFromOntology) throws PredicateAtom.PredicateArityException, igaedrewriter.fol.Term.TermTypeException, URISyntaxException {
		if (importQueryPrefixesFromOntology) {
			String sparqlPrefixes = String.join("\n", OntologyUtils.getStringPrefixes(ontology, "PREFIX %s <%s>"));
			sparql = sparqlPrefixes + "\n\n" + sparql;
		}
		return rewriteQuery(sparql, ontology);
	}
	
	public static Set<OntologyConjunctiveQuery> rewriteQuery(String sparql, OWLOntology ontology) throws igaedrewriter.fol.Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		TreeWitnessRewriter twr = new TreeWitnessRewriter();
		Ontology twOntology = new Ontology(ontology);
		twr.setTBox(twOntology);
		CQCUtilities.reasoner = twr.getReasoner();
		CQIE cqie = buildQuery(sparql, twr.getReasoner());
		DatalogProgram dp = new DatalogProgram();
		dp.appendRule(cqie);
		DatalogProgram nr = (DatalogProgram) twr.rewrite(dp);
		List<CQIE> qp = new LinkedList<>();
		
		for (CQIE q : nr.getRules()) {
			if (q.getHead().getPredicate().getName().equals(queryURI)) {
				qp.add(q);
			}
		}
		
		// Remove redundant queries
		Iterator<CQIE> iterator = qp.iterator();
		while (iterator.hasNext()) {
			CQIE cq = iterator.next();
			for (CQIE q2 : qp) {
				if (cq != q2 && subsumedBy(twr.getReasoner(), cq, q2)) {
					iterator.remove();
					break;
				}
			}
		}
		
		for (CQIE q : qp) {
			for (Atom a : q.getBody()) {
				IRI extName = IRI.create(a.getPredicate().getName().toString() + "_EXT");
				Predicate ext = OBDADataFactory.getInstance().getPredicate(extName, a.getArity(), null);
				List<CQIE> rules = nr.getRules(ext);
				if (!rules.isEmpty()) {
					a.getPredicate().setName(extName);
				}
			}
		}
		
		DatalogProgram dp2 = new DatalogProgram();
		dp2.appendRule(qp);
		DatalogProgram output = DatalogQueryServices.plugInDefinitions(dp2, nr);
		//System.out.println("#rewritten queries: " + output.getRules().size());
		
		Set<OntologyConjunctiveQuery> result = new HashSet<>();
		for (CQIE qr : output.getRules()) {
			if(qr.toString().contains(OntologyUtils.INVERSE_AUX_SUFFIX)) continue;
			List<OntologyPredicateAtom> atoms = new ArrayList<>();
			for (Atom twAtom : qr.getBody()) {
				atoms.add(new OntologyPredicateAtom(
						twAtom.getPredicate().getName().toString(),
						convertTermList(twAtom.getTerms()),
						ontology
				));
			}
			result.add(new OntologyConjunctiveQuery(
					atoms,
					convertTermList(qr.getHead().getTerms()).stream()
							.map(t->(igaedrewriter.fol.Variable)t)
							.collect(Collectors.toList())
			));
		}
		return result;
	}
	
	private static List<igaedrewriter.fol.Term> convertTermList(List<Term> twTerms) {
		List<igaedrewriter.fol.Term> terms = new ArrayList<>();
		for (Term twTerm : twTerms) {
			if (twTerm instanceof Constant) {
				terms.add(new ObjectConstant(twTerm.toString()));
			}
			else {
				terms.add(new igaedrewriter.fol.Variable(twTerm.toString()));
			}
		}
		return terms;
	}
	
	private static boolean subsumedBy(TreeWitnessReasonerLite twr, CQIE cq, CQIE q2) {
		Iterator<Atom> atomIterator = q2.getBody().iterator();
		
		boolean found;
		do {
			if (!atomIterator.hasNext()) {
				return true;
			}
			
			Atom q2a = atomIterator.next();
			found = false;
			for (Atom cqa : cq.getBody()) {
				if (twr.isMoreSpecific(cqa, q2a)) {
					found = true;
					break;
				}
			}
		} while (found);
		
		return false;
	}
	
	private static CQIE buildQuery(String queryString, final TreeWitnessReasonerLite reasoner) {
		Query queryObject = QueryFactory.create(queryString);
		if (queryObject.getQueryType() != 111) {
			System.out.println("treewitness/ERROR: NOT A SELECT QUERY");
		}
		
		Element qp = queryObject.getQueryPattern();
		final MinimalCQProducer body = new MinimalCQProducer(reasoner);
		ElementVisitorBase elementVisitor = new ElementVisitorBase() {
			public void visit(ElementPathBlock el) {
				Atom a;
				for(ListIterator<TriplePath> iterator = el.getPattern().iterator(); iterator.hasNext(); body.add(a)) {
					TriplePath triplePath = iterator.next();
					a = null;
					
					try {
						String ps = triplePath.getPredicate().getURI();
						if (!ps.equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#type")) {
							String psi = reasoner.getNamedInverse(ps);
							if (psi == null) {
								a = new Atom(IRI.create(ps), getTerm(triplePath.getSubject()), getTerm(triplePath.getObject()));
							} else {
								a = new Atom(IRI.create(psi), getTerm(triplePath.getObject()), getTerm(triplePath.getSubject()));
							}
						} else {
							a = new Atom(IRI.create(triplePath.getObject().getURI()), getTerm(triplePath.getSubject()));
						}
					} catch (URI.MalformedURIException e) {
						e.printStackTrace();
					}
				}
				
			}
		};
		ElementWalker.walk(qp, elementVisitor);
		List<Term> ans = new LinkedList<>();
		for (String ansv : queryObject.getResultVars()) {
			ans.add(new Variable(ansv));
		}
		
		return new CQIE(new Atom(queryURI, ans), body.getAtoms());
	}
	
	private static Term getTerm(Node n) throws URI.MalformedURIException {
		if (n.isVariable()) {
			return new Variable(n.getName());
		} else {
			return n.isURI() ? new Constant(IRI.create(n.getURI())) : null;
		}
	}
}
