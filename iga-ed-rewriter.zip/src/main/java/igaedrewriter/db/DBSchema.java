package igaedrewriter.db;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class DBSchema {
	private final String database;
	private final Set<Table> tables;
	
	public DBSchema(String database, Set<Table> tables) {
		this.database = database;
		this.tables = tables;
	}
	
	public DBSchema(String database) {
		this(database, new HashSet<>());
	}
	
	public Set<Table> getTables() {
		return tables;
	}
	
	public String getDatabase() {
		return database;
	}
	
	public Table getTableByName(String tableName) {
		for (Table r : tables) {
			if (r.getTableName().equals(tableName)) return r;
		}
		return null;
	}
	
	public Map<String,Integer> getPredicateToArityMap() {
		Map<String,Integer> map = new HashMap<>();
		tables.forEach(t -> map.put(t.getTableName(), t.getArity()));
		return map;
	}
	
	public void addTable(Table table) {
		this.tables.add(table);
	}
	
	public void removeTable(Table table) {
		this.tables.add(table);
	}
}
