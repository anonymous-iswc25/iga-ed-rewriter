package igaedrewriter.db;

import java.util.*;
import java.util.stream.Collectors;

public class Inclusion {
	public final Table leftTable;
	public final Table rightTable;
	public final int[] leftAttributesIndices;
	public final int[] rightAttributesIndices;
	
	public Inclusion(Table leftTable, int[] leftAttributesIndices, Table rightTable, int[] rightAttributesIndices) throws InclusionException {
		if (leftAttributesIndices.length != rightAttributesIndices.length)
			throw new InclusionException("The number of attributes for the two relations must be the same.");
		
		InclusionException smallIndexException = new InclusionException("An attribute index must be greater than 1.");
		InclusionException bigIndexException   = new InclusionException("An attribute index of an N-ary relation must be less than or equal to N.");
		for (int index : leftAttributesIndices) {
			if (index < 1) throw smallIndexException;
			if (index > leftTable.getArity()) throw bigIndexException;
		}
		for (int index : rightAttributesIndices) {
			if (index < 1) throw smallIndexException;
			if (index > rightTable.getArity()) throw bigIndexException;
		}
		
		this.leftTable = leftTable;
		this.rightTable = rightTable;
		this.leftAttributesIndices = leftAttributesIndices;
		this.rightAttributesIndices = rightAttributesIndices;
	}
	
	public List<Integer> notPropagatedPositions(){
		List<Integer> notPropagatedPositions = new ArrayList<>();
		for (int p = 1; p <= getRightArity(); p++) {
			boolean found = false;
			for (int rightAttributesIndex : rightAttributesIndices) {
				if (rightAttributesIndex == p) {
					found = true;
					break;
				}
			}
			if (!found) notPropagatedPositions.add(p-1);
		}
		
		return notPropagatedPositions;
	}
	
	/**
	 *
	 */
	public Map<Integer, Integer> createMap(){
		HashMap<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < this.leftAttributesIndices.length; i++){
			int leftPos  = this.leftAttributesIndices[i];
			int rightPos = this.rightAttributesIndices[i];
			map.put(rightPos, leftPos);
		}
		return map;
	}
	
	public List<Integer> getLeftAttributes(){
		return Arrays.stream(this.leftAttributesIndices)
				.map(index -> index - 1)
				.boxed()
				.collect(Collectors.toList());
	}
	
	public List<Integer> getRightAttributes(){
		return Arrays.stream(this.rightAttributesIndices)
				.map(index -> index - 1)
				.boxed()
				.collect(Collectors.toList());
	}
	
	public int getLeftArity(){
		return leftTable.getArity();
	}
	
	public int getRightArity(){
		return rightTable.getArity();
	}
	
	@Override
	public String toString(){
		return leftTable.getTableName() + Arrays.toString(leftAttributesIndices) + "->" +
				rightTable.getTableName() + Arrays.toString(rightAttributesIndices);
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Inclusion i = (Inclusion) o;
		return Objects.equals(leftTable, i.leftTable) && Arrays.equals(leftAttributesIndices, i.leftAttributesIndices) &&
				Objects.equals(rightTable, i.rightTable) && Arrays.equals(rightAttributesIndices, i.rightAttributesIndices);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(leftTable, leftAttributesIndices, rightTable, rightAttributesIndices);
	}
	
	public static class InclusionException extends Exception {
		public InclusionException(String s) {
			super(s);
		}
	}
}