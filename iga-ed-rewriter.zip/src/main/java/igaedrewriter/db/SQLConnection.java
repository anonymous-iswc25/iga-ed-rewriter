package igaedrewriter.db;

import igaedrewriter.Configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLConnection {
	private final Connection conn;
	
	private static Connection lastConnection;
	private static String lastUser;
	private static String lastPassword;
	private static String lastDriver;
	
	public SQLConnection(Configuration conf) throws SQLException, DriverNotFoundException {
		String user = conf.dbUser;
		String password = conf.dbPassword;
		String driver = conf.jdbcDriver;
		
		if (user.equals(lastUser) && password.equals(lastPassword) && driver.equals(lastDriver)
				&& lastConnection != null && lastConnection.isValid(10)) {
			conn = lastConnection;
		}
		else {
			conn = DriverManager.getConnection(getUrl(conf), user, password);
			
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				throw new DriverNotFoundException(driver);
			}
			
			lastConnection = conn;
			lastUser = user;
			lastPassword = password;
			lastDriver = driver;
		}
	}
	
	public Connection getConnection() {
		return conn;
	}
	
	/**
	 * This method tests if an SQL connection can be created from a given configuration.
	 *
	 * @param conf the configuration file
	 * @throws DriverNotFoundException If the DB driver (a Java class) specified in the configuration file is not found.
	 * @throws SQLException If the connection can't be established for other reasons.
	 */
	public static void testConnection(Configuration conf) throws DriverNotFoundException, SQLException {
		new SQLConnection(conf);
	}
	
	// TODO: generalize URL
	private static String getUrl(Configuration conf) {
		String connectionOptions = conf.jdbcConnectionOptions != null ? conf.jdbcConnectionOptions : "";
		return String.format("jdbc:mysql://localhost:%s/%s%s", conf.dbPortNumber, conf.dbName, connectionOptions);
	}
	
	public static class DriverNotFoundException extends ClassNotFoundException {
		public DriverNotFoundException(String driverName) {
			super("No class has been found for the following driver: " + driverName);
		}
	}
}
