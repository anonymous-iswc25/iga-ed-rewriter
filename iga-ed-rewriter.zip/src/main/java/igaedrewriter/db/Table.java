package igaedrewriter.db;

import igaedrewriter.Logger;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class Table {
	private final String name;
	private final LinkedHashMap<String,String> attributeToType = new LinkedHashMap<>(); // LinkedHashMap preserves the attributes' order
	
	public Table(String tableName, List<String> attributeNames) {
		if (SQLUtils.isSQLReservedWord(tableName)) Logger.warn(tableName + " is a SQL reserved word. It may cause errors if used as table name.");
		this.name = tableName;
		for (String attributeName : attributeNames) {
			this.attributeToType.put(attributeName, null);
		}
	}
	
	public Table(String tableName, LinkedHashMap<String,String> attributeToType) {
		if (SQLUtils.isSQLReservedWord(tableName)) Logger.warn(tableName + " is a SQL reserved word. It may cause errors if used as table name.");
		this.name = tableName;
		this.attributeToType.putAll(attributeToType);
	}
	
	public String getType(String attributeName) {
		return this.attributeToType.get(attributeName);
	}
	
	/**
	 * Attribute indices start from 0.
	 */
	public String getType(int attributeIndex) {
		int counter = 0;
		for (String attributeName : this.attributeToType.keySet()) {
			if (counter == attributeIndex) return this.attributeToType.get(attributeName);
			else counter++;
		}
		return null;
	}
	
	public String getTableName() {
		return name;
	}
	
	public List<String> getAttributes() {
		return new ArrayList<>(this.attributeToType.keySet());
	}
	
	public LinkedHashMap<String,String> getAttributeToType() {
		return new LinkedHashMap<>(attributeToType);
	}
	
	public int getArity() {
		return this.attributeToType.size();
	}
	
	@Override
	public String toString() {
		List<String> attributesData = new ArrayList<>();
		for (String attributeName : this.attributeToType.keySet()) {
			String type = this.attributeToType.get(attributeName);
			attributesData.add(type == null ? attributeName : attributeName + " " + type);
		}
		return String.format("%s(%s)", name, String.join(", ", attributesData));
	}
}
