package igaedrewriter.fol;

public abstract class Constant extends Term { }