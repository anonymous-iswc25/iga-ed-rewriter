package igaedrewriter.fol;

import org.semanticweb.owlapi.vocab.OWL2Datatype;

import org.jetbrains.annotations.NotNull;

import java.math.BigInteger;

import static igaedrewriter.fol.Datatype.*;

public class DataConstant extends Constant {
	private final @NotNull String value;
	private final @NotNull Datatype datatype;
	
	@SuppressWarnings("unused")
	public DataConstant(@NotNull String value) throws DatatypeNoMatchException {
		this(value, XSD_STRING);
	}
	
	@SuppressWarnings("unused")
	public DataConstant(int value) throws DatatypeNoMatchException {
		this(Integer.toString(value), XSD_INT);
	}
	
	@SuppressWarnings("unused")
	public DataConstant(@NotNull BigInteger value) throws DatatypeNoMatchException {
		this(value.toString(), XSD_INTEGER);
	}
	
	@SuppressWarnings("unused")
	public DataConstant(float value) throws DatatypeNoMatchException {
		this(Float.toString(value), XSD_FLOAT);
	}
	
	public DataConstant(@NotNull String value, @NotNull OWL2Datatype owl2Datatype) throws OWL2DataytypeNotSupportedException, DatatypeNoMatchException {
		this(value, getDatatype(owl2Datatype));
	}
	
	private static Datatype getDatatype(OWL2Datatype owl2Datatype) throws OWL2DataytypeNotSupportedException {
		Datatype datatype = Datatype.getDatatype(owl2Datatype);
		if (datatype == null) {
			throw new OWL2DataytypeNotSupportedException(owl2Datatype);
		}
		return datatype;
	}
	
	public DataConstant(@NotNull String value, @NotNull Datatype datatype) throws DatatypeNoMatchException {
		if (!datatype.getPattern().matcher(value).matches()) {
			throw new DatatypeNoMatchException(value, datatype);
		}
		this.value = value;
		this.datatype = datatype;
	}
	
	@NotNull
	public String getValue() {
		return this.value;
	}
	
	@NotNull
	@Override
	public Term.Type getType() {
		return Type.DATA;
	}
	
	@NotNull
	public Datatype getDatatype() {
		return this.datatype;
	}
	
	/**
	 * @param usePrefixedDatatype If {@code true}, the method specifies the datatype with the namespace prefix,
	 *                            otherwise, it uses the whole datatype IRI (default: {@code true}).
	 */
	public String toSparql(boolean usePrefixedDatatype) {
		return String.format(
				usePrefixedDatatype ? "\"%s\"^^%s" : "\"%s\"^^<%s>",
				value,
				usePrefixedDatatype ? datatype.getPrefixedName() : datatype.getIRI()
		);
	}
	
	@Override
	public String toSparql() {
		return this.toSparql(true);
	}
	
	@Override
	public int hashCode() {
		// specifying the class is important because a Variable, a DataConstant and a ObjectConstant must always have different hashcodes
		return (getClass() + value + datatype).hashCode();
	}
	
	@Override
	public boolean equals(@NotNull Object obj) {
		if (getClass() != obj.getClass())
			return false;
		return this.value.equals(((DataConstant) obj).value)
				&& this.datatype.equals(((DataConstant) obj).datatype);
	}
	
	@Override
	public String toString() {
		switch (datatype) {
			case XSD_BOOLEAN:
				return value.equals("1") ? "true" : Boolean.valueOf(value).toString();
			case XSD_DATE_TIME:
			case XSD_DECIMAL:
			case XSD_FLOAT:
			case XSD_INT:
			case XSD_INTEGER:
				return value;
			case XSD_STRING:
				return "\"" + value + "\"";
		}
		throw new RuntimeException();
	}
	
	@Override
	public DataConstant clone() {
		return (DataConstant) super.clone();
	}
	
	public static class OWL2DataytypeNotSupportedException extends Exception {
		public OWL2DataytypeNotSupportedException(OWL2Datatype datatype) {
			super("OWL 2 datatype not supported: " + datatype.getPrefixedName());
		}
	}
	
	public static class DatatypeNoMatchException extends Exception {
		public DatatypeNoMatchException(String value, Datatype datatype) {
			super(String.format("Value \"%s\" does not match the pattern for datatype %s (/%s/)",
					value, datatype.getPrefixedName(), datatype.getPattern()));
		}
	}
}
