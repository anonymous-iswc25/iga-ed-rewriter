package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

/**
 * An equality is a construct of the form {@code x = y}, where {@code x} and {@code y} are {@link Term terms}.
 */
public class Equality extends ComparisonAtom {
	
	public Equality(@NotNull Term left, @NotNull Term right) {
		super(left, right, "=", true);
	}
	
	@Override
	public boolean isTautology() {
		return this.negate().isContradiction();
	}
	
	/**
	 * The following method is semantically sound only under the so-called unique name assumption.
	 */
	@Override
	public boolean isContradiction() {
		return this.negate().isTautology();
	}
	
	@Override
	public StrictInequality negate() {
		return new StrictInequality(this.left, this.right);
	}
	
	@Override
	public Equality clone() {
		return (Equality) super.clone();
	}

	public boolean equals(Object obj){
		if (getClass() != obj.getClass()) return false;
		Equality e = (Equality) obj;
		return e.getLeftTerm().equals(getLeftTerm()) && e.getRightTerm().equals(getRightTerm());
	}
}
