package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;

/**
 * This class models an existential quantifier. See also {@link Quantifier}.
 */
public class Exist extends Quantifier {
	
	public Exist(@NotNull Formula subformula) {
		super(subformula);
	}
	
	public Exist(@NotNull Formula subformula, @NotNull Variable... existentialVars) {
		super(subformula, existentialVars);
	}
	
	public Exist(@NotNull Formula subformula, @NotNull ArrayList<Variable> existentialVars) {
		super(subformula, existentialVars);
	}
	
	@Override
	public boolean isTautology() {
		return false;
	}
	
	@Override
	public boolean isContradiction() {
		return content.isContradiction();
	}
	
	@Override
	public Exist clone() {
		return (Exist) super.clone();
	}
	
	@Override
	public String toString() {
		return toString("\\exists");
	}
}
