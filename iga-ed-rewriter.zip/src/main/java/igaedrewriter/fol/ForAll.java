package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;

/**
 * This class models an universal quantifier. See also {@link Quantifier}.
 */
public class ForAll extends Quantifier {
	
	public ForAll(@NotNull Formula subformula) {
		super(subformula);
	}
	
	public ForAll(@NotNull Formula subformula, @NotNull Variable... universalVars) {
		super(subformula, universalVars);
	}
	
	public ForAll(@NotNull Formula subformula, @NotNull ArrayList<Variable> universalVars) {
		super(subformula, universalVars);
	}
	
	@Override
	public boolean isTautology() {
		return content.isTautology();
	}
	
	@Override
	public boolean isContradiction() {
		return false;
	}
	
	@Override
	public ForAll clone() {
		return (ForAll) super.clone();
	}
	
	@Override
	public String toString() {
		return toString("\\forall");
	}
}
