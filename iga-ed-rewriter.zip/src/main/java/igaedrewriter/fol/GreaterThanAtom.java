package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

public class GreaterThanAtom extends InequalityAtom {
	
	public GreaterThanAtom(@NotNull Term left, @NotNull Term right) {
		super(left, right, ">", false);
	}
	
	@Override
	public boolean isTautology() {
		return this.negate().isContradiction();
	}
	
	@Override
	public boolean isContradiction() {
		return this.negate().isTautology();
	}
	
	@Override
	public LessThanOrEqualAtom negate() {
		return new LessThanOrEqualAtom(this.left, this.right);
	}
	
	@Override
	public GreaterThanAtom clone() {
		return (GreaterThanAtom) super.clone();
	}
}
