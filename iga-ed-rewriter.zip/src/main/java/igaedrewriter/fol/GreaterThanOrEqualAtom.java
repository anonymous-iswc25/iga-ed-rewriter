package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

public class GreaterThanOrEqualAtom extends InequalityAtom {
	
	public GreaterThanOrEqualAtom(@NotNull Term left, @NotNull Term right) {
		super(left, right, ">=", false);
	}
	
	@Override
	public boolean isTautology() {
		return this.negate().isContradiction();
	}
	
	@Override
	public boolean isContradiction() {
		return this.negate().isTautology();
	}
	
	@Override
	public LessThanAtom negate() {
		return new LessThanAtom(this.left, this.right);
	}
	
	@Override
	public GreaterThanOrEqualAtom clone() {
		return (GreaterThanOrEqualAtom) super.clone();
	}
}
