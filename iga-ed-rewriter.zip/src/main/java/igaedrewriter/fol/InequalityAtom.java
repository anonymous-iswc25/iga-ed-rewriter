package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

/**
 * An inequality is a {@link ComparisonAtom comparison atom} that is not an {@link Equality equality}. It can be:
 * <ul>
 *     <li> a {@link StrictInequality strict inequality} ({@code !=});
 *     <li> a {@link LessThanAtom less-than inequality} ({@code <});
 *     <li> a {@link LessThanOrEqualAtom less-than-or-equal-to inequality} ({@code <=});
 *     <li> a {@link GreaterThanAtom greater-than inequality} ({@code >});
 *     <li> a {@link GreaterThanOrEqualAtom greater-than-or-equal-to inequality} ({@code >=}).
 * </ul>
 */
public abstract class InequalityAtom extends ComparisonAtom {
	protected InequalityAtom(@NotNull Term left, @NotNull Term right, String sqlOperator, boolean symmetric) {
		super(left, right, sqlOperator, symmetric);
	}
}
