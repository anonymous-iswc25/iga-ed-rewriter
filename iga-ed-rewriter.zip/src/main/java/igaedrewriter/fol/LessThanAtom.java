package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

public class LessThanAtom extends InequalityAtom {
	
	public LessThanAtom(@NotNull Term left, @NotNull Term right) {
		super(left, right, "<", false);
	}
	
	@Override
	public boolean isTautology() {
		// TODO
		return false;
	}
	
	@Override
	public boolean isContradiction() {
		// TODO
		return false;
	}
	
	@Override
	public GreaterThanOrEqualAtom negate() {
		return new GreaterThanOrEqualAtom(this.left, this.right);
	}
	
	@Override
	public LessThanAtom clone() {
		return (LessThanAtom) super.clone();
	}
}
