package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

public class LessThanOrEqualAtom extends InequalityAtom {
	
	public LessThanOrEqualAtom(@NotNull Term left, @NotNull Term right) {
		super(left, right, "<=", false);
	}
	
	@Override
	public boolean isTautology() {
		// TODO
		return false;
	}
	
	@Override
	public boolean isContradiction() {
		// TODO
		return false;
	}
	
	@Override
	public GreaterThanAtom negate() {
		return new GreaterThanAtom(this.left, this.right);
	}
	
	@Override
	public LessThanOrEqualAtom clone() {
		return (LessThanOrEqualAtom) super.clone();
	}
}
