package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

public class MostGeneralUnifier {

	public static Substitution findMGU(@NotNull PredicateAtom[] atoms) {
		Substitution mgu = new Substitution();

		for (int i = 0; i < atoms.length - 1; i++) {
			for (int j = i + 1; j < atoms.length; j++) {
				Substitution pairMGU = findMGU(atoms[i], atoms[j]);

				if (pairMGU != null && compatibleUnifiers(mgu, pairMGU)) {
					mgu = Substitution.compose(mgu, pairMGU);
				}
				else return null;
			}
		}

		mgu.resolveChainedReplacements();

		return mgu;
	}

	private static Substitution findMGU(@NotNull PredicateAtom atom1, @NotNull PredicateAtom atom2) {
		// Check if the predicate names match
		if (!atom1.isSamePredicate(atom2)) {
			return null;
		}

		// Check if the arity (number of arguments) match
		if (atom1.getArity() != atom2.getArity()) {
			return null;
		}

		Substitution mgu = new Substitution();

		for (int i = 0; i < atom1.getArity(); i++) {
			Term term1 = atom1.getTerm(i);
			Term term2 = atom2.getTerm(i);

			Substitution pairMGU = findMGU(term1, term2);

			if (pairMGU == null) {
				// If a pair of terms is not unifiable, the overall atoms are not unifiable.
				return null;
			}

			mgu = Substitution.compose(mgu, pairMGU);
		}

		return mgu;
	}

	private static Substitution findMGU(Term term1, Term term2) {
		if (term1.equals(term2)) {
			// If terms are already identical, no substitution needed.
			return new Substitution();
		}

		if (term1 instanceof Variable) {
			return new Substitution((Variable) term1, term2);
		}

		if (term2 instanceof Variable) {
			return new Substitution((Variable) term2, term1);
		}

		// If both terms are constants and not equal, they are not unifiable.
		return null;
	}

	/**
	 * We say that two unifiers are compatible if, when "recursively" applied,
	 * they do not replace the same variable with different constants.
	 * <br>
	 * For example:
	 * <ul>
	 *     <li> {@code {y->3, x->3}} is compatible with {@code {y->x}};
	 *     <li> {@code {y->3, x->4}} is <i>not</i> compatible with {@code {y->x}}.
	 * </ul>
	 * @param s1 The first unifier.
	 * @param s2 The second unifier.
	 * @return {@code true} iff s1 is compatible with s2.
	 */
	public static boolean compatibleUnifiers(Substitution s1, Substitution s2) {
		FlatConjunction c = new FlatConjunction(s1.getEqualities());
		c.addAll(s2.getEqualities());
		return !c.isContradiction();
	}
}