package igaedrewriter.fol;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import igaedrewriter.fol.Term.TermTypeException;
import igaedrewriter.util.Lambdas;
import igaedrewriter.util.OntologyUtils;

import org.jetbrains.annotations.NotNull;
import java.net.URISyntaxException;
import java.util.*;

import static igaedrewriter.fol.OntologyPredicateAtom.Type.*;
import static igaedrewriter.fol.Term.Type.DATA;
import static igaedrewriter.fol.Term.Type.OBJECT;

public class OntologyPredicateAtom extends PredicateAtom {
	private final Type type;
	private final String predicateIRI;
	
	public enum Type {
		UNDEFINED, CONCEPT, ROLE, ATTRIBUTE;
		
		@Override
		public String toString() {
			switch (this) {
				case CONCEPT:   return "concept";
				case ROLE:      return "role";
				case ATTRIBUTE: return "attribute";
				default:        return "undefined";
			}
		}
	}
	
	public OntologyPredicateAtom(@NotNull String predicateIRI, @NotNull List<? extends Term> terms, Type type) throws URISyntaxException, PredicateArityException, TermTypeException {
		super(OntologyUtils.getPredicateNameFromIRI(predicateIRI), terms);
		this.type = type == Type.UNDEFINED ? guessType(this.terms) : type;
		this.predicateIRI = predicateIRI;
		
		this.arityCheck();
		this.setVariablesType();
		this.termsCheck();
	}
	
	public OntologyPredicateAtom(@NotNull String predicateIRI, @NotNull List<? extends Term> terms, OWLOntology ontology) throws URISyntaxException, PredicateArityException, TermTypeException {
		this(
				OntologyUtils.explicitIRIPrefix(predicateIRI, ontology),
				terms,
				OntologyPredicateAtom.getType(OntologyUtils.explicitIRIPrefix(predicateIRI, ontology), ontology)
		);
	}
	
	public OntologyPredicateAtom(@NotNull String predicateIRI, List<? extends Term> terms) throws URISyntaxException, PredicateArityException, TermTypeException {
		this(predicateIRI, terms, Type.UNDEFINED);
	}
	
	private Type guessType(List<Term> terms) {
		if (terms.size() == 1) return CONCEPT;
		if (terms.size() == 2) {
			if (terms.get(1).getType() == OBJECT) return ROLE;
			if (terms.get(1).getType() == DATA) return ATTRIBUTE;
		}
		return Type.UNDEFINED;
	}
	
	private void setVariablesType() {
		Term t1 = terms.get(0);
		if (t1 instanceof Variable && t1.getType() == Term.Type.UNDEFINED)
			((Variable) t1).setType(OBJECT);
		
		if (this.type != CONCEPT) {
			Term t2 = terms.get(1);
			if (t2 instanceof Variable && t2.getType() == Term.Type.UNDEFINED) {
				switch (this.type) {
					case ROLE:      ((Variable) t2).setType(OBJECT); break;
					case ATTRIBUTE: ((Variable) t2).setType(DATA);   break;
				}
			}
		}
	}
	
	public void arityCheck() throws PredicateArityException {
		final int termsNum = this.terms.size();
		
		if ((this.type == CONCEPT && termsNum != 1) || (this.type != CONCEPT && termsNum != 2))
			throw new PredicateArityException(String.format(
					"Forbidden arity for atom %s: %s <%s> can't have %d variables.",
					this.toString(), this.type.toString(), this.predicateIRI, termsNum));
	}
	
	public void termsCheck() throws TermTypeException {
		Lambdas.Function3<String,Term.Type,TermTypeException> termTypeError = (num, tType) -> new TermTypeException(
				String.format("Forbidden term type found in atom %s: %s term for %s <%s> must be %s %s constant/variable.",
						this.toString(), num, this.type.toString(), this.predicateIRI,
						tType == OBJECT ? "an" : "a", tType));
		
		if (getTerm(0).getType() == DATA) throw termTypeError.apply("first", OBJECT);
		
		switch (this.type) {
			case ROLE:
				if (getTerm(1).getType() == DATA) throw termTypeError.apply("second", OBJECT);
				break;
			case ATTRIBUTE:
				if (getTerm(1).getType() == OBJECT) throw termTypeError.apply("second", DATA);
				break;
		}
	}
	
	@Override
	public String getPredicateIdentifier() {
		return predicateIRI;
	}
	
	public String getPredicateIRI() {
		return predicateIRI;
	}
	
	public Type getType() {
		return type;
	}
	
	public static Type getType(String predicateIRI, OWLOntology ontology) {
		IRI iri = IRI.create(predicateIRI);
		if (ontology.containsClassInSignature(iri))
			return CONCEPT;
		if (ontology.containsObjectPropertyInSignature(iri))
			return ROLE;
		if (ontology.containsDataPropertyInSignature(iri))
			return ATTRIBUTE;
		return Type.UNDEFINED;
	}
	
	/**
	 * This method is a specialization (not a proper overriding) of {@link PredicateAtom#isSamePredicate(PredicateAtom)}.
	 */
	public boolean isSamePredicate(OntologyPredicateAtom atom) {
		return super.isSamePredicate(atom) && getType()==atom.getType();
	}
	
	@Override
	public OntologyPredicateAtom clone() {
        try {
            return new OntologyPredicateAtom(getPredicateIRI(), getTerms(), getType());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        } catch (PredicateArityException e) {
            throw new RuntimeException(e);
        } catch (TermTypeException e) {
            throw new RuntimeException(e);
        }
	}

	@Override
	public int hashCode() {
		return (getClass().toString() + getPredicateIdentifier() + getArity() + getPredicateIRI() + Objects.hash(terms)).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (getClass() != obj.getClass()) {
			return false;
		}
		OntologyPredicateAtom pa = (OntologyPredicateAtom) obj;
		if (!predicateName.equals(pa.getPredicateName())){
			return false;
		}
		if (!predicateIRI.equals(pa.getPredicateIRI())){
			return false;
		}
		if (!this.getTerms().equals(pa.getTerms())){
			return false;
		}
		return true;
	}
}
