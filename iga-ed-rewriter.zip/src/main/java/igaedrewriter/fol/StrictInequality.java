package igaedrewriter.fol;

import org.jetbrains.annotations.NotNull;

/**
 * A strict inequality is a construct of the form {@code not(x = y)} or {@code x \= y}, where {@code x} and {@code y} are {@link Term terms}.
 */
public class StrictInequality extends InequalityAtom {
	
	public StrictInequality(@NotNull Term left, @NotNull Term right) {
		super(left, right, "!=", true);
	}
	
	/**
	 * The following method is semantically sound only under the so-called unique name assumption.
	 */
	@Override
	public boolean isTautology() {
		return left instanceof Constant && right instanceof Constant
				&& !left.equals(right);
	}
	
	@Override
	public boolean isContradiction() {
		return left.equals(right);
	}
	
	@Override
	public Equality negate() {
		return new Equality(this.left, this.right);
	}
	
	@Override
	public StrictInequality clone() {
		return (StrictInequality) super.clone();
	}
}
