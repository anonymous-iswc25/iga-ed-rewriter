package igaedrewriter.fol;

import igaedrewriter.policy.EpistemicDependency;
import igaedrewriter.policy.OntologyConjunctiveQuery;

import org.jetbrains.annotations.NotNull;
import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

public class Substitution {
	private final Map<Variable, Term> substitutionMap;

	public Substitution() {
		this.substitutionMap = new HashMap<>();
	}

	public Substitution(@NotNull Map<Variable, Term> substitutionMap) {
		this.substitutionMap = substitutionMap;
	}

	public Substitution(@NotNull Variable v, @NotNull Term t) {
		this.substitutionMap = new HashMap<Variable,Term>() {{
			put(v,t);
		}};
	}

	public Term put(Variable variable, Term term) {
		return this.substitutionMap.put(variable, term);
	}

	public Set<Equality> getEqualities() {
		return substitutionMap
				.entrySet()
				.stream()
				.map(e -> new Equality(e.getKey(),e.getValue()))
				.collect(Collectors.toSet());
	}

	/**
	 * Example input: {@code {x->y, y->3}}<br>
	 * Example output: {@code {x->3, y->3}}
	 */
	public void resolveChainedReplacements() {
		while (true) {
			// Input: { v1->v2, v2->t2 }; Output: { v1->t2, v2->t2 }
			Variable v1 = null;
			Term t2 = null;
			for (Map.Entry<Variable, Term> entry : this.substitutionMap.entrySet()) {
				v1 = entry.getKey();
				Term t1 = entry.getValue();
				if (t1 instanceof Variable) {
					Variable v2 = (Variable) t1;
					if (this.substitutionMap.containsKey(v2)) {
						t2 = this.substitutionMap.get(v2);
						break;
					}
				}
			}
			if (v1 != null && t2 != null) {
				this.substitutionMap.put(v1, t2);
			}
			else break;
		}
	}

	/**
	 * The <i>composition</i> operator (∘) is defined as follows: given two substitutions {@code s1} and {@code s2},
	 * {@code s = s1 ∘ s2} is such that {@code s(x) = s2(s1(φ))} for every possible formula {@code φ}.
	 * <br>
	 * For example, given the substitutions:
	 * <ul>
	 *     <li> {@code s1 = { z->x }}
	 *     <li> {@code s2 = { x->y, y->3 }}
	 * </ul>
	 * this method will return {@code { z->y, x->y, y->3 }}.
	 * @param s1 The first substitution.
	 * @param s2 The second substitution.
	 * @return The substitution {@code s1 ∘ s2}.
	 */
	public static Substitution compose(Substitution s1, Substitution s2) {
		Substitution newSubst = new Substitution();

		// First, apply s2 to all the target variables of s1.
		for (Map.Entry<Variable, Term> entry : s1.substitutionMap.entrySet()) {
			newSubst.put(entry.getKey(), s2.applyTo(entry.getValue()));
		}

		// Then, add the replacements of s2, for the source variables that are not
		// already contained in the result substitution.
		for (Map.Entry<Variable, Term> entry : s2.substitutionMap.entrySet()) {
			Variable variable = entry.getKey();
			if (!newSubst.substitutionMap.containsKey(variable)) {
				newSubst.put(variable, entry.getValue());
			}
		}

		return newSubst;
	}

	public boolean isIdempotent(){
		ArrayList<Term> leftFound = new ArrayList<>();
		ArrayList<Term> rightFound = new ArrayList<>();
		for (Equality e : getEqualities()){
			Term left = e.getLeftTerm();
			Term right = e.getRightTerm();
			if (!left.equals(right)){
				leftFound.add(left);
				rightFound.add(right);
			}
		}
		for (Term t: leftFound){
			if (rightFound.contains(t)) return false;
		}
		return true;
	}

	private Term applyTo(Term term) {
        if (term instanceof Variable) {
			Variable variable = (Variable) term;
			variable.unbind();
			Term replacedTerm = this.substitutionMap.get(variable);
			return replacedTerm != null
					? replacedTerm.clone()
					: variable;
		}
		return term.clone();
	}

	private List<Term> applyToListOfTerms(List<Term> terms) {
		List<Term> res = new ArrayList<Term>();
		for (Term t : terms){
			res.add(applyTo(t));
		}
		return res;
	}

	public OntologyPredicateAtom applyToOntologyPredicateAtom(OntologyPredicateAtom opa) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		return new OntologyPredicateAtom(opa.getPredicateIRI(), applyToListOfTerms(opa.getTerms()));
	}

	public Set<OntologyPredicateAtom> applyToSetOfOntologyPredicateAtoms(Set<OntologyPredicateAtom> oldSet) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		Set<OntologyPredicateAtom> res = new HashSet<>();
		for (OntologyPredicateAtom opa : oldSet){
			res.add(new OntologyPredicateAtom(opa.getPredicateIRI(), applyToListOfTerms(opa.getTerms())));
		}
		return res;
	}

    public OntologyConjunctiveQuery applyToOntologyConjunctiveQuery(OntologyConjunctiveQuery cq) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		Set<OntologyPredicateAtom> bodyPredicateAtoms = new HashSet<>();
		for (Atom a : cq.getAtoms()){
			if (a instanceof OntologyPredicateAtom) bodyPredicateAtoms.add((OntologyPredicateAtom) a);
		}
		return new OntologyConjunctiveQuery(applyToSetOfOntologyPredicateAtoms(bodyPredicateAtoms), applyToUQV(cq.getFreeVariables()));
    }

    public ArrayList<Variable> applyToUQV(ArrayList<Variable> freeVariables) {
		ArrayList<Variable> res = new ArrayList<>();
		for (Variable v : freeVariables){
			Term t = applyTo(v);
			if (t instanceof Variable){
				Variable newv = (Variable) t;
				if(!res.contains(newv)) res.add(newv);
			}
		}
		return res;
	}

	public EpistemicDependency applyToED(EpistemicDependency ed) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		OntologyConjunctiveQuery newBody = applyToOntologyConjunctiveQuery(ed.getBody());
		OntologyConjunctiveQuery newHead = applyToOntologyConjunctiveQuery(ed.getHead());
		ArrayList<Variable> newUQV = applyToUQV(ed.getUniversallyQuantifiedVariables());
		if(newHead.getBody().isEmpty()){
			OntologyConjunctiveQuery finalHead = new OntologyConjunctiveQuery(new HashSet<>(Arrays.asList(new False())), newUQV);
			return new EpistemicDependency(newBody, finalHead, newUQV);
		}
		return new EpistemicDependency(newBody, newHead, newUQV);
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Substitution))
			return false;
		Substitution otherSubst = (Substitution) o;
		if (this.substitutionMap.size() != otherSubst.substitutionMap.size()){
			return false;
		}
		for (Map.Entry<Variable, Term> entry : otherSubst.substitutionMap.entrySet()) {
			Variable variable = entry.getKey();
			Term term = entry.getValue();
			if (!this.substitutionMap.containsKey(variable) ||
					!this.substitutionMap.get(variable).equals(term)) {
				return false;
			}
		}
		return true;
	}

	@Override
	public String toString() {
		return substitutionMap.toString();
	}
}