package igaedrewriter.policy;

import igaedrewriter.fol.*;
import igaedrewriter.util.Utils;

import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * A conjunctive query is of the form:
 * 	{@code Q() :- C(x), R(x, y), J(x, "abc") .}<br>
 * with:
 * <ul>
 *  <li> {@link PredicateAtom predicate atoms}   = {@code { C(x), R(x, y), J(x, "abc") }}
 *  <li> {@link Variable variables} = {@code { x, y }}
 *  <li> {@link Constant constants} = {@code { "abc" }}
 * </ul>
 * It may also contain inequalities, e.g., "{@code T(x,a), T(x,b), T(x,c), a != b, a != c, b != c}".
 */
public class ConjunctiveQuery implements Cloneable {
	protected FlatConjunction body = new FlatConjunction();
	protected List<Variable> freeVariables; //unbound
	
	public ConjunctiveQuery(Collection<? extends Atom> atoms, List<Variable> freeVariables) {
		this.body.addAll(atoms);
		this.freeVariables = freeVariables;
		bindVariablesToQuery();
	}
	
	private void bindVariablesToQuery() {
		this.body.bindVariablesToQuery(this);
	}
	
	/**
	 * This method returns all the CQ atoms.
	 */
	public Set<Atom> getAtoms() {
		return this.body.getAtoms();
	}
	
	/**
	 * This method returns a {@link Conjunction conjunction} of all the CQ atoms.
	 */
	public Conjunction getBody() {
		return this.body.unflat();
	}

	public FlatConjunction getBodyAsFlatConjunction() {
		return this.body.clone();
	}

	//returns unbound variables
	public ArrayList<Variable> getFreeVariables(){
		ArrayList<Variable> res = new ArrayList<>();
		for (Variable v : freeVariables){
			Variable v1 = v.clone();
			v1.unbind();
			res.add(v1);
		}
		return res;
	}
	
	public void explicitNondistinguishedNonsharedVariables() {
		explicitNondistinguishedNonsharedVariables(null);
	}

	/**
	 * This method make all the variables explicit according to a given alphabet.<br>
	 * E.g., {@code A(x,_), B(_,y) -> A(x,z), B(w,y)}
	 * @param alphabet A set of allowed variable names.
	 */
	public void explicitNondistinguishedNonsharedVariables(Set<String> alphabet) {
		explicitNondistinguishedNonsharedVariables(alphabet, new HashSet<>());
	}
	
	/**
	 * This method make all the variables explicit according to a given alphabet.<br>
	 * E.g., {@code A(x,_), B(_,y) -> A(x,z), B(w,y)}
	 * @param alphabet A set of allowed variable names.
	 */
	public void explicitNondistinguishedNonsharedVariables(Set<String> alphabet, Collection<String> reservedNames) {
		if (alphabet == null) alphabet = Formula.LC_LATIN_ALPHABET;
		assert !alphabet.isEmpty();
		
		Set<String> reservedNamesSet = new HashSet<>(reservedNames);
		reservedNamesSet.addAll(getVariables()
				.stream()
				.map(Variable::getName)
				.collect(Collectors.toSet()));
		
		this.body.explicitVariables(alphabet, reservedNamesSet);
	}
	
	/**
	 * This method returns ALL the CQ's {@link PredicateAtom predicate atoms},
	 * regardless of whether they are (or are not) part of a number restriction.
	 */
	public Set<? extends PredicateAtom> getPredicateAtoms() {
		return Utils.filterByClass(getAtoms(), PredicateAtom.class, Collectors.toSet());
	}

	public Set<OntologyPredicateAtom> getOntologyPredicateAtoms() {
		return Utils.filterByClass(getAtoms(), OntologyPredicateAtom.class, Collectors.toSet());
	}
	
	/**
	 * This method returns all the CQ's {@link InequalityAtom inequalities}.
	 */
	public Set<InequalityAtom> getInequalities() {
		return this.body.getInequalities();
	}
	
	@SuppressWarnings("unused")
	public Set<PredicateAtom> getPredicateAtomsByPredicate(String predicateIdentifier) {
		return getPredicateAtoms().stream()
				.filter(a -> a.getPredicateIdentifier().equals(predicateIdentifier))
				.map(PredicateAtom::clone)
				.collect(Collectors.toSet());
	}
	
	/**
	 * This method checks if the CQ contains or not a given predicate.
	 * @return {@code true} if at least one of the CQ atoms have the specified predicate, {@code false} otherwise.
	 */
	public boolean hasPredicate(String predicateIdentifier) {
		for (PredicateAtom a : getPredicateAtoms()) {
			if (a.getPredicateIdentifier().equals(predicateIdentifier)) return true;
		}
		return false;
	}
	
	public void replaceVariable(Variable oldVar, Variable newVar) {
		this.body.replaceVariables(Collections.singletonMap(oldVar, newVar));
		ArrayList<Variable> freeVariables = this.getFreeVariables();
		if (freeVariables.contains(oldVar)){
			this.freeVariables.remove(oldVar);
			this.freeVariables.add(newVar);
		}
	}
	
	/**
	 * This method returns all the variables used by the CQ atoms.
	 * @return A {@link Set set} of {@link Variable variables}.
	 */
	public ArrayList<Variable> getVariables() {
		ArrayList<Variable> variables = new ArrayList<>();
		for (Atom a : getAtoms()){
			for (Variable v : a.getVariables()){
				if(!variables.contains(v)) variables.add(v);
			}
		}
		return variables;
	}

	public Collection<? extends Term> getConstants() {
		ArrayList<Constant> constants = new ArrayList<>();
		getAtoms().stream()
				.map(Atom::getConstants)
				.forEach(constants::addAll);
		return constants;
	}
	
	public boolean isInconsistent() {
		return new FlatConjunction(getAtoms()).isContradiction();
	}

	@Override
	public String toString() {
		List<String> atomStrings = getAtoms().stream()
				.map(Atom::toString)
				.collect(Collectors.toList());
		ArrayList<Variable> quantifiedVariables = this.getQuantifiedVariables();
		return "Q(" + getFreeVariables().toString() + ") :- " + String.join(", ", atomStrings) + ".";
	}

	public ArrayList<Variable> getQuantifiedVariables() {
		ArrayList<Variable> allVariables = Utils.unbindArrayList(getVariables());
		ArrayList<Variable> freeVariables = getFreeVariables();
		allVariables.removeAll(freeVariables);
		return allVariables;
	}

	@Override
	public ConjunctiveQuery clone() {
		try {
			super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e);
		}
		Collection<Atom> atoms = getAtoms();
		atoms.forEach(Formula::unbindVariables);
		ArrayList<Variable> freeVariables = getFreeVariables();
		return new ConjunctiveQuery(atoms,freeVariables);
	}
	
	/**
	 * Two CQs are equal if they are the same object.<br>
	 * This is fundamental, since two variables must be bound to the same query for being considered equal.<br>
	 * Furthermore, inspecting CQ content in this method may cause a stack-overflow error.
	 */
	@Override
	public int hashCode() {
		return super.hashCode();
	}
	
	/*/**
	 * Two CQs are equal if they are the same object.<br>
	 * This is fundamental, since two variables must be bound to the same query for being considered equal.<br>
	 * Furthermore, inspecting CQ content in this method may cause a stack-overflow error.
	 */
	@Override
	public boolean equals(Object o) {
		return super.equals(o);
	}
}
