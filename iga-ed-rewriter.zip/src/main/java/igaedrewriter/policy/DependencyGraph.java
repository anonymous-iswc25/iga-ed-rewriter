package igaedrewriter.policy;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.parameters.Imports;
import igaedrewriter.fol.*;

import java.io.IOException;
import java.util.Set;
import java.util.*;

import org.semanticweb.owlapi.model.*;


public class DependencyGraph implements Cloneable {
    Set<String> nodes;
    Set<Edge> edges;

    public DependencyGraph(Set<String> nodes, Set<Edge> edges){
        this.nodes = nodes;
        this.edges = edges;
    }

    public DependencyGraph(Set<EpistemicDependency> policySet, OWLOntology TBox) throws IOException {
        Set<String> nodes = new HashSet<String>();
        Set<Edge> edges = new HashSet<Edge>();
        for (EpistemicDependency ed : policySet){
            Set<? extends PredicateAtom> bodyPredicateAtoms = ed.getBody().getPredicateAtoms();
            Set<? extends PredicateAtom> headPredicateAtoms = ed.getHead().getPredicateAtoms();
            Set<String> predicatesInBody = new HashSet<String>();
            for (PredicateAtom pa : bodyPredicateAtoms){
                predicatesInBody.add(pa.getPredicateName());
            }
            Set<String> predicatesInHead = new HashSet<String>();
            for (PredicateAtom pa : headPredicateAtoms){
                predicatesInHead.add(pa.getPredicateName());
            }
            //Create nodes
            nodes.addAll(predicatesInBody);
            nodes.addAll(predicatesInHead);
            //Create edges
            for (String hp : predicatesInHead){
                for (String bp : predicatesInBody){
                    Edge e = new Edge(bp, hp, Edge.EdgeType.P_EDGE);
                    edges.add(e);
                }
            }
        }
        for (OWLAxiom a: TBox.getAxioms(Imports.EXCLUDED)){
            if(a.getAxiomType().equals(AxiomType.SUBCLASS_OF)){
                OWLSubClassOfAxiom axiom = (OWLSubClassOfAxiom) a;
                OWLClassExpression subExpression = axiom.getSubClass();
                OWLClassExpression superExpression = axiom.getSuperClass();
                Set<OWLEntity> subEntities = getEntities(subExpression);
                Set<OWLEntity> superEntities = getEntities(superExpression);
                for (OWLEntity e1 : subEntities){
                    for (OWLEntity e2 : superEntities){
                        String included = e1.getIRI().toString();
                        String includer = e2.getIRI().toString();
                        int i1 = included.indexOf("#");
                        int i2 = includer.indexOf("#");
                        included = included.substring(i1+1);
                        includer = includer.substring(i2+1);
                        nodes.add(includer);
                        nodes.add(included);
                        edges.add(new Edge(included, includer, Edge.EdgeType.T_EDGE));
                    }
                }
            }
            else if(a.getAxiomType().equals(AxiomType.SUB_OBJECT_PROPERTY)){
                OWLSubObjectPropertyOfAxiom axiom = (OWLSubObjectPropertyOfAxiom) a;
                OWLPropertyExpression subExpression = axiom.getSubProperty();
                OWLPropertyExpression superExpression = axiom.getSuperProperty();
                Set<OWLEntity> subEntities = getEntities(subExpression);
                Set<OWLEntity> superEntities = getEntities(superExpression);
                for (OWLEntity e1 : subEntities){
                    for (OWLEntity e2 : superEntities){
                        String included = e1.getIRI().toString();
                        String includer = e2.getIRI().toString();
                        int i1 = included.indexOf("#");
                        int i2 = includer.indexOf("#");
                        included = included.substring(i1+1);
                        includer = includer.substring(i2+1);
                        nodes.add(includer);
                        nodes.add(included);
                        edges.add(new Edge(included, includer, Edge.EdgeType.T_EDGE));
                    }
                }
            }
        }
        this.nodes = nodes;
        this.edges = edges;
    }

    //Returns classes and object properties (i.e. predicates) found in the input expression
    private Set<OWLEntity> getEntities(OWLObject expression) {
        Set<OWLEntity> res = new HashSet<OWLEntity>();
        res.addAll(expression.getClassesInSignature());
        res.addAll(expression.getObjectPropertiesInSignature());
        //Remove the class Thing
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLDataFactory factory = manager.getOWLDataFactory();
        OWLClass thingClass = factory.getOWLThing();
        res.remove(thingClass);
        return res;
    }

    public Set<String> getNodes(){
        Set<String> toReturn = new HashSet<String>();
        toReturn.addAll(nodes);
        return toReturn;
    }

    public Set<Edge> getEdges(){
        Set<Edge> toReturn = new HashSet<Edge>();
        toReturn.addAll(edges);
        return toReturn;
    }

    public Boolean isPolicyAcyclic(){
        Set<Set<String>> scc = tarjan(); //Computes strongly connected components
        //An edge belongs to a cycle iff it has source and target in the scc
        for (Edge e : getEdges()){
            if (e.getType().equals(Edge.EdgeType.P_EDGE)){
                for (Set<String> component : scc){
                    if (component.contains(e.getSource()) && component.contains(e.getTarget())) return false;
                }
            }
        }
        return true;
    }

    //Returns the set of connected components
    private Set<Set<String>> tarjan(){
        Set<Set<String>> result = new HashSet<>();
        List<Integer> index = new ArrayList<>(); //"Integer index = 0" it is not correctly updated through the recursive calls
        index.add(0);
        List<String> stack = new ArrayList<String>();
        Map<String, Integer> indexes = new HashMap<String, Integer>();
        Map<String, Integer> lowLink = new HashMap<String, Integer>();
        Set<String> onStack = new HashSet<String>();
        for (String node : getNodes()){
            if(!indexes.containsKey(node)){
                strongConnect(node, index, indexes, lowLink, stack, onStack, result);
                }
        }
        return result;
    }

    private void strongConnect(String node, List<Integer> indexArray, Map<String, Integer> indexes, Map<String, Integer> lowLink, List<String> stack, Set<String> onStack, Set<Set<String>> result){
        Integer index = indexArray.get(0);
        indexes.put(node, index);
        lowLink.put(node, index);
        indexArray.remove(index);
        indexArray.add(index+1);
        stack.add(stack.size(), node);
        onStack.add(node);

        for (Edge e : getOutgoingEdges(node)) {
            String neighbour = e.getTarget();
            if (!indexes.containsKey(neighbour)) {
                strongConnect(neighbour, indexArray, indexes, lowLink, stack, onStack, result);
                lowLink.replace(node, Math.min(lowLink.get(node), lowLink.get(neighbour)));
            } else if (onStack.contains(neighbour)) {
                lowLink.replace(node, Math.min(lowLink.get(node), indexes.get(neighbour)));
            }
        }

        if (lowLink.get(node).equals(indexes.get(node))){
            Set<String> component = new HashSet<String>();
            while (true){
                String n = stack.get(stack.size()-1);
                stack.remove(stack.size()-1);
                onStack.remove(n);
                component.add(n);
                if(node.equals(n)) break;
            }
            result.add(component);
        }
    }

    private Set<Edge> getOutgoingEdges(String node) {
        Set<Edge> incomingEdges = new HashSet<Edge>();
        for (Edge e : getEdges()){
            if(e.getSource().equals(node)) incomingEdges.add(e);
        }
        return incomingEdges;
    }

    private Set<Edge> getIncomingEdges(String node) {
        Set<Edge> incomingEdges = new HashSet<Edge>();
        for (Edge e : getEdges()){
            if(e.getTarget().equals(node)) incomingEdges.add(e);
        }
        return incomingEdges;
    }

    public DependencyGraph clone(){
        try {
            super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
        return new DependencyGraph(getNodes(), getEdges());
    }

    public int hashCode(){
        return Objects.hash(nodes, edges);
    }

    public boolean equals(Object o){
        if (this == o){return true;}
        if (o == null){return false;}
        if (this.getClass() != o.getClass()){return false;}
        DependencyGraph dg = (DependencyGraph) o;
        return getNodes().equals(dg.getNodes()) &&
                getEdges().equals(dg.getEdges());
    }
}
