package igaedrewriter.policy;


import java.io.IOException;
import java.util.Objects;

public class Edge {
    final String source;
    final String target;
    final EdgeType type;

    public enum EdgeType{
        P_EDGE, //policy edge
        T_EDGE  //tbox edge
    }

    Edge(String source, String target, EdgeType type) throws IOException{
        if (!type.equals(EdgeType.P_EDGE) && !type.equals(EdgeType.T_EDGE)){
            throw new IOException("Edge type must be 'P_EDGE' or 'T_EDGE'.");
        }
        this.source = source;
        this.target = target;
        this.type = type;
    }

    public String getSource(){
        return source;
    }

    public String getTarget(){
        return target;
    }

    public EdgeType getType(){
        return type;
    }

    public Edge clone(){
        try{
            super.clone();
        } catch (CloneNotSupportedException e){
            throw new RuntimeException(e);
        }
        try {
            return new Edge(source, target, type);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //two edges with same root, target and type are considered the same
    public int hashCode(){
        return Objects.hash(source, target, type);
    }

    public boolean equals(Object o){
        if (this == o){return true;}
        if (o == null){return false;}
        if (this.getClass() != o.getClass()){return false;}
        Edge e = (Edge) o;
        return getSource().equals(e.getSource()) &&
                getTarget().equals(e.getTarget()) &&
                getType().equals(e.getType());
    }

    public String toString(){
        if(getType().equals(EdgeType.P_EDGE)) return "P-edge from " + getSource() + " to " + getTarget();
        else return "T-edge from " + getSource() + " to " + getTarget();
    }

}



