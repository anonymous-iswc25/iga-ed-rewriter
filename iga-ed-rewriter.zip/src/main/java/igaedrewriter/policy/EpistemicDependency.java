package igaedrewriter.policy;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import igaedrewriter.fol.*;

import java.net.URISyntaxException;
import java.util.*;

import igaedrewriter.util.Utils;
import uk.ac.manchester.cs.owl.owlapi.*;

import static igaedrewriter.util.Utils.unbindList;

public class EpistemicDependency implements Cloneable{
    protected OntologyConjunctiveQuery body;
    protected OntologyConjunctiveQuery head;
    protected ArrayList<Variable> universallyQuantifiedVariables; //unbind
    public static String IND_AUX_PRED_NAME = "IndAux";

    public EpistemicDependency(OntologyConjunctiveQuery body, OntologyConjunctiveQuery head, ArrayList<Variable> universallyQuantifiedVariables){
        checkArgumentsValidity(body, head, universallyQuantifiedVariables);
        this.body = body;
        this.head = head;
        this.universallyQuantifiedVariables = universallyQuantifiedVariables;
    }

    private void checkArgumentsValidity(ConjunctiveQuery body, ConjunctiveQuery head, ArrayList<Variable> universallyQuantifiedVariables) {
        if (universallyQuantifiedVariables.equals(body.getFreeVariables()) && universallyQuantifiedVariables.equals(head.getFreeVariables()) ){
            return;
        }
        else{
            throw new IllegalArgumentException("Please use the same free variables in body and head.");
        }
    }

    public OntologyConjunctiveQuery getBody(){return this.body.clone();}

    public OntologyConjunctiveQuery getHead(){return this.head.clone();}

    public ArrayList<Variable> getUniversallyQuantifiedVariables(){
        ArrayList<Variable> res = new ArrayList<>();
        res.addAll(this.universallyQuantifiedVariables);
        return res;}

    public boolean isFull() {
        if (getUniversallyQuantifiedVariables().containsAll(Utils.unbindArrayList(getHead().getVariables()))) return true;
        return false;
    }

    public boolean isLinear(){
        if(getBody().getAtoms().size() == 1 && getHead().getAtoms().size()<2) return true;
        return false;
    }

    public EpistemicDependency createCorrespondingTGD(String ontologyIri) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        OntologyConjunctiveQuery oldHead = getHead();
        OntologyConjunctiveQuery oldBody = getBody();
        //TGD body
        Collection<Atom> atoms = oldBody.getAtoms();
        for (Variable v : oldBody.getFreeVariables()) {
            List<Variable> terms = new ArrayList<>();
            terms.add(v);
            OntologyPredicateAtom ind = new OntologyPredicateAtom(ontologyIri + "#" + IND_AUX_PRED_NAME, terms);
            atoms.add(ind);
        }
        OntologyConjunctiveQuery newBody = new OntologyConjunctiveQuery(atoms, Utils.unbindArrayList(oldBody.getFreeVariables()));
        return new EpistemicDependency(newBody, oldHead, getUniversallyQuantifiedVariables());
    }

    //Takes in input a TGD
    public OWLAxiom toOWLAxiom() {
        OntologyConjunctiveQuery head = getHead();
        if (headContainsRole() && head.getQuantifiedVariables().isEmpty()){ //role inclusion
            if(head.getOntologyPredicateAtoms().iterator().next().getType().equals(OntologyPredicateAtom.Type.ROLE)){
                return turnToSubObjectPropertyAxiom();
            }
            else{
                return turnToSubDataPropertyAxiom();
            }
        }
        else{ //class inclusion
            return turnToSubClassOfAxiom();
        }
    }

    private OWLSubObjectPropertyOfAxiom turnToSubObjectPropertyAxiom() {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OntologyPredicateAtom bodyPredicate = getBody().getOntologyPredicateAtoms().iterator().next();
        OntologyPredicateAtom headPredicate = getHead().getOntologyPredicateAtoms().iterator().next();
        List<Term> bodyTerms = unbindList(bodyPredicate.getTerms());
        List<Term> headTerms = unbindList(headPredicate.getTerms());
        OWLObjectProperty bodyProperty = dataFactory.getOWLObjectProperty(IRI.create(bodyPredicate.getPredicateIRI()));
        OWLObjectProperty headProperty = dataFactory.getOWLObjectProperty(IRI.create(headPredicate.getPredicateIRI()));
        if(bodyTerms.equals(headTerms)){ //R ISA S
            return new OWLSubObjectPropertyOfAxiomImpl(bodyProperty, headProperty, new HashSet<>());
        }
        else{ //R ISA S-
            OWLObjectPropertyExpression superProperty = new OWLObjectInverseOfImpl(headProperty);
            return new OWLSubObjectPropertyOfAxiomImpl(bodyProperty, superProperty, new HashSet<>());
        }
    }

    private OWLSubDataPropertyOfAxiom turnToSubDataPropertyAxiom() {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OntologyPredicateAtom bodyPredicate = getBody().getOntologyPredicateAtoms().iterator().next();
        OntologyPredicateAtom headPredicate = getHead().getOntologyPredicateAtoms().iterator().next();
        OWLDataProperty bodyProperty = dataFactory.getOWLDataProperty(IRI.create(bodyPredicate.getPredicateIRI()));
        OWLDataProperty headProperty = dataFactory.getOWLDataProperty(IRI.create(headPredicate.getPredicateIRI()));
        //R ISA S (R IS S- does not exist for data properties)
        return new OWLSubDataPropertyOfAxiomImpl(bodyProperty, headProperty, new HashSet<>());
    }

    private OWLSubClassOfAxiom turnToSubClassOfAxiom() {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OntologyPredicateAtom bodyPredicate = getBody().getOntologyPredicateAtoms().iterator().next();
        OntologyPredicateAtom headPredicate = getHead().getOntologyPredicateAtoms().iterator().next();
        List<Term> bodyTerms = unbindList(bodyPredicate.getTerms());
        List<Term> headTerms = unbindList(headPredicate.getTerms());
        if (bodyTerms.size() == 1 && headTerms.size() == 1){ //C(x) -> D(x)
            OWLClass subClass = dataFactory.getOWLClass(IRI.create(bodyPredicate.getPredicateIRI()));
            OWLClass superClass = dataFactory.getOWLClass(IRI.create(headPredicate.getPredicateIRI()));
            return new OWLSubClassOfAxiomImpl(subClass, superClass, new HashSet<>());
        }
        else if (bodyTerms.size() == 1 && headTerms.size() == 2 && bodyTerms.get(0).equals(headTerms.get(0))){ //C(x) -> \exists y R(x,y)
            OWLClass subClass = dataFactory.getOWLClass(IRI.create(bodyPredicate.getPredicateIRI()));
            OWLObjectProperty headRole = dataFactory.getOWLObjectProperty(IRI.create(headPredicate.getPredicateIRI()));
            OWLClassExpression superClass = new OWLObjectSomeValuesFromImpl(headRole, dataFactory.getOWLThing());
            return new OWLSubClassOfAxiomImpl(subClass, superClass, new HashSet<>());
        }
        else if (bodyTerms.size() == 1 && headTerms.size() == 2 && bodyTerms.get(0).equals(headTerms.get(1))){ //C(x) -> \exists y R(y,x)
            OWLClass subClass = dataFactory.getOWLClass(IRI.create(bodyPredicate.getPredicateIRI()));
            OWLObjectProperty headRole = dataFactory.getOWLObjectProperty(IRI.create(headPredicate.getPredicateIRI()));
            OWLObjectPropertyExpression inverseOfHeadRole = headRole.getInverseProperty();
            OWLClassExpression superClass = new OWLObjectSomeValuesFromImpl(inverseOfHeadRole, dataFactory.getOWLThing());
            return new OWLSubClassOfAxiomImpl(subClass, superClass, new HashSet<>());
        }
        else if (bodyTerms.size() == 2 && headTerms.size() == 1 && headTerms.get(0).equals(bodyTerms.get(0))){ //\exists y R(x,y) -> C(x)
            OWLClass superClass = dataFactory.getOWLClass(IRI.create(headPredicate.getPredicateIRI()));
            OWLObjectProperty bodyRole = dataFactory.getOWLObjectProperty(IRI.create(bodyPredicate.getPredicateIRI()));
            OWLClassExpression subClass = new OWLObjectSomeValuesFromImpl(bodyRole, dataFactory.getOWLThing());
            return new OWLSubClassOfAxiomImpl(subClass, superClass, new HashSet<>());
        }
        else if (bodyTerms.size() == 2 && headTerms.size() == 1 && headTerms.get(0).equals(bodyTerms.get(1))){ //\exists y R(y,x) -> C(x)
            OWLClass superClass = dataFactory.getOWLClass(IRI.create(headPredicate.getPredicateIRI()));
            OWLObjectProperty bodyRole = dataFactory.getOWLObjectProperty(IRI.create(bodyPredicate.getPredicateIRI()));
            OWLObjectPropertyExpression inverseOfBodyRole = bodyRole.getInverseProperty();
            OWLClassExpression subClass = new OWLObjectSomeValuesFromImpl(inverseOfBodyRole, dataFactory.getOWLThing());
            return new OWLSubClassOfAxiomImpl(subClass, superClass, new HashSet<>());
        }
        ArrayList<Variable> uqvs = getUniversallyQuantifiedVariables();
        Variable uqv = new Variable("Temp");
        for (Variable v : uqvs){
            uqv = v;
        }
        OWLObjectProperty bodyRole = dataFactory.getOWLObjectProperty(IRI.create(bodyPredicate.getPredicateIRI()));
        OWLObjectProperty headRole = dataFactory.getOWLObjectProperty(IRI.create(headPredicate.getPredicateIRI()));
        OWLClassExpressionImpl subClass;
        OWLClassExpressionImpl superClass;
        if (uqv.equals(bodyTerms.get(0))){
            subClass = new OWLObjectSomeValuesFromImpl(bodyRole, dataFactory.getOWLThing());
        }
        else{
            OWLObjectPropertyExpression inverseOfBodyRole = bodyRole.getInverseProperty();
            subClass = new OWLObjectSomeValuesFromImpl(inverseOfBodyRole, dataFactory.getOWLThing());
        }
        if (uqv.equals(headTerms.get(0))){
            superClass = new OWLObjectSomeValuesFromImpl(headRole, dataFactory.getOWLThing());
        }
        else{
            OWLObjectPropertyExpression inverseOfHeadRole = headRole.getInverseProperty();
            superClass = new OWLObjectSomeValuesFromImpl(inverseOfHeadRole, dataFactory.getOWLThing());
        }
        return new OWLSubClassOfAxiomImpl(subClass, superClass, new HashSet<>());
    }

    private Boolean headContainsRole(){
        Set<? extends PredicateAtom> headPredicates = getHead().getPredicateAtoms();
        for (PredicateAtom predicate : headPredicates) {
            if (predicate.getTerms().size() > 1){
                return true;
            }
        }
        return false;
    }

    public EpistemicDependency removePredicateFromBody(String predicateName) throws Term.TermTypeException {
        return new EpistemicDependency(getBody().removePredicate(predicateName), getHead(), getUniversallyQuantifiedVariables());
    }

    public boolean isDenial() {
        if(getHead().containsOnlyFalse()) return true;
        return false;
    }

    @Override
    public EpistemicDependency clone() {
        try {
            super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
        OntologyConjunctiveQuery head = getHead();
        OntologyConjunctiveQuery body = getBody();
        ArrayList<Variable> universallyQuantifiedVariables = getUniversallyQuantifiedVariables();
        return new EpistemicDependency(body, head, universallyQuantifiedVariables);
    }

    public int hashCode(){
        return Objects.hash(body, head, universallyQuantifiedVariables);
    }

    public boolean equals(Object o){return super.equals(o);}

    public EpistemicDependency changeAllVariablesNames(String prefix) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        HashMap<Variable, Term> dict = new HashMap<>();
        if(prefix != null) {
            int i = 0;
            for (Variable v : getVariables()) {
                dict.put(v,new Variable(prefix + i));
                i++;
            }
        }
        else{
            Set<String> alphabet = new HashSet<>();
            for (char letter = 'a'; letter <= 'z'; letter++) {
                String s = "" + letter;
                alphabet.add(s);
            }
            Set<String> reservedNames = new HashSet<>();
            for (Variable v : getVariables()) {
                dict.put(v, Formula.getFreshVariable(alphabet, reservedNames, true));
            }
        }
        Substitution s = new Substitution(dict);
        return s.applyToED(this);
    }

    private ArrayList<Variable> getVariables() {
        ArrayList<Variable> res = new ArrayList<>();
        res.addAll(getUniversallyQuantifiedVariables());
        res.addAll(getExistentialVariables());
        return res;
    }

    public EpistemicDependency changeFreeVariablesNames(String prefix) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        ArrayList<Variable> newNames = new ArrayList<>();
        if(prefix != null) {
            for (int i = 0; i < getUniversallyQuantifiedVariables().size(); i++) {
                newNames.add(new Variable(prefix + i));
            }
        }
        else{
            Set<String> alphabet = new HashSet<>();
            for (char letter = 'a'; letter <= 'z'; letter++) {
                String s = "" + letter;
                alphabet.add(s);
            }
            Set<String> reservedNames = new HashSet<>();
            for (Variable v : getExistentialVariables()){
                reservedNames.add(v.getName());
            }
            for (int i = 0; i < getUniversallyQuantifiedVariables().size(); i++) {
                newNames.add(Formula.getFreshVariable(alphabet, reservedNames, true));
            }
        }
        return changeFreeVariablesNames(newNames);
    }

    private ArrayList<Variable> getExistentialVariables() {
        ArrayList<Variable> res = new ArrayList<>();
        res.addAll(getBody().getQuantifiedVariables());
        res.addAll(getHead().getQuantifiedVariables());
        return res;
    }

    private EpistemicDependency changeFreeVariablesNames(ArrayList<Variable> newNames) throws Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
        OntologyConjunctiveQuery newBody = getBody().changeFreeVariablesNames(newNames);
        OntologyConjunctiveQuery newHead = getHead().changeFreeVariablesNames(newNames);
        return new EpistemicDependency(newBody, newHead, newNames);
    }

    public String toString(){
        return "UQV: " + getUniversallyQuantifiedVariables().toString() + " BODY: " + getBody().toString() + " HEAD: " + getHead().toString();
    }

    public boolean isEquivalentTo(EpistemicDependency ed) {
        if (ed == null){return false;}
        int numberOfUQV = getUniversallyQuantifiedVariables().size();
        if (numberOfUQV != ed.getUniversallyQuantifiedVariables().size()) return false;
        ArrayList<Variable> newNames = new ArrayList<>();
        for (int i = 0; i < numberOfUQV; i++){
            newNames.add(new Variable("free" + i));
        }

        EpistemicDependency thatED;
        EpistemicDependency thisCopy;
        try {
            EpistemicDependency thisED = changeAllVariablesNames("this");
            thatED = ed.changeAllVariablesNames("that");
            thisCopy = thisED.changeFreeVariablesNames(newNames);
        } catch (Term.TermTypeException e) {
            throw new RuntimeException(e);
        } catch (PredicateAtom.PredicateArityException e) {
            throw new RuntimeException(e);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        List<List<Variable>> newNamesPermutations = Utils.permutations(newNames);
        for (List<Variable> p : newNamesPermutations){
            ArrayList<Variable> permutation = new ArrayList<>();
            for (Variable v : p) permutation.add(v);
            EpistemicDependency thatCopy = null;
            try {
                thatCopy = thatED.changeFreeVariablesNames(permutation);
            } catch (Term.TermTypeException e) {
                throw new RuntimeException(e);
            } catch (PredicateAtom.PredicateArityException e) {
                throw new RuntimeException(e);
            } catch (URISyntaxException e) {
                throw new RuntimeException(e);
            }

            FlatConjunction thisBody = thisCopy.getBody().getBodyAsFlatConjunction();
            thisBody.unbindVariables();
            FlatConjunction thatBody = thatCopy.getBody().getBodyAsFlatConjunction();
            thatBody.unbindVariables();
            FlatConjunction thisHead = thisCopy.getHead().getBodyAsFlatConjunction();
            thisHead.unbindVariables();
            FlatConjunction thatHead = thatCopy.getHead().getBodyAsFlatConjunction();
            thatHead.unbindVariables();
            ArrayList<FlatConjunction> thisArray = new ArrayList<>();
            thisArray.add(thisBody);
            thisArray.add(thisHead);
            ArrayList<FlatConjunction> thatArray = new ArrayList<>();
            thatArray.add(thatBody);
            thatArray.add(thatHead);
            if (FlatConjunction.impliesUnderSomeSubstitution(thisArray, thatArray) &&
                    FlatConjunction.impliesUnderSomeSubstitution(thatArray, thisArray)){
                return true;
            }
        }
        return false;
    }
}
