package igaedrewriter.policy;

import igaedrewriter.fol.*;
import igaedrewriter.fol.Term.TermTypeException;
import igaedrewriter.util.Utils;

import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

import static igaedrewriter.fol.OntologyPredicateAtom.Type.*;
import static igaedrewriter.fol.Term.Type.*;
import static igaedrewriter.util.Utils.setIntersection;

public class OntologyConjunctiveQuery extends ConjunctiveQuery {
	public OntologyConjunctiveQuery(Collection<? extends Atom> atoms, List<Variable> freeVariables) throws TermTypeException {
		super(atoms, freeVariables);
		variablesTypeCheck();
	}
	
	public boolean hasInequalities() {
		return this.getInequalities().size() > 0;
	}

	public Set<OntologyPredicateAtom> getAllPredicateAtoms() {
		return Utils.filterByClass(getAtoms(), OntologyPredicateAtom.class, Collectors.toSet());
	}

	public Set<OntologyPredicateAtom> getStandardPredicateAtoms() {
		return Utils.setDifference(getAllPredicateAtoms(), getPredicateAtomsJoiningInequalities());
	}
	
	public Set<OntologyPredicateAtom> getPredicateAtomsJoiningInequalities() {
		ArrayList<Variable> inequalityVariables = getInequalityVariables();
		return this.getAllPredicateAtoms().stream()
				.filter(a -> !Collections.disjoint(a.getVariables(), inequalityVariables))
				.collect(Collectors.toSet());
	}
	
	/**
	 * This method returns all the variables used in some comparison atom.<br>
	 * E.g., given a CQ {@code A(x), R(x,y), R(x,z), y\=z}, it returns {@code {y,z}}.
	 * @return A {@link Set set} of {@link Variable variables}.
	 */
	public ArrayList<Variable> getInequalityVariables() {
		ArrayList<Variable> inequalityVariables = new ArrayList<>();
		getInequalities().stream()
				.map(InequalityAtom::getVariables)
				.forEach(inequalityVariables::addAll);
		return inequalityVariables;
	}
	
	
	/**
	 * This method makes additional checks with respect to the language's syntactic ones:
	 * <ol>
	 *     <li> Every term appearing in a concept, in a role or in the first position of an attribute
	 *     must be an object variable or an object constant.
	 *     <li> Every term appearing in the second position of an attribute must be a data variable or a data constant.
	 * </ol>
	 * @throws TermTypeException if one of the above conditions is violated.
	 */
	private void variablesTypeCheck() throws TermTypeException {
		Set<Term> objectTerms = new HashSet<>();
		Set<Term> dataTerms = new HashSet<>();
		for (OntologyPredicateAtom a : getAllPredicateAtoms()) {
			a.getTerms().forEach(t->{if (t.getType()==OBJECT) objectTerms.add(t);});
			a.getTerms().forEach(t->{if (t.getType()==DATA)   dataTerms.add(t);});
		}
		// undistinguished non-shared variables may appear both in data and object position
		Set<Term> intersection = setIntersection(objectTerms, dataTerms).stream()
				.filter(t -> !(t instanceof Variable && ((Variable) t).isUndistinguishedNonShared()))
				.collect(Collectors.toSet());
		if (!intersection.isEmpty()) throw new RuntimeException();
		
		for (OntologyPredicateAtom atom : this.getAllPredicateAtoms()) {
			for (int index = 0; index < atom.getArity(); index++) {
				Term t = atom.getTerm(index);
				if (t.getType() == Term.Type.UNDEFINED)
					throw new RuntimeException();
				if ((index == 0 && t.getType() == DATA)
						|| (index == 1 && t.getType() == DATA   && atom.getType() == ROLE)
						|| (index == 1 && t.getType() == OBJECT && atom.getType() == ATTRIBUTE))
					throw new TermTypeException(String.format(
							"Wrong type for data/object constant/variables in the following atom: %s.",this));
			}
		}
	}
	
	public OntologyConjunctiveQuery changeFreeVariablesNames(String prefix) throws TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		ArrayList<Variable> newNames = new ArrayList<>();
		int i = 0;
		for (Variable v : getFreeVariables()){
			newNames.add(new Variable(prefix+i));
			i++;
		}
		Map<Variable, Term> map = new HashMap<>();
		i = 0;
		for (Variable v : getFreeVariables()){
			v.unbind();
			map.put(v,newNames.get(i));
			i = i+1;
		}
		Substitution s = new Substitution(map);
		Set<OntologyPredicateAtom> newOntologyPredicateAtoms = s.applyToSetOfOntologyPredicateAtoms(getAllPredicateAtoms());
		return new OntologyConjunctiveQuery(newOntologyPredicateAtoms, newNames);
	}


	public OntologyConjunctiveQuery changeFreeVariablesNames(ArrayList<Variable> newFreeVars) throws TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		if(containsOnlyFalse()) {
			Set<Atom> arg1 = new HashSet<>();
			arg1.add(new False());
			return new OntologyConjunctiveQuery(arg1, newFreeVars);
		}
		Set<String> alphabet = new HashSet<>();
		for (char letter = 'a'; letter <= 'z'; letter++) {
			String s = "" + letter;
			alphabet.add(s);
		}
		Set<String> reservedNames = new HashSet<>();
		for (Variable v : getQuantifiedVariables()){
			reservedNames.add(v.getName());
		}
		for (Variable qv : getQuantifiedVariables()){
			for (Variable fv : newFreeVars){
				if (qv.getName().equals(fv.getName())){
					Variable newqv = Formula.getFreshVariable(alphabet,reservedNames,true);
					newqv.bindToQuery(this);
					qv.bindToQuery(this);
					this.replaceVariable(qv, newqv);
				}
			}
		}
		Map<Variable, Term> map = new HashMap<>();
		int i = 0;
		for (Variable v : getFreeVariables()){
			v.unbind();
			map.put(v,newFreeVars.get(i));
			i = i+1;
		}
		Substitution s = new Substitution(map);
		Set<OntologyPredicateAtom> newOntologyPredicateAtoms = s.applyToSetOfOntologyPredicateAtoms(getAllPredicateAtoms());
		return new OntologyConjunctiveQuery(newOntologyPredicateAtoms, newFreeVars);
	}

	public boolean containsOnlyFalse() {
		Conjunction conjunction = getBody();
		Boolean containsOnlyFalse = true;
		for (Formula f : conjunction){
			if(!(f instanceof False)){
				containsOnlyFalse = false;
				break;
			}
		}
		return containsOnlyFalse;
	}

	public Formula toFormula(){
		Set<PredicateAtom> unboundPredicateAtoms = new HashSet<>();
		for (PredicateAtom pa: getPredicateAtoms()){
			pa.unbindVariables();
			unboundPredicateAtoms.add(pa);
		}
		if (getQuantifiedVariables().isEmpty()){
			return new Conjunction(unboundPredicateAtoms);
		}
		else{
			return new Exist(new Conjunction(unboundPredicateAtoms), getQuantifiedVariables());
		}
	}

	public String toSparql() {
		String triples = getAllPredicateAtoms().stream()
				.map(atom -> atom.toSparql() + ". ")
				.collect(Collectors.joining(" "));
		String filter = getInequalities().isEmpty() ? "" :
				String.format("FILTER (%s) ",
						getInequalities().stream()
								.map(InequalityAtom::toSparql)
								.collect(Collectors.joining(" && ")));
		if (getFreeUsedVariables().isEmpty()){
			return "ASK WHERE { " + triples + filter + "}";
		}
		else{
			String variablesToSelect = "";
			for (Variable v : getFreeUsedVariables()){
				variablesToSelect = variablesToSelect + "?" + v.getName() + " ";
			}
			return "SELECT " + variablesToSelect + "WHERE { " + triples + filter + "}";
		}
	}

	private ArrayList<Variable> getFreeUsedVariables() {
		ArrayList<Variable> res = new ArrayList<>();
		for (Variable v : getFreeVariables()){
			if (usedInBody(v)) res.add(v);
		}
		return res;
	}

	private boolean usedInBody(Variable v1) {
		for (OntologyPredicateAtom opa : getAllPredicateAtoms()){
			for (Variable v2 : opa.getVariables()){
				if (v1.getName().equals(v2.getName())) return true;
			}
		}
		return false;
	}

	public OntologyConjunctiveQuery removePredicate(String predicateName) throws TermTypeException {
		Set<PredicateAtom> newPredicates = new HashSet<>();
		for (PredicateAtom predicate : getPredicateAtoms()){
			if (!predicate.getPredicateName().equals(predicateName)){
				newPredicates.add(predicate);
			}
		}
		return new OntologyConjunctiveQuery(newPredicates, getFreeVariables());
	}
	
	@Override
	public OntologyConjunctiveQuery clone() {
		Collection<Atom> atoms = super.clone().getAtoms();
		ArrayList<Variable> freeVariables = super.clone().getFreeVariables();
		atoms.forEach(Formula::unbindVariables);
		try {
			return new OntologyConjunctiveQuery(atoms, freeVariables);
		} catch (TermTypeException e) {
			throw new RuntimeException(e);
		}
	}

    public OntologyConjunctiveQuery changeAllVariablesNames(String prefix) throws TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		HashMap<Variable, Term> dict = new HashMap<>();
		int i = 0;
		for (Variable v : getVariables()){
			Variable v1 = v.clone();
			v1.unbind();
			dict.put(v1, new Variable(prefix + i));
			i++;
		}
		Substitution s = new Substitution(dict);
		OntologyConjunctiveQuery res = s.applyToOntologyConjunctiveQuery(this);
		return res;
    }

    public OntologyConjunctiveQuery changeQuantifiedVariablesNames(String prefix) throws TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException {
		ArrayList<Variable> newNames = new ArrayList<>();
		int i = 0;
		for (Variable v : getQuantifiedVariables()){
			newNames.add(new Variable(prefix+i));
			i++;
		}
		Map<Variable, Term> map = new HashMap<>();
		i = 0;
		for (Variable v : getQuantifiedVariables()){
			v.unbind();
			map.put(v,newNames.get(i));
			i = i+1;
		}
		Substitution s = new Substitution(map);
		Set<OntologyPredicateAtom> newOntologyPredicateAtoms = s.applyToSetOfOntologyPredicateAtoms(getAllPredicateAtoms());
		return new OntologyConjunctiveQuery(newOntologyPredicateAtoms, getFreeVariables());
	}

    public static class UnsafePolicyException extends Exception {
		public UnsafePolicyException(String message) { super(message); }
		public UnsafePolicyException(Object object, String message) { super(String.format(
				"Found expression not allowed by the current policy language:\n\t%s\n%s", object.toString(), message));
		}
	}
}
