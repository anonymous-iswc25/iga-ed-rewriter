package igaedrewriter.util;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.model.parameters.Imports;
import igaedrewriter.Logger;
import igaedrewriter.fol.OntologyPredicateAtom;

import java.io.File;
import java.net.URISyntaxException;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class OntologyUtils {
	public static final String INVERSE_AUX_SUFFIX = "InverseAux";

	public static OWLOntology loadOntology(String ontologyFilePath) throws OWLOntologyCreationException {
		return OWLManager.createOWLOntologyManager()
				.loadOntologyFromOntologyDocument(new File(ontologyFilePath));
	}

	public static void prepareTBox(OWLOntology ontology) {
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		Set<OWLDataProperty> dataProperties = ontology.getDataPropertiesInSignature();
		OWLDataFactory dataFactory = manager.getOWLDataFactory();
		//Delete data properties
		for (OWLDataProperty dataProperty : dataProperties) {
			Set<OWLDataPropertyAxiom> referencingAxioms = ontology.getAxioms(dataProperty, Imports.INCLUDED);
			manager.removeAxioms(ontology, referencingAxioms);
			OWLDeclarationAxiom declarationAxiom = dataFactory.getOWLDeclarationAxiom(dataProperty);
			manager.removeAxiom(ontology,declarationAxiom);
		}
		OWLDataFactory factory = manager.getOWLDataFactory();
		for (OWLAxiom a : ontology.getAxioms()) {
			//rewrite equivalence between classes
			if (a instanceof OWLEquivalentClassesAxiom){
				OWLEquivalentClassesAxiom castedAxiom = (OWLEquivalentClassesAxiom) a;
				Set<OWLClassExpression> classExpressions = castedAxiom.getClassExpressions();
				for (OWLClassExpression expr1 : classExpressions) {
					for (OWLClassExpression expr2 : classExpressions) {
						if (!expr1.equals(expr2)) {
							OWLSubClassOfAxiom newAxiom = factory.getOWLSubClassOfAxiom(expr1, expr2);
							manager.addAxiom(ontology, newAxiom);
						}
					}
				}
			}
			//rewrite equivalence between object properties
			else if (a instanceof OWLEquivalentObjectPropertiesAxiom){
				OWLEquivalentObjectPropertiesAxiom castedAxiom = (OWLEquivalentObjectPropertiesAxiom) a;
				Set<OWLObjectPropertyExpression> props = castedAxiom.getProperties();
				for (OWLObjectPropertyExpression p1 : props) {
					for (OWLObjectPropertyExpression p2 : props) {
						if (!p1.equals(p2)) {
							OWLSubObjectPropertyOfAxiom newAxiom = factory.getOWLSubObjectPropertyOfAxiom(p1, p2);
							manager.addAxiom(ontology, newAxiom);
						}
					}
				}
			}
			//Rewrite symmetry between properties
			else if (a instanceof OWLSymmetricObjectPropertyAxiom){
				OWLSymmetricObjectPropertyAxiom castedAxiom = (OWLSymmetricObjectPropertyAxiom) a;
				OWLObjectPropertyExpression originalProperty = castedAxiom.getProperty();
				OWLObjectProperty inverseProperty = factory.getOWLObjectProperty(IRI.create(originalProperty.getNamedProperty().getIRI()+ INVERSE_AUX_SUFFIX));

				OWLDeclarationAxiom da = factory.getOWLDeclarationAxiom(inverseProperty);
				manager.addAxiom(ontology,da);
				OWLInverseObjectPropertiesAxiom axiom1 = factory.getOWLInverseObjectPropertiesAxiom(inverseProperty, originalProperty);
				OWLSubObjectPropertyOfAxiom axiom2 = factory.getOWLSubObjectPropertyOfAxiom(inverseProperty, originalProperty);
				manager.addAxiom(ontology, axiom1);
				manager.addAxiom(ontology, axiom2);
			}
		}
	}

	public static Set<String> getOntologyPredicates(OWLOntology ontology) {
		Set<String> predicates = new HashSet<>();
		ontology.getClassesInSignature()
				.forEach(c -> predicates.add(c.getIRI().toString()));
		ontology.getObjectPropertiesInSignature()
				.forEach(c -> predicates.add(c.getIRI().toString()));
		ontology.getDataPropertiesInSignature()
				.forEach(c -> predicates.add(c.getIRI().toString()));
		return predicates
				.stream()
				.map(p->explicitIRIPrefix(p, ontology))
				.collect(Collectors.toSet());
	}
	
	public static String getOntologyName(OWLOntology ontology) throws URISyntaxException {
		if (ontology.getOntologyID().getOntologyIRI().isPresent()) {
			return Utils.getLastURIPart(ontology.getOntologyID().getOntologyIRI().get().toString());
		}
		else {
			Logger.warn("Cannot obtain ontology name from OWL ontology.");
			return null;
		}
	}
	
	public static Map<String, Integer> getPredicateToArityMap(OWLOntology tbox) {
		Set<String> fullPredicates = getOntologyPredicates(tbox);
		Map<String, Integer> resultMap = new HashMap<>();
		for (String predicate : fullPredicates) {
			OntologyPredicateAtom.Type type = OntologyPredicateAtom.getType(predicate, tbox);
			resultMap.put(predicate, type == OntologyPredicateAtom.Type.CONCEPT ? 1 : 2);
		}
		return resultMap;
	}

	//"":"http...#"
	public static Map<String,String> getPrefixMap(OWLOntology ontology) {
		return Objects.requireNonNull(ontology.getOWLOntologyManager().getOntologyFormat(ontology))
				.asPrefixOWLOntologyFormat()
				.getPrefixName2PrefixMap();
	}
	
	/**
	 * @param pattern A String pattern including two "%s".
	 * @return A list of prefixes formatted according to the pattern.
	 */
	public static List<String> getStringPrefixes(OWLOntology ontology, String pattern) {
		return getPrefixMap(ontology).entrySet().stream().map(
				e -> String.format(pattern, e.getKey(), e.getValue())
		).collect(Collectors.toList());
	}
	
	public static String explicitIRIPrefix(String prefixedIri, OWLOntology ontology) {
		return explicitIRIPrefix(prefixedIri, getPrefixMap(ontology));
	}
	
	public static String explicitIRIPrefix(String prefixedIri, Map<String,String> prefixMap) {
		for(String k : prefixMap.keySet()) {
			prefixedIri = prefixedIri.replaceAll(k+"(?=\\w+)", prefixMap.get(k));
		}
		return prefixedIri;
	}
	
	public static String getPredicateNameFromIRI(String iri) {
		return IRI.create(iri).getShortForm();
	}
	
	// complementary to getPredicateNameFromIRI (i.e., it just removes the trailing name from the IRI, if one exists)
	public static String getPrefixIRI(String iri) {
		String name = getPredicateNameFromIRI(iri);
		if (iri.endsWith(name)) {
			return iri.substring(0, iri.lastIndexOf(name));
		}
		else throw new RuntimeException();
	}
	
	/*
	 * IRI regex pattern (claimed to be) compliant with RFC3987
	 * taken from https://stackoverflow.com/a/190405/4607733
	 */
	public static boolean isValidIRI(String iri) {
		String regexPattern = "(?i)^[a-z](?:[-a-z0-9+.])*:(?://(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:])*@)?(?:\\[(?:(?:(?:[0-9a-f]{1,4}:){6}(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3})|::(?:[0-9a-f]{1,4}:){5}(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3})|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3})|(?:(?:[0-9a-f]{1,4}:)?[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3})|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3})|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3})|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3})|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|v[0-9a-f]+\\.[-a-z0-9\\._~!\\$&'\\(\\)\\*\\+,;=:]+)\\]|(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}|(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=])*)(?::[0-9]*)?(?:/(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:@]))*)*|/(?:(?:(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!\\$&'\\(\\)\\*\\+,;=:@]))+)(?:\\/(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9\\._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:@]))*)*)?|(?:(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:@]))+)(?:/(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:@]))*)*|(?!(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:@])))(?:\\?(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:@])|[\\x{E000}-\\x{F8FF}\\x{F0000}-\\x{FFFFD}\\x{100000}-\\x{10FFFD}/?])*)?(?:#(?:(?:%[0-9a-f][0-9a-f]|[-a-z0-9._~\\x{A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}\\x{10000}-\\x{1FFFD}\\x{20000}-\\x{2FFFD}\\x{30000}-\\x{3FFFD}\\x{40000}-\\x{4FFFD}\\x{50000}-\\x{5FFFD}\\x{60000}-\\x{6FFFD}\\x{70000}-\\x{7FFFD}\\x{80000}-\\x{8FFFD}\\x{90000}-\\x{9FFFD}\\x{A0000}-\\x{AFFFD}\\x{B0000}-\\x{BFFFD}\\x{C0000}-\\x{CFFFD}\\x{D0000}-\\x{DFFFD}\\x{E1000}-\\x{EFFFD}!$&'()*+,;=:@])|[/?])*)?$";
		return iri!= null && Pattern.matches(regexPattern, iri);
	}

}
