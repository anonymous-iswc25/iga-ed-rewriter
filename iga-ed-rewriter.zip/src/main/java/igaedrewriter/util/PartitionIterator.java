package igaedrewriter.util;

import java.util.*;

/* Credits: Holger @ StackOverflow (https://stackoverflow.com/a/56444342) */

public final class PartitionIterator<T> implements Iterator<List<List<T>>> {
	
	private List<List<T>> nextPartition;
	private final List<T> elements = new ArrayList<>();
	private int blocks = 1;
	
	private final int[] s;
	private final int[] m;
	private final int n;
	
	public PartitionIterator(Collection<T> elements) {
		this.elements.addAll(elements);
		this.n = elements.size();
		this.s = new int[n];
		this.m = new int[n];
		init();
	}
	
	private void init() {
		if (n != 0) {
			Arrays.fill(s,0);
			Arrays.fill(m,0);
			for (int i = n - blocks + 1; i < n; ++i) {
				s[i] = m[i] = i - n + blocks;
			}
			loadPartition();
		}
	}
	
	@Override
	public boolean hasNext() {
		return nextPartition != null;
	}
	
	@Override
	public List<List<T>> next() {
		if (nextPartition == null) {
			throw new NoSuchElementException("No more partitions left.");
		}
		List<List<T>> partition = nextPartition;
		generateNextPartition();
		return partition;
	}
	
	private void loadPartition() {
		nextPartition = new ArrayList<>(blocks);
		for (int i = 0; i < blocks; ++i) {
			nextPartition.add(new ArrayList<>());
		}
		for (int i = 0; i < n; ++i) {
			nextPartition.get(s[i]).add(elements.get(i));
		}
	}
	
	private void generateNextPartition() {
		for (int i = n - 1; i > 0; --i) {
			if (s[i] < blocks - 1 && s[i] <= m[i - 1]) {
				s[i]++;
				m[i] = Math.max(m[i], s[i]);
				
				for (int j = i + 1; j < n - blocks + m[i] + 1; ++j) {
					s[j] = 0;
					m[j] = m[i];
				}
				for (int j = n - blocks + m[i] + 1; j < n; ++j) {
					s[j] = m[j] = blocks - n + j;
				}
				loadPartition();
				return;
			}
		}
		
		if (++blocks <= n) {
			init();
		}
		else {
			nextPartition = null;
		}
	}
}