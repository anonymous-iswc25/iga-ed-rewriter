package igaedrewriter.util;

import java.util.*;

import static java.util.Collections.swap;

public class PermutationIterator<E> implements Iterator<List<E>> {
	
	private final List<E> elements;
	private final int[] count;
	private boolean hasNext;
	
	public PermutationIterator(Collection<E> elements) {
		this.elements = new ArrayList<>(elements);
		this.count = new int[elements.size()];
		this.hasNext = true;
	}
	
	@Override
	public boolean hasNext() {
		return hasNext;
	}
	
	@Override
	public List<E> next() {
		if (!hasNext) {
			throw new NoSuchElementException();
		}
		
		List<E> result = new ArrayList<>(elements);
		int i = 0;
		while (i < elements.size()) {
			if (count[i] < i) {
				if (i % 2 == 0) {
					swap(elements, 0, i);
				}
				else {
					swap(elements, count[i], i);
				}
				count[i]++;
				return result;
			}
			else {
				count[i] = 0;
				i++;
			}
		}
		
		hasNext = false;
		return result;
	}
	
	public static void main(String[] args) {
		List<Integer> set = Arrays.asList(1, 2, 3);
		PermutationIterator<Integer> iterator = new PermutationIterator<>(set);
		
		// Use iterator to get permutations
		while (iterator.hasNext()) {
			List<Integer> permutation = iterator.next();
			System.out.println(permutation);
		}
	}
}