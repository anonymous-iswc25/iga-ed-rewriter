import org.junit.Test;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import igaedrewriter.Configuration;
import igaedrewriter.Logger;
import igaedrewriter.TreeWitnessClient;
import igaedrewriter.db.SQLConnection;
import igaedrewriter.fol.PredicateAtom;
import igaedrewriter.fol.Term;
import igaedrewriter.policy.OntologyConjunctiveQuery;
import igaedrewriter.util.OntologyUtils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TreeWitnessTest {
	private static Configuration conf;
	
	private static void setConfiguration() throws SQLException, SQLConnection.DriverNotFoundException {
		try {
			conf = new Configuration("src/test/resources/owl2bench/config.ini");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		// SQLConnection.testConnection(conf);
	}
	
	@Test
	public void queryAnsweringTest() throws OWLOntologyCreationException, SQLException, ClassNotFoundException, PredicateAtom.PredicateArityException, Term.TermTypeException, URISyntaxException {
		setConfiguration();
		OWLOntology ontology = OntologyUtils.loadOntology(conf.prependInputPath(conf.ontologyFilename));
		String sparql = "SELECT DISTINCT ?s ?c WHERE {" +
				"?s rdf:type :Student. " +
				"?x rdf:type :Organization. " +
				"?x :hasDean ?z. " +
				"?z :teachesCourse ?c. " +
				"?s :takesCourse ?c " +
				"}";
		Collection<OntologyConjunctiveQuery> UCQ = TreeWitnessClient.rewriteQuery(sparql, ontology, true);
		for (OntologyConjunctiveQuery qr : UCQ) {
			Logger.info(qr);
		}
		assertEquals(4, UCQ.size());
	}
}
