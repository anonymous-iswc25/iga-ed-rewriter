package db;

import igaedrewriter.Configuration;
import igaedrewriter.db.SQLConnection.DriverNotFoundException;
import igaedrewriter.db.Table;
import igaedrewriter.util.Tuple;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;

import static db.SQLTestUtils.*;

public class SQLTestCases {
	
	// remember last initialization in the current execution, so that the same test case is not initialized twice in a row
	private static int LAST_TEST_CASE = -1;
	private static final int TEST_CASE_1 = 1;
	private static final int TEST_CASE_2 = 2;
	
	private static final String SQL_VARCHAR_50 = "VARCHAR(50)";
	private static final String SQL_INTEGER = "INTEGER";
	
	public static void initTestCase1() {
		if (LAST_TEST_CASE == TEST_CASE_1) return;
		else LAST_TEST_CASE = TEST_CASE_1;
		
		try {
			Configuration config = new Configuration("src/test/resources/dummy-ontology/config.ini");
			SQLTestUtils.createConnection(config);
			
			Table tableA = defaultTable("A", 1, SQL_INTEGER);
			initTable(tableA,
					new Tuple(1),
					new Tuple(2)
			);
			
			Table tableB = defaultTable("B", 1, SQL_INTEGER);
			initTable(tableB,
					new Tuple(2),
					new Tuple(3)
			);
			
			Table tableC = defaultTable("C", 1, SQL_INTEGER);
			initTable(tableC,
					new Tuple(1),
					new Tuple(4)
			);
			
			Table tableR = defaultTable("R", 2, SQL_INTEGER);
			initTable(tableR,
					new Tuple(1, 2),
					new Tuple(2, 3),
					new Tuple(4, null),
					new Tuple(null, 5),
					new Tuple(6, 6)
			);
			
			Table tableS = defaultTable("S", 2, SQL_INTEGER);
			initTable(tableS,
					new Tuple(2, 7),
					new Tuple(3, 3)
			);
			
			Table tableT = defaultTable("T", 2, SQL_INTEGER);
			initTable(tableT);
			
			Table tableW = defaultTable("W", 3, SQL_INTEGER);
			initTable(tableW);
		}
		catch(SQLException | IOException | DriverNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static void initTestCase2() {
		if (LAST_TEST_CASE == TEST_CASE_2) return;
		else LAST_TEST_CASE = TEST_CASE_2;
		
		try {
			Configuration config = new Configuration("src/test/resources/dummy-ontology/config.ini");
			SQLTestUtils.createConnection(config);
			
			Table tableThing = defaultTable("Thing", 1, SQL_VARCHAR_50);
			initTable(tableThing);
			
			Table tableA = defaultTable("A", 1, SQL_VARCHAR_50);
			initTable(tableA,
					new Tuple(dummyObject("1")),
					new Tuple(dummyObject("2"))
			);
			
			Table tableB = defaultTable("B", 1, SQL_VARCHAR_50);
			initTable(tableB,
					new Tuple(dummyObject("2")),
					new Tuple(dummyObject("3"))
			);
			
			Table tableC = defaultTable("C", 1, SQL_VARCHAR_50);
			initTable(tableC,
					new Tuple(dummyObject("1")),
					new Tuple(dummyObject("4"))
			);
			
			Table tableR = defaultTable("R", 2, SQL_VARCHAR_50);
			initTable(tableR,
					new Tuple(dummyObject("1"), dummyObject("2")),
					new Tuple(dummyObject("2"), dummyObject("3")),
					new Tuple(dummyObject("4"), dummyObject("7")),
					new Tuple(dummyObject("8"), dummyObject("5")),
					new Tuple(dummyObject("6"), dummyObject("6"))
			);
			
			Table tableS = defaultTable("S", 2, SQL_VARCHAR_50);
			initTable(tableS,
					new Tuple(dummyObject("2"), dummyObject("7")),
					new Tuple(dummyObject("3"), dummyObject("3"))
			);
			
			Table tableT = defaultTable("T", 2, SQL_VARCHAR_50);
			initTable(tableT);
			
			Table tableJ = defaultTable("J", 2, SQL_VARCHAR_50);
			initTable(tableJ);
			
			Table tableK = defaultTable("K", 2, SQL_VARCHAR_50);
			initTable(tableK);
		}
		catch(SQLException | IOException | DriverNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
	
	private static String dummyObject(String name) {
		return "http://example.org/my-ontology#" + name;
	}
	
	public static void initTable(Table table, Tuple... tuples) throws SQLException {
		dropAndCreate(table);
		insert(table, Arrays.asList(tuples));
	}
}