package db;

import igaedrewriter.Configuration;
import igaedrewriter.Logger;
import igaedrewriter.db.DBSchema;
import igaedrewriter.db.SQLCompiler;
import igaedrewriter.db.SQLConnection;
import igaedrewriter.db.SQLConnection.DriverNotFoundException;
import igaedrewriter.db.Table;
import igaedrewriter.fol.Exist;
import igaedrewriter.fol.Formula;
import igaedrewriter.fol.Variable;
import igaedrewriter.util.Tuple;
import util.TestUtils;

import java.sql.*;
import java.util.*;

import static igaedrewriter.fol.Formula.wrap;
import static util.TestUtils.conf;

public class SQLTestUtils {
	private final static String DROP_TABLE = "DROP TABLE IF EXISTS `%s`";
	private final static String CREATE_TABLE = "CREATE TABLE `%s` (%s);";
	private final static String INSERT = "INSERT INTO `%s` VALUES %s";
	
	private static Connection conn;
	
	private static Connection getConnection() throws SQLException {
		if (conn == null) throw new SQLException(String.format("Unable to establish connection. Please ensure the method %s#createConnection have been previously (and correctly) invoked.",
				SQLTestUtils.class.toString()));
		else return conn;
	}
	
	public static void createConnection(Configuration c) throws SQLException, DriverNotFoundException {
		conn = new SQLConnection(c).getConnection();
	}
	
	public static void dropAndCreate(Table table) throws SQLException {
		Statement stmt = getConnection().createStatement();
		
		String tableName = table.getTableName();
		List<String> attributesAndTypes = new ArrayList<>();
		Map<String,String> attributeToType = table.getAttributeToType();
		for (String attributeName : attributeToType.keySet()) {
			String type = attributeToType.get(attributeName);
			attributesAndTypes.add(String.format("`%s` %s", attributeName, type));
		}
		
		Logger.debug("Dropping table `" + tableName + "`");
		stmt.executeUpdate(String.format(DROP_TABLE, tableName));
		Logger.debug("Creating table `" + tableName + "`");
		stmt.executeUpdate(String.format(CREATE_TABLE, tableName, String.join(", ", attributesAndTypes)));
	}
	
	public static void insert(String tableName, List<Tuple> tuples) throws SQLException {
		if (!tuples.isEmpty()) {
			int arity = tuples.get(0).size();
			List<String> phList = new ArrayList<>();
			for (int i = 0; i < arity; i++) phList.add("?");
			String placeholders = "(" + String.join(",", phList) + ")";
			PreparedStatement pstmt = getConnection().prepareStatement(String.format(INSERT, tableName, placeholders));
			for (Tuple tuple : tuples) {
				guessPreparedStatement(pstmt, tuple.toArray()).execute();
			}
		}
	}
	
	public static void insert(Table table, List<Tuple> tuples) throws SQLException {
		insert(table.getTableName(), tuples);
	}
	
	public static ResultSet select(String query) throws SQLException {
		Statement stmt = getConnection().createStatement();
		return stmt.executeQuery(query);
	}
	
	public static int count(String query) throws SQLException {
		Statement stmt = getConnection().createStatement();
		ResultSet result = stmt.executeQuery("SELECT COUNT(*) FROM (\n" + wrap(query) + "\n) countQuery");
		if (result.next()) {
			return Integer.parseInt(result.getString(1));
		}
		else throw new RuntimeException();
	}
	
	private static PreparedStatement guessPreparedStatement(PreparedStatement pstmt, Object... values) throws SQLException {
		for (int i=0; i<values.length;) {
			Object value = values[i++];
			if (value == null)                 pstmt.setNull(i, Types.NULL);
			else if (value instanceof Boolean) pstmt.setBoolean(i, (Boolean) value);
			else if (value instanceof Integer) pstmt.setInt(i, (Integer) value);
			else if (value instanceof String)  pstmt.setString(i, (String) value);
			else throw new RuntimeException("Class " + value.getClass() + " not supported yet.");
		}
		return pstmt;
	}
	
	public static List<Tuple> getStringTuples(ResultSet resultSet) throws SQLException {
		List<Tuple> stringTuples = new ArrayList<>();
		ResultSetMetaData rsmd = resultSet.getMetaData();
		int columnsNumber = rsmd.getColumnCount();
		while (resultSet.next()) {
			List<String> row = new ArrayList<>();
			for (int i = 1; i <= columnsNumber; i++) {
				row.add(resultSet.getString(i));
			}
			stringTuples.add(new Tuple(row.toArray()));
		}
		return stringTuples;
	}
	
	public static void printResultSet(ResultSet resultSet) throws SQLException {
		ResultSetMetaData rsmd = resultSet.getMetaData();
		int columnsNumber = rsmd.getColumnCount();
		boolean firstRow = true;
		while (resultSet.next()) {
			if (firstRow) {
				List<String> row = new ArrayList<>();
				int hyphenNum = 0;
				for (int i = 1; i <= columnsNumber; i++) {
					String colName = rsmd.getColumnName(i);
					row.add(colName);
					hyphenNum += colName.length() + 3;
				}
				System.out.println(String.join("\t", row));
				System.out.println(String.join("", Collections.nCopies(hyphenNum - 2, "-")));
				firstRow = false;
			}
			List<String> row = new ArrayList<>();
			for (int i = 1; i <= columnsNumber; i++) {
				row.add(resultSet.getString(i));
			}
			System.out.println(String.join("\t", row));
		}
	}
	
	public static DBSchema exampleSchema = new DBSchema("mydb",
			new HashSet<>(Arrays.asList(
					defaultTable("Thing", 1),
					defaultTable("A", 1),
					defaultTable("B", 1),
					defaultTable("C", 1),
					defaultTable("D", 1),
					defaultTable("E", 1),
					defaultTable("F", 1),
					defaultTable("J", 2),
					defaultTable("K", 2),
					defaultTable("L", 2),
					defaultTable("R", 2),
					defaultTable("S", 2),
					defaultTable("T", 2),
					defaultTable("W", 3)
			))
	);
	
	public static String defaultColName(int i, int arity) {
		assert i <= arity;
		return arity == 1 ? conf.columnNamePrefix : conf.columnNamePrefix + i;
	}
	
	public static Table defaultTable(String tableName, int arity) {
		List<String> colNames = new ArrayList<>();
		for (int i = 1; i <= arity; i++) {
			colNames.add(defaultColName(i, arity));
		}
		return new Table(tableName, colNames);
	}
	
	public static Table defaultTable(String tableName, int arity, String type) {
		return new Table(tableName, new LinkedHashMap<String, String>() {{
			for (int i = 1; i <= arity; i++) {
				put(defaultColName(i, arity), type);
			}
		}});
	}
	
	public static Table defaultTable(String tableName, int arity, List<String> types) {
		return new Table(tableName, new LinkedHashMap<String, String>() {{
			for (int i = 1; i <= arity; i++) {
				put(defaultColName(i, arity), types.get(i-1));
			}
		}});
	}
	
	public static String toSql(DBSchema schema, Formula f, boolean distinct, String... existentialVariables) throws SQLCompiler.SQLificationException {
		Variable[] vars = TestUtils.variablesArray(existentialVariables);
		return new SQLCompiler(schema).sqlify(vars.length == 0 ? f : new Exist(f, vars), new HashMap<>(), distinct);
	}
	
	public static String toSql(Formula f, boolean distinct, String... existentialVariables) throws SQLCompiler.SQLificationException {
		return toSql(exampleSchema, f, distinct, existentialVariables);
	}
	
	public static String toSql(Formula f, String... existentialVars) throws SQLCompiler.SQLificationException {
		return toSql(f, false, existentialVars);
	}
}