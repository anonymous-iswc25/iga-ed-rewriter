package db;

import org.junit.Test;
import igaedrewriter.Logger;
import igaedrewriter.db.SQLCompiler;
import igaedrewriter.fol.*;
import igaedrewriter.db.SQLCompiler.SQLificationException;
import igaedrewriter.util.Tuple;
import util.TestUtils;

import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

import static db.SQLTestUtils.*;
import static fol.FormulaTest.*;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SQLifierTest {
	
	private static final List<Tuple> falseResult = Collections.emptyList();
	private static final List<Tuple> trueResult = Collections.singletonList(new Tuple(true)); // for Boolean queries
	
	@SuppressWarnings("SameParameterValue")
	private Tuple nullTuple(int tupleLength) {
		return new Tuple(Collections.nCopies(tupleLength, null).toArray());
	}
	
	@Test
	public void test1() throws SQLificationException {
		PredicateAtom a1 = pa("R(x,y)");
		PredicateAtom a2 = pa("S(y,z)");
		PredicateAtom a3 = pa("T(w,z)");
		PredicateAtom a4 = pa("T(w,v)");
		PredicateAtom a5 = pa("A(y)");
		PredicateAtom a6 = pa("B(w)");
		PredicateAtom a7 = pa("C(t)");
		Equality eq = eq("x","y");
		ArrayList<Variable> existentialVariables = new ArrayList<>(TestUtils.variablesList("z", "w", "v", "t"));
		
		Formula f = new Exist(
				new Conjunction(
						a1, a2, a5, a6, a7,
						new Disjunction( a3, a4, eq )
				),
				existentialVariables
		);
		
		Logger.info(f);
		String query = toSql(f);
		Logger.debug(query);
	}
	
	@Test
	public void test2() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		PredicateAtom a1 = pa("R(x,y)");
		PredicateAtom a2 = pa("R(y,z)");
		Conjunction c = and(a1, a2);
		
		Logger.info(c);
		String query1 = toSql(c);
		testQuery(query1, Arrays.asList(
				new Tuple(1,2,3),
				new Tuple(6,6,6)
				), true
		);
		
		String query2 = toSql(c, "x", "z");
		testQuery(query2, Arrays.asList(
				new Tuple(2),
				new Tuple(6)
				), true
		);
		
		String query3 = toSql(c, "x", "y", "z");
		testQuery(query3, trueResult, true
		);
		
		Disjunction d = or(
				exist (c, "x", "y", "z"),
				exist (pa("R(v,v)"),"v"));
		
		Logger.info(d);
		String query4 = toSql(d);
		testQuery(query4, trueResult, true);
	}
	
	@Test
	public void test3() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		PredicateAtom a1 = pa("R(x,y)");
		Formula f = exist(or(
				and(a1, eq("y","5")),
				and(a1, eq("y","6")),
				and(a1, eq("y","7"))
		), "x");
		
		Logger.info(f);
		String query1 = toSql(f);
		testQuery(query1, Arrays.asList(
				new Tuple(5),
				new Tuple(6)
				), true
		);
	}
	
	@Test
	public void test4() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		Formula f = and(
				pa("A(x)"),
				pa("R(x,y)"),
				pa("B(y)"),
				or(pa("C(x)"), pa("S(x,y)"))
		);
		
		Logger.info(f);
		String query1 = toSql(f);
		testQuery(query1, Collections.singletonList(new Tuple(1, 2)), true);
	}
	
	@Test
	public void reflexiveAtomTest() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		Formula f = or(pa("S(x,x)"));
		
		Logger.info(f);
		String query1 = toSql(f, true);
		testQuery(query1, Collections.singletonList(
				new Tuple(3)
		), true);
	}
	
	@Test
	public void joinTest() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		Formula f = and(pa("R(x,y)"), pa("R(y,z)"));
		
		Logger.info(f);
		String query1 = toSql(f, true);
		testQuery(query1, Arrays.asList(
				new Tuple(1, 2, 3),
				new Tuple(6, 6, 6)
		), true);
	}
	
	@Test
	public void unionTest() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		Formula f = or(pa("S(x,y)"), pa("S(y,x)"));
		
		Logger.info(f);
		String query1 = toSql(f, true);
		testQuery(query1, Arrays.asList(
				new Tuple(2, 7),
				new Tuple(3, 3),
				new Tuple(7, 2)
		), true);
	}
	
	@Test
	public void multipleQuantificationTest() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		Formula f1 = pa("R(x,y)");
		Formula f2 = and(
				pa("R(x,y)"),
				exist(pa("A(z)"), "z")
		);
		Formula f3 = and(
				pa("R(x,y)"),
				exist(pa("A(y)"), "y")
		);
		testQuery(toSql(f1), getStringTuples(select(toSql(f2))));
		testQuery(toSql(f1), getStringTuples(select(toSql(f3))));
		testQuery(toSql(f1, "y"), getStringTuples(select(toSql(f3, "y"))));
	}
	
	@Test
	public void forAllTest() throws SQLificationException {
		SQLTestCases.initTestCase1();
		
		Formula f1 = forall(pa("R(x,y)"),"x");
		Logger.info(f1);
		assertThrows(SQLificationException.class, () -> toSql(f1));
		
		Formula f2 = not(forall(not(pa("R(x,y)")),"x"));
		Logger.info(f2);
		Logger.debug(toSql(f2));
		assertDoesNotThrow(() -> toSql(f2));
		
		Formula f3 = and(pa("B(z)"),forall(and(
				pa("A(x)"),
				forall(pa("R(x,y)"),"y")
		),"x"));
		Logger.info(f3);
		assertDoesNotThrow(() -> toSql(f3));
		
		Formula f4 = forall(and(
				pa("A(x)"),
				forall(pa("R(x,y)"),"y")
		),"x");
		Logger.info(f4);
		assertDoesNotThrow(() -> toSql(f4));
	}
	
	@Test
	public void selectFalse() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		testQuery(toSql(False.getInstance()), falseResult, true);
	}
	
	@Test
	public void selectTrue() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		testQuery(toSql(True.getInstance()), trueResult, true);
	}
	
	@Test
	public void selectEqOrIneq() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		testQuery(toSql(eq("1","1")), trueResult, true);
		testQuery(toSql(eq("1","2")), falseResult, true);
		testQuery(toSql(ineq("1","2")), trueResult, true);
		testQuery(toSql(ineq("1","1")), falseResult, true);
	}
	
	@Test
	public void selectNot() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		testQuery(toSql(not(eq("1","1"))), falseResult, true);
		testQuery(toSql(not(ineq("1","1"))), trueResult, true);
		testQuery(toSql(not(not(pa("R(x,y)")))), Arrays.asList(
				new Tuple(1,2),
				new Tuple(2,3),
				new Tuple(4,null),
				new Tuple(null,5),
				new Tuple(6,6)
		), true);
		testQuery(toSql(not(not(pa("R(x,y)"))), "y"), Arrays.asList(
				new Tuple(1),
				new Tuple(2),
				new Tuple(4),
				nullTuple(1),
				new Tuple(6)
		), true);
		testQuery(toSql(and(pa("R(x,y)"), not(exist(and(pa("S(y,z)"), eq("z","3")),"z"))), "y"), Arrays.asList(
				new Tuple(1),
				new Tuple(4),
				nullTuple(1),
				new Tuple(6)
		), true);
	}
	
	@Test
	public void testException() {
		Formula f = and(
				pa("A(x)"),
				or(
						pa("A(y)"),
						pa("R(x,y)")));
		assertThrows(SQLificationException.class, () -> toSql(f));
	}
	
	@Test
	public void unsafeQueryTest() {
		Formula f1 = or(
				pa("A(x)"),
				pa("R(x,y)"));
		assertThrows(SQLCompiler.UnsafeQueryException.class, () -> toSql(f1));
		
		Formula f2 = and(
				pa("W(x,y,z)"),
				or(
						pa("B(x)"),
						and(
								pa("A(x)"),
								pa("R(x,y)"),
								eq("x","z"),
								eq("y","z"))));
		Logger.info(f2);
		assertDoesNotThrow(() -> toSql(f2));
		
		Formula f3 = and(pa("A(x)"), exist(not(or(pa("A(y)"), pa("R(x,y)"))),"x"));
		Formula f4 = and(pa("A(x)"), exist(not(or(pa("A(y)"), pa("R(x,y)"))),"y"));
		Logger.info(f3);
		Logger.info(f4);
		assertThrows(SQLCompiler.UnsafeQueryException.class, () -> toSql(f3));
		assertDoesNotThrow(() -> toSql(f4));
	}
	
	@Test
	public void distinctTest() throws SQLificationException, SQLException {
		SQLTestCases.initTestCase1();
		
		Disjunction d = or(pa("R(x,y)"), pa("R(y,z)"));
		
		Logger.info(d);
		String query1 = toSql(d, true, "x", "z");
		testQuery(query1, Arrays.asList(
				new Tuple(1),
				new Tuple(2),
				new Tuple(3),
				new Tuple(4),
				new Tuple(5),
				new Tuple(6),
				nullTuple(1)
				), true
		);
	}
	
	public static void testQuery(String query, List<Tuple> expectedResult) throws SQLException {
		testQuery(query, expectedResult, false);
	}
	
	public static void testQuery(String query, List<Tuple> expectedResult, boolean verbose) throws SQLException {
		if (verbose) {
			Logger.debug("Executing query:\n" + query + "\n");
			System.out.println("Output:");
			printResultSet(select(query));
		}
		List<Tuple> actualResult = getStringTuples(select(query));
		List<Tuple> expectedStringResult = expectedResult.stream()
				.map(SQLifierTest::toStringTuple)
				.collect(Collectors.toList());
		assertEquals(expectedStringResult.size(), actualResult.size());
		assertEquals(new HashSet<>(expectedStringResult), new HashSet<>(actualResult));
	}
	
	private static Tuple toStringTuple(Tuple tuple) {
		return new Tuple(Arrays.stream(tuple.toArray()).map(value -> {
			if (value instanceof Boolean) return (Boolean) value ? "1" : "0";
			return value == null ? null : value.toString();
		}).toArray());
	}
}
