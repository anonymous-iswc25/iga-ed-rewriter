package fol;

import org.junit.Test;
import igaedrewriter.fol.*;
import igaedrewriter.fol.ObjectConstant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static util.TestUtils.testEquality;
import static util.TestUtils.testInequality;

public class ComparisonAtomTest {
	
	@Test
	public void equalityTest() {
		Term vx = new Variable("x");
		Term vy = new Variable("y");
		Term oc = new ObjectConstant("x");
		
		// a1 and a2 should be considered equal but printed in different ways
		ComparisonAtom a1 = new Equality(vx, vy);
		ComparisonAtom a2 = new Equality(vy, vx);
		testEquality(a1, a2);
		assertNotEquals(a1.toString(), a2.toString());
		
		// a3 and a3 should be considered NOT equal but printed in the same way
		ComparisonAtom a3 = new Equality(vx, vx);
		ComparisonAtom a4 = new Equality(oc, oc);
		assertEquals(a3.toString(), a4.toString());
		testInequality(a3, a4);
		
		// a1 and a2 should be considered NOT equal and printed in different ways
		ComparisonAtom a5 = new StrictInequality(vx, vy);
		testInequality(a1, a5);
		assertNotEquals(a1.toString(), a5.toString());
	}
}
