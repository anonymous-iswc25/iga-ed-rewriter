package fol;

import org.junit.Test;
import igaedrewriter.fol.*;

import java.util.*;

import static fol.FormulaTest.pa;
import static fol.TermTest.var;
import static org.junit.Assert.*;
import static util.TestUtils.*;

public class ConjunctionTest {
	
	@Test
	public void optimizationTest() {
		PredicateAtom a1 = pa(":R(x,y)");
		PredicateAtom a2 = pa(":S(x,z)");
		Conjunction c1 = new Conjunction(a1, a2);
		
		// optimization removes tautologies from the the conjunction
		Conjunction c2 = new Conjunction(a1, a2, True.getInstance());
		testInequality(c1, c2);
		c2.optimize();
		testEquality(c1, c2);
		
		// optimization doesn't remove contradictions from the the conjunction
		c2 = new Conjunction(a1, a2, False.getInstance());
		testInequality(c1, c2);
		c2.optimize();
		testInequality(c1, c2);
		
		// optimization flattens the conjunction
		c2 = new Conjunction(a1, new Conjunction(new Conjunction(a2)));
		testInequality(c1, c2);
		c2.optimize();
		testEquality(c1, c2);
		
		// optimization removes unnecessary containers
		c2 = new Conjunction(a1, new Negation(a2));
		Conjunction c3 = new Conjunction(a1, new Negation(new Disjunction(a2)));
		testInequality(c2, c3);
		c3.optimize();
		testEquality(c2, c3);
	}
	
	@Test
	public void equalsTest1() {
		PredicateAtom a1 = pa(":R(x,y)");
		PredicateAtom a2 = pa(":S(x,z)");
		Conjunction c1 = new Conjunction(a1, a2);
		Conjunction c2 = conj(":R(x,y)", ":S(x,z)");
		FlatConjunction c3 = new FlatConjunction(Arrays.asList(a1, a2));
		testEquality(c1,c2);
		testEquality(c1,c3);
		testEquality(c2,c3);
	}
	
	@Test
	public void equalsTest2() {
		PredicateAtom a1 = pa(":R(x,y)");
		PredicateAtom a2 = pa(":S(x,z)");
		Conjunction c1 = new Conjunction(a1, a2);
		Conjunction c2 = new Conjunction(a2, a1);
		testEquality(c1,c2);
	}
	
	@Test
	public void sharedVariablesTest1() {
		/*
		 * Given a formula (R(x,y) AND S(x,z) AND (T(z,z) OR T(z,w) OR C(w))),
		 *       it will return {x,z}. Notice that it does NOT include "w".
		 */
		PredicateAtom a1 = pa(":R(x,y)");
		PredicateAtom a2 = pa(":S(x,z)");
		PredicateAtom a3 = pa(":T(z,z)");
		PredicateAtom a4 = pa(":T(z,w)");
		PredicateAtom a5 = pa(":C(w)");
		
		Conjunction c = new Conjunction(a1, a2, new Disjunction(a3, a4, a5));
		System.out.println("\nFormula:\n" + c);
		
		Collection<Variable> sv;
		
		sv = c.getSharedVariables();
		System.out.println("Shared variables (NOT counting multiple occurrences in same subformula):\n" + sv);
		assertTrue (sv.contains(var("x")));
		assertFalse(sv.contains(var("y")));
		assertTrue (sv.contains(var("z")));
		assertFalse(sv.contains(var("w")));
	}
	
	@Test
	public void sharedVariablesTest2() {
		PredicateAtom a1 = pa(":R(x,x)");
		PredicateAtom a2 = pa(":R(y,z)");
		PredicateAtom a3 = pa(":R(z,w)");
		
		Conjunction c = new Conjunction(a1, a2, a3);
		System.out.println("\nFormula:\n" + c);
		
		Collection<Variable> sv;
		
		sv = c.getSharedVariables();
		System.out.println("Shared variables (NOT counting multiple occurrences in same atom):\n" + sv);
		assertFalse(sv.contains(var("x")));
		assertFalse(sv.contains(var("y")));
		assertTrue (sv.contains(var("z")));
		assertFalse(sv.contains(var("w")));
	}
}
