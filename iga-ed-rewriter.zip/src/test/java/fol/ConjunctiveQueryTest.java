package fol;

public class ConjunctiveQueryTest {
	
	/* TODO: implement unit test for general CQs. Suggestions:
	 *  - copy something from OntologyConjunctiveQueryTest
	 *  - use a DBSchema
	 *  - consider n-ary predicates (with n>2)
	 */
}
