package fol;

import org.junit.Test;
import igaedrewriter.fol.Constant;
import igaedrewriter.fol.DataConstant;
import igaedrewriter.fol.Datatype;
import igaedrewriter.fol.Term;
import igaedrewriter.parser.ParserException;
import util.TestException;
import util.TestUtils;

import static org.junit.Assert.*;
import static igaedrewriter.fol.Datatype.*;

public class DataConstantTest {
	
	@Test
	public void parsingTest() throws ParserException, Term.TermTypeException {
		String stringInput = "\"abc \\\"def\\\" ghi\"";
		String stringValue = "abc \"def\" ghi";
		
		assertEquals(stringValue, fromDatalog(stringInput).getValue());
		assertEquals("123", fromDatalog("123").getValue());
	}
	
	@Test
	public void subclassTest() throws ParserException, Term.TermTypeException {
		assertTrue(Constant.class.isAssignableFrom(fromDatalog("123").getClass()));
	}
	
	@Test
	public void datatypeTest() throws ParserException, Term.TermTypeException {
		assertEquals(XSD_INTEGER, fromDatalog("-1").getDatatype());
		assertEquals(XSD_DECIMAL, fromDatalog("1.23").getDatatype());
		assertEquals(XSD_BOOLEAN, fromDatalog("true").getDatatype());
		assertNotEquals(XSD_STRING, fromDatalog("false").getDatatype());
	}
	
	protected static DataConstant fromDatalog(String source) throws ParserException, Term.TermTypeException {
		return TestUtils.datalogParser.parseAs(source, DataConstant.class);
	}
	
	protected static DataConstant stringConstant(String value) {
		try {
			return new DataConstant(value, Datatype.XSD_STRING);
		} catch (DataConstant.DatatypeNoMatchException e) {
			throw new TestException(e);
		}
	}
}
