package fol;

import org.junit.Test;
import igaedrewriter.fol.*;

import static fol.FormulaTest.pa;
import static util.TestUtils.*;

public class DisjunctionTest {
	
	@Test
	public void optimizationTest() {
		PredicateAtom a1 = pa(":R(x,y)");
		PredicateAtom a2 = pa(":S(x,z)");
		Disjunction d1 = new Disjunction(a1, a2),
				d2, d3;
		
		// optimization removes contradictions from the the conjunction
		d2 = new Disjunction(a1, a2, False.getInstance());
		testInequality(d1, d2);
		d2.optimize();
		testEquality(d1, d2);
		
		// optimization doesn't remove tautologies from the the conjunction
		d2 = new Disjunction(a1, a2, True.getInstance());
		testInequality(d1, d2);
		d2.optimize();
		testInequality(d1, d2);
		
		// optimization flattens the conjunction
		d2 = new Disjunction(a1, new Disjunction(new Disjunction(a2)));
		testInequality(d1, d2);
		d2.optimize();
		testEquality(d1, d2);
		
		// optimization removes unnecessary containers
		d2 = new Disjunction(a1, new Negation(a2));
		d3 = new Disjunction(a1, new Negation(new Disjunction(a2)));
		testInequality(d2, d3);
		d3.optimize();
		testEquality(d2, d3);
	}
	
	@Test
	public void equalsTest1() {
		PredicateAtom a1 = pa(":R(x,y)");
		PredicateAtom a2 = pa(":S(x,z)");
		Disjunction c1 = new Disjunction(a1, a2);
		Disjunction c2 = disj(":R(x,y)", ":S(x,z)");
		testEquality(c1,c2);
	}
	
	@Test
	public void equalsTest2() {
		PredicateAtom a1 = pa(":R(x,y)");
		PredicateAtom a2 = pa(":S(x,z)");
		Disjunction c1 = new Disjunction(a1, a2);
		Disjunction c2 = new Disjunction(a2, a1);
		testEquality(c1,c2);
	}
}
