package fol;

import org.junit.Test;
import igaedrewriter.fol.*;

import java.util.ArrayList;
import java.util.Arrays;

import static fol.FormulaTest.pa;

public class ExistTest {
	
	@Test
	public void test1() {
		PredicateAtom atom1 = pa(":R(x,y)");
		PredicateAtom atom2 = pa(":S(x,z)");
		System.out.println(
				new Exist(
						new Conjunction(
								atom1, new Negation(atom2)
						),
						new ArrayList<>(Arrays.asList(new Variable("x"), new Variable("y")))
				)
		);
	}
}
