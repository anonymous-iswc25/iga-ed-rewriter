package fol;

import org.junit.Test;
import igaedrewriter.fol.*;

import java.util.*;
import java.util.stream.Collectors;

import static fol.FormulaTest.*;
import static fol.TermTest.var;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static util.TestUtils.*;

public class FlatConjunctionTest {
	
	@Test
	public void implicationTest() {

		assertImpliesUSS(conj(":R(x,y)"), conj(":R(x,y)"));
		assertImpliesUSS(conj(":R(x,y)"), conj(":R(x,z)"));
		assertNotImpliesUSS(conj(":R(x,y)"), conj(":R(x,x)"));
		assertNotImpliesUSS(conj(":R(x,y)"), conj(":R(y,x)"));
		assertNotImpliesUSS(conj(":R(x,y)"), conj(":R(y,y)"));
		assertNotImpliesUSS(conj(":R(x,y)"), conj(":R(y,z)"));
		assertNotImpliesUSS(conj(":R(x,y)"), conj(":R(z,z)"));
		
		assertNotImplies(conj(":R(z,z)", ":C(z)"), conj(":R(x,y)", ":R(y,z)"));
		assertImpliesUSS(conj(":R(z,z)", ":C(z)"), conj(":R(x,y)", ":R(y,z)"));
		
		//--------------------------------------
		// EQUALITIES
		//--------------------------------------
		
		assertImplies(conj("x=y","x=z"), conj("y=z"));
		assertImpliesUSS(conj("x=y","x=z"), conj("y=z"));
		
		assertImplies(conj("x=y", "y=3"), conj("x=3"));
		assertImpliesUSS(conj("x=y", "y=3"), conj("x=3"));
		
		assertNotImplies(conj("x=y"), conj("x=z"));
		assertNotImpliesUSS(conj("x=y"), conj("x=z"));
		
		//--------------------------------------
		// CONSTANTS
		//--------------------------------------
		
		assertImplies(conj(":R(x,y)", ":J(z,3)"), conj(":J(z,3)"));
		assertNotImplies(conj(":J(x,3)"), conj(":J(z,3)"));
		assertNotImplies(conj(":J(x,3)"), conj(":J(x,y)"));
		assertNotImplies(conj(":J(x,3)"), conj(":J(z,y)"));
		assertNotImplies(conj(":J(x,y)"), conj(":J(x,3)"));
		assertNotImplies(conj(":J(x,y)"), conj(":J(z,3)"));
		assertImpliesUSS(conj(":J(x,3)"), conj(":J(z,3)"));
		assertImpliesUSS(conj(":J(x,3)"), conj(":J(x,y)"));
		assertImpliesUSS(conj(":J(x,3)"), conj(":J(z,y)"));
		assertNotImpliesUSS(conj(":J(x,y)"), conj(":J(x,3)"));
		assertNotImpliesUSS(conj(":J(x,y)"), conj(":J(z,3)"));

		//assertImpliesUSS(conj(":R(3,3)","C(z)"), conj(":R(x,y)",":R(y,z)"));
		
		//--------------------------------------
		//--------------------------------------
		
		assertImplies(conj(":R(x,x)"), conj(":R(x,x)"));
		assertImpliesUSS(conj(":R(x,x)"), conj(":R(x,x)"));
		assertImpliesUSS(conj(":R(x,x)"), conj(":R(x,y)"));
		assertImpliesUSS(conj(":R(x,x)"), conj(":R(y,x)"));
		assertImpliesUSS(conj(":R(x,x)"), conj(":R(y,y)"));
		assertImpliesUSS(conj(":R(x,x)"), conj(":R(x,z)"));
		assertImpliesUSS(conj(":R(x,x)"), conj(":R(y,z)"));
		assertImpliesUSS(conj(":R(x,x)"), conj(":R(z,z)"));
		
		//--------------------------------------
		//--------------------------------------
		
		assertImpliesUSS(conj(":R(y,y)"), conj(":R(x,x)"));
		assertImpliesUSS(conj(":R(y,y)"), conj(":R(x,y)"));
		assertImpliesUSS(conj(":R(y,y)"), conj(":R(y,x)"));
		assertImpliesUSS(conj(":R(y,y)"), conj(":R(y,y)"));
		assertImpliesUSS(conj(":R(y,y)"), conj(":R(x,z)"));
		assertImpliesUSS(conj(":R(y,y)"), conj(":R(y,z)"));
		assertImpliesUSS(conj(":R(y,y)"), conj(":R(z,z)"));
		
		//--------------------------------------
		//--------------------------------------
		
		assertImplies(conj(":R(x,y)", "x=y"), conj(":R(x,x)"));
		assertImplies(conj(":R(x,y)", "x=y"), conj(":R(x,y)"));
		assertImplies(conj(":R(x,y)", "x=y"), conj(":R(y,x)"));
		assertImplies(conj(":R(x,y)", "x=y"), conj(":R(y,y)"));
		assertNotImplies(conj(":R(x,y)", "x=y"), conj(":R(x,z)"));
		assertNotImplies(conj(":R(x,y)", "x=y"), conj(":R(y,z)"));
		assertNotImplies(conj(":R(x,y)", "x=y"), conj(":R(z,z)"));
		
		//--------------------------------------
		//--------------------------------------
		
		assertImpliesUSS(conj(":R(x,y)", "x=y"), conj(":R(x,x)"));
		assertImpliesUSS(conj(":R(x,y)", "x=y"), conj(":R(x,y)"));
		assertImpliesUSS(conj(":R(x,y)", "x=y"), conj(":R(y,x)"));
		assertImpliesUSS(conj(":R(x,y)", "x=y"), conj(":R(y,y)"));
		assertImpliesUSS(conj(":R(x,y)", "x=y"), conj(":R(x,z)"));
		assertImpliesUSS(conj(":R(x,y)", "x=y"), conj(":R(y,z)"));
		assertImpliesUSS(conj(":R(x,y)", "x=y"), conj(":R(z,z)"));
		
		//--------------------------------------
		//--------------------------------------
		
		assertImpliesUSS(conj(":R(x,y)", "x!=y"), conj(":R(x,y)"));
		assertImpliesUSS(conj(":R(x,y)", "x!=y"), conj(":R(x,z)"));
		assertNotImpliesUSS(conj(":R(x,y)"), conj(":R(x,x)"));
		assertNotImpliesUSS(conj(":R(x,y)"), conj(":R(x,y)", "x!=y"));
		assertNotImpliesUSS(conj(":R(x,y)", "x!=y"), conj(":R(x,x)"));
		assertNotImpliesUSS(conj(":R(x,y)", "x!=y"), conj(":R(y,x)"));
		assertNotImpliesUSS(conj(":R(x,y)", "x!=y"), conj(":R(y,y)"));
		assertNotImpliesUSS(conj(":R(x,y)", "x!=y"), conj(":R(y,z)"));
		assertNotImpliesUSS(conj(":R(x,y)", "x!=y"), conj(":R(z,z)"));
		
		//--------------------------------------
		//--------------------------------------
		
		assertImplies(conj(":R(x,y)"), conj());
		assertImplies(conj(":R(x,y)"), conj("x=x"));
		
		// a tautology implies another tautology
		assertImplies(conj(), conj());
		assertImplies(conj("1 = 1", "x = x"), conj());
		assertImplies(conj(), conj("1 = 1", "x = x"));
		
		// everything can imply a tautology
		assertImplies(conj("x != 1"), conj("1 = 1", "x = x"));
		assertImplies(conj("x != 1"), conj());
		
		// a contradiction can imply everything
		assertImplies(conj("x=y", "x=z", "y!=z"), conj("x != 1"));
		assertImplies(conj("x='a'", "x=1"), conj("x != 1"));
		
		// a contradiction can imply another contradiction
		assertImplies(conj("x=y", "x=z", "y!=z"), conj("x=y", "x!=y"));
		assertImplies(conj("x='a'", "x=1"), conj("x=y", "x!=y"));
		
		// a tautology can't imply a contradiction
		assertNotImpliesUSS(conj(), conj("x=y", "x!=y"));
	}
	
	private FlatConjunction conj(String... sources) {
		return new FlatConjunction(
				parse(sources).stream()
						.map(f->(Atom)f)
						.collect(Collectors.toList())
		);
	}
	
	private void assertImplies(FlatConjunction bc1, FlatConjunction bc2) {
		assertImpliesUSS(bc1,bc2); // everything implied should also be implied under some substitution!
		assertTrue("The second conjunction is expected to be a consequence of the first one.",
				bc1.implies(bc2));
	}
	
	private void assertNotImplies(FlatConjunction bc1, FlatConjunction bc2) {
		assertFalse("The second conjunction is expected NOT to be a consequence of the first one.",
				bc1.implies(bc2));
	}
	
	private void assertImpliesUSS(FlatConjunction bc1, FlatConjunction bc2) {
		assertTrue("The first conjunction is expected to imply the latter under some substitution.",
				bc1.impliesUnderSomeSubstitution(bc2));
	}
	
	private void assertNotImpliesUSS(FlatConjunction bc1, FlatConjunction bc2) {
		assertNotImplies(bc1,bc2); // everything not implied under some substitution should never be implied!
		assertFalse("The first conjunction is expected NOT to imply the latter under some substitution.",
				bc1.impliesUnderSomeSubstitution(bc2));
	}
	
	
	
	//------ OLD TESTS
	
	@Test
	public void consistencyChecks() {
		FlatConjunction c1 = new FlatConjunction();
		addEquivalentVariables(c1, "a", "b");
		addEquivalentVariables(c1, "c", "c");
		addEquivalentVariables(c1, "c", "a");
		addEquivalentVariables(c1, "x", "y");
		addEquivalentVariables(c1, "x", "y");
		
		assertFalse(c1.contradicts(Arrays.asList(
				ineq("a", "x"),
				ineq("b", "x")
		)));
		assertTrue(c1.contradicts(ineq("a", "b")));
		
		addStrictInequality(c1, "x", "y");
		assertTrue(c1.isContradiction());
	}
	
	@Test
	public void strictInequalityImplication() {
		FlatConjunction cond = new FlatConjunction();
		addEquivalentVariables(cond, "a", "b", "c");
		addEquivalentVariables(cond, "c", "d");
		addEquivalentVariables(cond, "e", "f");
		addStrictInequality(cond, "d", "f");
		addStrictInequality(cond, "g", "h");
		
		assertFalse(cond.isContradiction());
		assertTrue(cond
				.inequalitySaturation(ineq("a", "e"))
				.containsAll(Arrays.asList(
						ineq("b", "e"),
						ineq("e", "b")
				)));
		assertTrue(cond.implies(ineq("b", "e")));
		assertFalse(cond.implies(ineq("b", "c")));
		assertFalse(cond.implies(ineq("f", "g")));
	}
	
	@Test
	public void otherImplications() {
		FlatConjunction c1 = new FlatConjunction(),
				c2 = new FlatConjunction(),
				c3 = new FlatConjunction(),
				c4 = new FlatConjunction(),
				c5 = new FlatConjunction();
		
		assertTrue(c1.impliesUnderSomeSubstitution(new FlatConjunction()));
		
		addEquivalentVariables(c1, "a", "b", "c");
		addEquivalentVariables(c1, "c", "d", "e");
		addEquivalentVariables(c1, "f", "g");
		addStrictInequality(c1, "g", "h");
		addStrictInequality(c1, "h", "i");
		assertTrue(c1.impliesUnderSomeSubstitution(new FlatConjunction()));
		assertFalse(new FlatConjunction().impliesUnderSomeSubstitution(c1));
		assertTrue(c1.impliesUnderSomeSubstitution(c1.clone()));
		assertTrue(c1.clone().impliesUnderSomeSubstitution(c1));
		
		c2.add(eq("a","b"));
		addStrictInequality(c2, "f", "h");
		assertTrue(c1.impliesUnderSomeSubstitution(c2));
		assertFalse(c2.impliesUnderSomeSubstitution(c1));
		
		addEquivalentVariables(c3, "a", "b");
		addStrictInequality(c3, "f", "i");
		assertFalse(c1.impliesUnderSomeSubstitution(c3));
		
		addEquivalentVariables(c4, "a", "b", "f");
		assertFalse(c1.impliesUnderSomeSubstitution(c4));
		
		addEquivalentVariables(c5, "a", "b", "c");
		addEquivalentVariables(c5, "c", "d", "e");
		addEquivalentVariables(c5, "f", "g");
		addStrictInequality(c5, "g", "h");
		addStrictInequality(c5, "h", "i");
		assertTrue(c1.impliesUnderSomeSubstitution(c5));
		assertTrue(c5.impliesUnderSomeSubstitution(c1));
	}
	
	
	@Test
	public void removeInequalities() {
		FlatConjunction c1 = new FlatConjunction();
		addEquivalentVariables(c1, "a", "b", "c");
		addStrictInequality(c1, "a", "d");
		addStrictInequality(c1, "b", "e");
		addStrictInequality(c1, "d", "f");
		
		FlatConjunction c2 = c1.clone();
		c2.removeAll(ineq("a","e"), ineq("d","e"));
		testEquality(c1, c2);
		
		FlatConjunction c3 = c1.clone();
		System.out.println(c3.inequalitySaturation(ineq("a", "e")));
		c3.removeAll(c3.inequalitySaturation(ineq("a", "e")));
		c3.removeAll(c3.inequalitySaturation(ineq("d", "e")));
		
		assertTrue(c1.impliesUnderSomeSubstitution(c3));
		assertFalse(c3.impliesUnderSomeSubstitution(c1));
	}
	
	@Test
	public void conjunctionOptimization() {
		FlatConjunction c1 = new FlatConjunction(),
				c2 = new FlatConjunction();
		
		addEquivalentVariables(c1, "a", "a");
		testInequality(c1, c2);
		c1.optimize();
		testEquality(c1, c2);
		
		addEquivalentVariables(c1, "a", "b", "c");
		removeVariable(c1, "c");
		removeVariable(c1, "b");
		testEquality(c1, c2);
		
		addEquivalentVariables(c1);
		addEquivalentVariables(c1, "a");
		addEquivalentVariables(c1, "a", "b");
		addEquivalentVariables(c1, "a", "b");
		addEquivalentVariables(c1, "x", "y");
		addEquivalentVariables(c1, "y", "z", "w");
		addStrictInequality(c1, "a", "w");
		c1 = FlatConjunction.join(c1, c1);
		
		addEquivalentVariables(c2, "a", "b");
		addEquivalentVariables(c2, "x", "y", "z", "w");
		addStrictInequality(c2, "b", "y");
		
		testInequality(c1, c2);									// they should be syntactically different
		assertTrue(c1.implies(c2) && c2.implies(c1));	// they should be semantically equivalent
	}
	
	@Test
	public void removeVariableTest() {
		FlatConjunction conj = new FlatConjunction();
		addStrictInequality(conj, "a", "b");
		addEquivalentVariables(conj, "b", "c");
		conj.removeTerm(var("b"));
		conj.implies(ineq("a", "c"));
	}
	
	@Test
	public void variablesTest() {
		FlatConjunction c1 = new FlatConjunction();
		addEquivalentVariables(c1, "a", "b", "c");
		addStrictInequality(c1, "a", "d");
		addStrictInequality(c1, "b", "e");
		addStrictInequality(c1, "d", "f");
		
		Collection<Variable> variables = c1.getVariables();
		assertTrue(variables.contains(var("c")));
		assertTrue(variables.contains(var("f")));
		assertFalse(variables.contains(var("x")));
	}
	
	@Test
	public void addEqualityTest() {
		FlatConjunction c = new FlatConjunction();
		assertEquals(0, c.getSetsOfEquivalentTerms().size());
		
		addEquivalentVariables(c, "a", "b");
		assertEquals(1, c.getSetsOfEquivalentTerms().size());
		
		addEquivalentVariables(c, "c", "d");
		addEquivalentVariables(c, "e", "f");
		addEquivalentVariables(c, "g", "h");
		addEquivalentVariables(c, "i", "j");
		addEquivalentVariables(c, "k", "l");
		addEquivalentVariables(c, "m", "n");
		addEquivalentVariables(c, "o", "p");
		addEquivalentVariables(c, "q", "r");
		assertEquals(9, c.getSetsOfEquivalentTerms().size());
		
		addEquivalentVariables(c, "a", "c", "e");
		assertEquals(7, getOptimizedNumberOfEqualityChains(c));
		
		addEquivalentVariables(c, "g", "i", "k");
		assertEquals(5, getOptimizedNumberOfEqualityChains(c));
		
		addEquivalentVariables(c, "m", "o", "q");
		assertEquals(3, getOptimizedNumberOfEqualityChains(c));
		
		addEquivalentVariables(c, "a", "g", "m");
		assertEquals(1, getOptimizedNumberOfEqualityChains(c));
	}
	
	@Test
	public void cloneTest() {
		FlatConjunction c1 = new FlatConjunction();
		addEquivalentVariables(c1, "a", "b", "c");
		addStrictInequality(c1, "a", "d");
		addStrictInequality(c1, "b", "e");
		
		FlatConjunction c2 = c1.clone();	// deep copy
		testEquality(c1, c2);
		
		addStrictInequality(c1, "d", "f");
		removeVariable(c1, "b");
		testInequality(c1, c2);
		
		addStrictInequality(c2, "d", "f");
		removeVariable(c2, "b");
		testEquality(c1, c2);
	}
	
	@Test
	public void nonAtomicSubformulasTest() {
		PredicateAtom a1 = pa(":A(x)");
		PredicateAtom a2 = pa(":B(x)");
		PredicateAtom a3 = pa(":C(x)");
		Disjunction d = new Disjunction(a2, a3);
		FlatConjunction fc = new FlatConjunction();
		
		assertDoesNotThrow(() -> fc.add(a1));
		assertThrows(RuntimeException.class, () -> fc.add(d));
		assertThrows(RuntimeException.class, () -> fc.addAll(d));
		assertThrows(RuntimeException.class, () -> fc.addAll(Collections.singletonList(d)));
		assertThrows(RuntimeException.class, () -> fc.replaceAll(a->d));
		
		Conjunction c = fc.unflat();
		testEquality(fc, c);
		testEquality(c, fc);
		assertDoesNotThrow(() -> c.add(a1));
	}
	
	private void addEquivalentVariables(FlatConjunction conj, String... variablesNames) {
		List<Variable> equivalentVariables = variablesList(variablesNames);
		for (int i=0; i < equivalentVariables.size(); i++) {
			Variable v1 = equivalentVariables.get(i);
			for (int j=i+1; j < equivalentVariables.size(); j++) {
				Variable v2 = equivalentVariables.get(j);
				conj.add(new Equality(v1,v2));
			}
		}
	}
	
	private void addStrictInequality(FlatConjunction conj, String varName1, String varName2) {
		conj.add(ineq(varName1, varName2));
	}
	
	private int getOptimizedNumberOfEqualityChains(FlatConjunction conjunction) {
		FlatConjunction fc2 = conjunction.clone();
		fc2.optimize();
		return fc2.getSetsOfEquivalentTerms().size();
	}
	
	private void removeVariable(FlatConjunction conj, String varName) {
		conj.removeTerm(var(varName));
	}
}
