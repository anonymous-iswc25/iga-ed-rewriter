package fol;

import org.junit.Test;
import igaedrewriter.fol.Datatype;
import igaedrewriter.fol.*;
import igaedrewriter.fol.OntologyPredicateAtom;
import util.TestException;
import util.TestUtils;

import java.util.*;
import java.util.stream.Collectors;

import static fol.TermTest.var;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static igaedrewriter.fol.Variable.BLANK_VAR_SYMBOL;
import static util.TestUtils.testEquality;
import static util.TestUtils.testInequality;

public class FormulaTest {
	
	@Test
	public void distinguishVariables() {
		PredicateAtom a1 = pa(":A(x)"),
				a2 = pa(":R(x, _)"),
				a3 = pa(":S(x, _)"),
				a4 = pa(":T(_, x)"),
				a5 = pa(":B(x)");
		
		Disjunction d = new Disjunction(a1,a2,a3);
		Formula f = new Conjunction(a4,a5,d);
		System.out.println("PRE: " + f);
		assert(f.hasVariableWithName(BLANK_VAR_SYMBOL));
		
		f.explicitVariables(new HashSet<>(Arrays.asList("x", "y", "z")));
		System.out.println("POST: " + f);
		assert(!f.hasVariableWithName(BLANK_VAR_SYMBOL));
	}
	
	@Test
	public void testFlatten() {
		PredicateAtom
				a1 = pa("A(x)"),
				a2 = pa("B(x)"),
				a3 = pa("C(x)"),
				a4 = pa("D(x)"),
				a5 = pa("E(x)");
		
		// TEST 1
		Formula f1 = and(a1, and(a2, not(not(or(a3, or(a4, a5))))));
		Formula f2 = and(a1, a2, or(a3, a4, a5));
		assertNotEquals(f1, f2);
		
		f1.flatten(true);
		assertEquals(f1, f2);
		
		// TEST 2
		Formula f3 = exist(not(not(a1)), "x");
		Formula f4 = exist(a1, "x");
		assertNotEquals(f3, f4);
		
		f3.flatten(true);
		assertEquals(f3, f4);
		
		// TEST 3
		Formula f5 = not(not(not(a1)));
		Formula f6 = not(a1);
		assertNotEquals(f5, f6);
		
		f5.flatten(true);
		assertEquals(f5, f6);
	}
	
	@Test
	public void variablesRenaming() {
		PredicateAtom l1a = pa(":A(x)"),
				l1b = pa(":B(x)"),
				l1c = pa(":R(x,y)"),
				l1d = pa(":S(x,y)"),
				l2a = pa(":A(y)"),
				l2b = pa(":B(y)"),
				l2c = pa(":R(y,x)"),
				l2d = pa(":S(y,x)");
		Formula f1 = new Negation(new Conjunction(new Disjunction(l1a, l1b, l1c, l1d)));
		Formula f2 = new Negation(new Conjunction(new Disjunction(l2a, l2b, l2c, l2d)));
		
		testInequality(f1,f2);
		
		f2.replaceVariablesByName(new HashMap<String,Term>(){{
			put("x", var("y"));
			put("y", var("x"));
		}});
		testEquality(f1, f2);
	}
	
	@Test
	public void optimizationTest() {
		PredicateAtom r = pa("R(x,y)");
		PredicateAtom a = pa("A(x)");
		
		// TEST 1
		Formula f1 = and(r, not(and(r, a)));
		Formula f2 = and(r, not(a));
		testInequality(f1, f2);
		
		f1.optimize();
		testEquality(f1, f2);
		
		// TEST 2
		Formula f3 = and(r, or(r, a));
		Formula f4 = and(r);
		testInequality(f3, f4);
		
		f3.optimize();
		testEquality(f3, f4);
		
		// TEST 3
		Formula f5 = or(r, not(or(r, a)));
		Formula f6 = or(r, not(a));
		testInequality(f5, f6);
		
		f5.optimize();
		testEquality(f5, f6);
		
		// TEST 4
		Formula f7 = or(r, and(r, a));
		Formula f8 = or(r);
		testInequality(f7, f8);
		
		f7.optimize();
		testEquality(f7, f8);
	}
	
	@Test
	public void freeVariables() {
		PredicateAtom a1 = pa("R(x,y,w)"),
				a2 = pa("S(x,y,z)");
		Variable x = var("x"),
				y = var("y"),
				z = var("z"),
				w = var("w");
		new Conjunction(a1, new Exist(a2,x,z));
		Formula f1 = new Exist(a2,x,z);
		Formula f2 = new Conjunction(a1, new Exist(a2,x,z));
		assertTrue(Collections.singletonList(y).containsAll(f1.getFreeVariables()));
		assertTrue(f1.getFreeVariables().contains(y));
		assertTrue(Arrays.asList(x,y,w).containsAll(f2.getFreeVariables()));
		assertTrue(f2.getFreeVariables().containsAll(Arrays.asList(x,y,w)));
	}
	
	public static OntologyPredicateAtom ontologyPredicateAtom(String datalog) {
		// we don't use TestUtils.datalogParser.parseAs() because here we don't care about catching parsing exceptions
		return TestUtils.parseAs(datalog, OntologyPredicateAtom.class);
	}
	
	// it only accepts variables or numeric constants
	private static Term parseTerm(String s) {
		try {
			Integer.parseInt(s);
			return new DataConstant(s, Datatype.XSD_INT);
		}
		catch (NumberFormatException e){
			return var(s);
		}
		catch (DataConstant.DatatypeNoMatchException e) {
			throw new TestException(e);
		}
	}
	
	/*
	 * SHORTCUTS
	 */
	
	public static PredicateAtom pa(String datalog) {
		// we don't use TestUtils.datalogParser.parseAs() because here we don't care about catching parsing exceptions
		return TestUtils.parseAs(datalog, PredicateAtom.class);
	}
	
	public static OntologyPredicateAtom opa(String datalog) {
		// we don't use TestUtils.datalogParser.parseAs() because here we don't care about catching parsing exceptions
		return TestUtils.parseAs(datalog, OntologyPredicateAtom.class);
	}
	
	public static Equality eq(String t1, String t2) {
		return new Equality(parseTerm(t1), parseTerm(t2));
	}
	
	public static StrictInequality ineq(String t1, String t2) {
		return new StrictInequality(parseTerm(t1), parseTerm(t2));
	}
	
	public static Conjunction and(Formula... ff) {
		return new Conjunction(ff);
	}
	
	public static Disjunction or(Formula... ff) {
		return new Disjunction(ff);
	}
	
	public static Negation not(Formula f) {
		return new Negation(f);
	}
	
	public static Exist exist(Formula f, String... vv) {
		return new Exist(f, new ArrayList<>(Arrays.stream(vv).map(Variable::new).collect(Collectors.toList())));
	}
	
	public static ForAll forall(Formula f, String... vv) {
		return new ForAll(f, new ArrayList<>(Arrays.stream(vv).map(Variable::new).collect(Collectors.toSet())));
	}
}
