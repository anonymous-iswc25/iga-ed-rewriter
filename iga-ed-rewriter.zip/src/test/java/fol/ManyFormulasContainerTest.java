package fol;

import org.junit.Test;
import igaedrewriter.Logger;
import igaedrewriter.fol.*;
import igaedrewriter.fol.Term.TermTypeException;

import java.util.HashMap;

import static fol.FormulaTest.pa;
import static fol.TermTest.var;
import static org.junit.Assert.*;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static util.TestUtils.conj;

public class ManyFormulasContainerTest {
	
	@Test
	public void printTest1() {
		ManyFormulasContainer f = conj(":R(x,y)");
		f.add(new Negation(conj(":S(x,w)")));
		f.add(new Negation(conj(":T(w,y)")));
		Logger.debug(f.toString());
		Logger.drawLine();
		Logger.debug(f.toString());
	}
	
	@Test
	public void printTest2() {
		ManyFormulasContainer f = conj(":J(x,\"c\")");
		f.add(conj(":S(x,y)", ":S(x,z)", "y\\=z"));
		Logger.debug(f.toString());
		Logger.drawLine();
		Logger.debug(f.toString());
	}
	
	@Test
	public void editTest() throws TermTypeException {
		Variable x = var("x");
		Variable y = var("y");
		PredicateAtom a = pa(":J(x,\"c\")");
		
		ManyFormulasContainer f = new Conjunction(a);
		assertTrue(f.contains(a));
		
		a.replaceVariable(x, y);
		assertTrue(f.contains(a));
		
		f = new Conjunction(a);
		PredicateAtom a2 = a.clone();
		f.replaceVariables(new HashMap<Variable,Variable>() {{ put(y, x); }});
		assertTrue (f.contains(a));
		assertFalse(f.contains(a2));
	}
	
	@Test
	public void containsTest() {
		ManyFormulasContainer formula = new Conjunction(
				pa(":R(x,y)"),
				new Negation(pa(":R(x,y)")));
		
		for (Formula f : formula) {
			assertTrue(formula.contains(f));
		}
	}
	
	@Test
	public void equalsTest1() {
		ManyFormulasContainer c = new Conjunction();
		ManyFormulasContainer d = new Disjunction();
		assertNotEquals(c,d);
		assertNotEquals(d,c);
	}
	
	@Test
	public void equalsTest2() {
		PredicateAtom a1 = pa(":A(x)");
		PredicateAtom a2 = pa(":B(x)");
		PredicateAtom a3 = pa(":C(x)");
		ManyFormulasContainer c = new Conjunction(a1, a2, a3);
		ManyFormulasContainer d = new Disjunction(a1, a2, a3);
		assertNotEquals(c,d);
		assertNotEquals(d,c);
	}
	
	@Test
	public void cloneTest() {
		ManyFormulasContainer f = conj(":R(x,y)", ":S(x,z)", "y\\=z");
		ManyFormulasContainer f2 = f.clone();
		f2.replaceVariables(new HashMap<Variable,Variable>() {{
			put(var("x"), var("k"));
		}});
		
		assertFalse(f.getVariables().contains(var("k")));
		assertTrue(f2.getVariables().contains(var("k")));
		assertNotEquals(f, f2);
	}
}
