package fol;

import org.junit.Test;
import igaedrewriter.fol.*;

import java.util.Arrays;
import java.util.Collections;

import static fol.DataConstantTest.stringConstant;
import static fol.TermTest.var;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;

public class MostGeneralUnifierTest {
	@Test
	public void testUnifiable1() {
		PredicateAtom[] atoms = { };
		Substitution mgu = MostGeneralUnifier.findMGU(atoms);
		assertNotNull(mgu);
		System.out.println("MGU: " + mgu);
	}
	
	@Test
	public void testUnifiable2() {
		PredicateAtom[] atoms = {
				new PredicateAtom("P", Arrays.asList(var("x"), stringConstant("a"))),
		};
		
		Substitution mgu = MostGeneralUnifier.findMGU(atoms);
		assertNotNull(mgu);
		System.out.println("MGU: " + mgu);
	}
	
	@Test
	public void testUnifiable3() {
		PredicateAtom[] atoms = {
				new PredicateAtom("P", Arrays.asList(var("x"), stringConstant("a"))),
				new PredicateAtom("P", Arrays.asList(stringConstant("c"), var("y"))),
				new PredicateAtom("P", Arrays.asList(var("z"), var("y")))
		};
		
		Substitution mgu = MostGeneralUnifier.findMGU(atoms);
		assertNotNull(mgu);
		System.out.println("MGU: " + mgu);
	}
	
	@Test
	public void testUnifiable4() {
		PredicateAtom[] atoms = {
				new PredicateAtom("R", Arrays.asList(stringConstant("a"), var("x"))),
				new PredicateAtom("R", Arrays.asList(var("x"), var("x"))),
				new PredicateAtom("R", Arrays.asList(var("x"), stringConstant("a")))
		};
		
		Substitution mgu = MostGeneralUnifier.findMGU(atoms);
		assertNotNull(mgu);
		System.out.println("MGU: " + mgu);
	}
	
	@Test
	public void testNotUnifiable1() {
		PredicateAtom[] atoms = {
				new PredicateAtom("P", Arrays.asList(stringConstant("a"), var("y"))),
				new PredicateAtom("P", Arrays.asList(stringConstant("c"), var("y")))
		};
		
		Substitution mgu = MostGeneralUnifier.findMGU(atoms);
		assertNull(mgu);
	}
	
	@Test
	public void testNotUnifiable2() {
		PredicateAtom[] atoms = {
				new PredicateAtom("C", Collections.singletonList(var("x"))),
				new PredicateAtom("D", Collections.singletonList(var("x")))
		};
		
		Substitution mgu = MostGeneralUnifier.findMGU(atoms);
		assertNull(mgu);
	}
	
	@Test
	public void testNotUnifiable3() {
		PredicateAtom[] atoms = {
				new PredicateAtom("R", Arrays.asList(stringConstant("a"), var("x"))),
				new PredicateAtom("R", Arrays.asList(var("x"), var("x"))),
				new PredicateAtom("R", Arrays.asList(var("x"), stringConstant("b")))
		};
		
		Substitution mgu = MostGeneralUnifier.findMGU(atoms);
		assertNull(mgu);
	}
}
