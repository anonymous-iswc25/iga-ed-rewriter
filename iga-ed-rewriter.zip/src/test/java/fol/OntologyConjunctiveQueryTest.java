package fol;

import org.junit.Test;
import igaedrewriter.Logger;
import igaedrewriter.fol.Conjunction;
import igaedrewriter.fol.Term.TermTypeException;
import igaedrewriter.fol.Variable;
import igaedrewriter.policy.OntologyConjunctiveQuery;
import igaedrewriter.parser.ParserException;
import util.TestUtils;

import java.util.Collection;
import java.util.HashSet;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static igaedrewriter.fol.Variable.BLANK_VAR_SYMBOL;
import static util.TestUtils.*;

public class OntologyConjunctiveQueryTest {
	
	@Test
	public void parsingTest() throws ParserException, TermTypeException {
		OntologyConjunctiveQuery cq1 = buildCQ("Q():- :R(x,y), :S(x,y), :T(y,z).", "1");
		OntologyConjunctiveQuery cq2 = buildCQ("Q():- z \\= y, :R(x,y), :R(x,z)  .", "2");
		OntologyConjunctiveQuery cq3 = buildCQ("Q():- not(  z= y), :R(x,y), :R(x,z), :R(x,w)  .", "3");
		OntologyConjunctiveQuery cq4 = buildCQ("Q():- not(  z= y), not(  z= w), not(y= w), :R(x,y), :R(x,z), :R(x,w), :S(x,a)  .", "4");
		OntologyConjunctiveQuery cq5 = buildCQ("Q():- :R(x,y), :R(x,y), :R(x,z), :R(x,w), :R(x,a), :R(x,b), :S(x,h), y\\=z, w\\=z, y\\=w, w\\=y, a\\=b .", "5");
		
		// TEST ObjectConstants
		assertDoesNotThrow(()->buildCQ("Q():- :R(x,<http://test.org#myObject>).", "6"));
		
		assertTrue(cq1.hasPredicate(explicitIRIPrefix(":R")));
		assertTrue(cq1.hasPredicate(explicitIRIPrefix(":S")));
		assertTrue(cq1.hasPredicate(explicitIRIPrefix(":T")));
		assertTrue(cq2.hasPredicate(explicitIRIPrefix(":R")));
		assertFalse(cq2.hasPredicate(explicitIRIPrefix(":S")));
		assertFalse(cq2.hasPredicate(explicitIRIPrefix(":T")));
		
		assertFalse(cq1.hasInequalities());
		assertTrue(cq2.hasInequalities());
		assertTrue(cq3.hasInequalities());
		assertTrue(cq4.hasInequalities());
		assertTrue(cq5.hasInequalities());
		
		assertEquals(0, cq1.getPredicateAtomsJoiningInequalities().size());
		assertEquals(2, cq2.getPredicateAtomsJoiningInequalities().size());
		assertEquals(2, cq3.getPredicateAtomsJoiningInequalities().size());
		assertEquals(3, cq4.getPredicateAtomsJoiningInequalities().size());
		assertEquals(5, cq5.getPredicateAtomsJoiningInequalities().size());
	}
	
	@Test
	public void equalityTest() throws ParserException, TermTypeException {
		OntologyConjunctiveQuery cq1 = buildCQ("Q(x):- :R(x,y).", "1");
		OntologyConjunctiveQuery cq2 = buildCQ("Q(v):- :R(v,w).", "2");
		OntologyConjunctiveQuery cq3 = buildCQ("Q(v):- :R(w,v).", "3");
		OntologyConjunctiveQuery cq4 = buildCQ("Q(x):- :S(x,y).", "4");
		OntologyConjunctiveQuery cq5 = buildCQ("Q():- :R(x,y).", "5");
		
		OntologyConjunctiveQuery cq6 = buildCQ("Q(x,y):- :R(x,y), :A(x), :B(y), :S(x, k).", "6");
		OntologyConjunctiveQuery cq7 = buildCQ("Q(v,w):- :R(v,w), :A(v), :B(w), :S(x, z).", "7");
		
		
		
		OntologyConjunctiveQuery cq8 = buildCQ("Q(a,b):- :A(a), :B(b), :R(a,b).", "8");
		
		assertNotEquals(cq1, cq3);
		assertNotEquals(cq1, cq4);
		assertNotEquals(cq1, cq5);
	}
	
	@Test
	public void distinguishVariables() throws ParserException, TermTypeException {
		OntologyConjunctiveQuery cq = buildCQ("Q():- :R(x,_), :S(x,_), :T(x,_) .", "1");
		
		OntologyConjunctiveQuery cq2 = cq.clone();
		cq2.explicitNondistinguishedNonsharedVariables();
		Collection<String> variablesNames2 = cq2.getVariables().stream().map(Variable::getName).collect(Collectors.toSet());
		Logger.debug(variablesNames2);
		assertEquals(4, variablesNames2.size());
		assert( variablesNames2.contains("x"));
		assert(!variablesNames2.contains(BLANK_VAR_SYMBOL));
		
		OntologyConjunctiveQuery cq3 = cq.clone();
		cq3.explicitNondistinguishedNonsharedVariables(null, variablesNames2);
		Collection<String> variablesNames3 = cq3.getVariables().stream().map(Variable::getName).collect(Collectors.toSet());
		Logger.debug(variablesNames3);
		assertEquals(4, variablesNames3.size());
		assert( variablesNames3.contains("x"));
		assert(!variablesNames3.contains(BLANK_VAR_SYMBOL));
	}
	
	public static OntologyConjunctiveQuery buildCQ(String source, String cqName) throws ParserException, TermTypeException {
		System.out.println("\nCQ #" + cqName);
		return buildCQ(source);
	}
	
	public static OntologyConjunctiveQuery buildCQ(String source) throws ParserException, TermTypeException {
		OntologyConjunctiveQuery cq = fromDatalog(source);
		System.out.println(cq);
		System.out.println("Standard predicate atoms: " + cq.getStandardPredicateAtoms());
		System.out.println("NR predicate atoms: " + cq.getPredicateAtomsJoiningInequalities());
		//System.out.println("Variables: " + cq.getVariables());
		System.out.println("Free variables: " + cq.getFreeVariables());
		System.out.println("Quantified variables: " + cq.getQuantifiedVariables());
		return cq;
	}
	
	@Test
	public void cloneTest() throws ParserException, TermTypeException {
		OntologyConjunctiveQuery cq1 = buildCQ("Q():- :R(x,y), :R(x,z), :R(x,a), :R(x,b), not(y=z), a\\=b .", "1");
		
		OntologyConjunctiveQuery cq2 = cq1.clone();	// deep copy
		Conjunction body1 = cq1.getBody();
		Conjunction body2 = cq2.getBody();
		testInequality(cq1, cq2);		// variables in cq1 and cq2 should be bound to distinct CQS
		testInequality(body1, body2);	// variables in body1 and body2 should be bound to distinct CQS
		
		body1.unbindVariables();
		body2.unbindVariables();
		Logger.debug(body1);
		Logger.debug(body2);
		testEquality(new HashSet<>(body1.getFormulas()), new HashSet<>(body2.getFormulas()));
	}
	
	protected static OntologyConjunctiveQuery fromDatalog(String source) throws ParserException, TermTypeException {
		return TestUtils.datalogParser.parseAs(source, OntologyConjunctiveQuery.class);
	}
}
