package fol;

import org.junit.Assert;
import org.junit.Test;
import igaedrewriter.fol.*;
import igaedrewriter.fol.PredicateAtom.PredicateArityException;
import igaedrewriter.fol.Term.TermTypeException;
import igaedrewriter.fol.OntologyPredicateAtom;
import igaedrewriter.parser.ParserException;
import igaedrewriter.util.OntologyUtils;
import util.TestUtils;

import java.net.URISyntaxException;
import java.util.*;

import static fol.TermTest.var;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static igaedrewriter.fol.OntologyPredicateAtom.Type.*;
import static igaedrewriter.fol.Variable.BLANK_VAR_SYMBOL;
import static igaedrewriter.fol.Variable.getUndistinguishedNonSharedVariable;
import static util.TestUtils.*;

public class OntologyPredicateAtomTest {
	
	@Test
	public void parsingTest() throws ParserException, TermTypeException, PredicateArityException, URISyntaxException {
		OntologyPredicateAtom a1 = newRole(":R", "x", "y");
		OntologyPredicateAtom a2 = fromDatalog(":R(  x ,y)");
		OntologyPredicateAtom a3 = fromDatalog(":R    (x,y)");
		OntologyPredicateAtom a4 = fromDatalog(":S(x,y)");
		OntologyPredicateAtom a5 = fromDatalog(":R(x,z)");
		
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);
		System.out.println(a5);
		
		testEquality(a1, a1);
		testEquality(a1, a2);
		testEquality(a1, a3);
		testEquality(a2, a3);
		testInequality(a1, a4);
		testInequality(a1, a5);
		testInequality(a4, a5);
		
		// test parsing exceptions
		assertThrows(ParserException.class, () -> fromDatalog(""));
		assertThrows(ParserException.class, () -> fromDatalog("A"));
		assertThrows(ParserException.class, () -> fromDatalog(":A()"));
		assertThrows(ParserException.class, () -> fromDatalog(":R(x,)"));
		assertThrows(ParserException.class, () -> fromDatalog(":S(,y)"));
	}
	
	@Test
	public void distinguishVariables() throws ParserException, TermTypeException {
		OntologyPredicateAtom a = fromDatalog(":R(x, _)");
		a.explicitVariables(new HashSet<>(), new HashSet<>());
		assert( a.getVariablesNames().contains("x"));
		assert(!a.getVariablesNames().contains(BLANK_VAR_SYMBOL));
		assertEquals(fromDatalog(":R(x, xx)"), a);
	}
	
	@Test
	public void subclassTest() throws ParserException, TermTypeException {
		assertTrue(Atom.class.isAssignableFrom(fromDatalog(":R(x,y)").getClass()));
	}
	
	@Test
	public void unificationMappingTest() throws ParserException, TermTypeException {
		OntologyPredicateAtom a1 = fromDatalog(":J(x,y)");
		OntologyPredicateAtom a2 = fromDatalog(":J(x,x)");
		OntologyPredicateAtom a3 = fromDatalog(":J(x,\"a\")");
		OntologyPredicateAtom a4 = fromDatalog(":J(x,z)");
		OntologyPredicateAtom a5 = fromDatalog(":J(y,x)");
		OntologyPredicateAtom a6 = fromDatalog(":J(y,z)");
		OntologyPredicateAtom a7 = fromDatalog(":J(z,z)");
		OntologyPredicateAtom a8 = fromDatalog(":J(z,w)");
		OntologyPredicateAtom a9 = fromDatalog(":J(y,\"a\")");
		OntologyPredicateAtom a10 = fromDatalog(":J(z,\"b\")");
		OntologyPredicateAtom a11 = fromDatalog(":J(z,123)");
		OntologyPredicateAtom a12 = fromDatalog(":K(x,y)");
		
		assertEquals(0, getUnificationSize(a1, a1));
		assertEquals(1, getUnificationSize(a1, a2));
		assertEquals(1, getUnificationSize(a1, a3));
		assertEquals(1, getUnificationSize(a1, a4));
		assertEquals(2, getUnificationSize(a1, a5));
		assertEquals(2, getUnificationSize(a1, a6));
		assertEquals(2, getUnificationSize(a1, a7));
		assertEquals(2, getUnificationSize(a1, a8));
		assertEquals(2, getUnificationSize(a1, a9));
		assertEquals(2, getUnificationSize(a1, a10));
		assertEquals(2, getUnificationSize(a1, a11));
		assertNull(a1.getUnificationMapping(a12));
		
		assertEquals(0, getUnificationSize(a2, a2));
		assertEquals(1, getUnificationSize(a2, a7));
		assertNull(a2.getUnificationMapping(a1));
		assertNull(a2.getUnificationMapping(a3));
		assertNull(a2.getUnificationMapping(a4));
		assertNull(a2.getUnificationMapping(a5));
		assertNull(a2.getUnificationMapping(a6));
		assertNull(a2.getUnificationMapping(a8));
		assertNull(a2.getUnificationMapping(a9));
		assertNull(a2.getUnificationMapping(a10));
		assertNull(a2.getUnificationMapping(a11));
		assertNull(a2.getUnificationMapping(a12));
		
		assertEquals(0, getUnificationSize(a3, a3));
		assertEquals(1, getUnificationSize(a3, a9));
		assertNull(a3.getUnificationMapping(a1));
		assertNull(a3.getUnificationMapping(a2));
		assertNull(a3.getUnificationMapping(a4));
		assertNull(a3.getUnificationMapping(a5));
		assertNull(a3.getUnificationMapping(a6));
		assertNull(a3.getUnificationMapping(a7));
		assertNull(a3.getUnificationMapping(a8));
		assertNull(a3.getUnificationMapping(a10));
		assertNull(a3.getUnificationMapping(a11));
		assertNull(a3.getUnificationMapping(a12));
	}
	
	private int getUnificationSize(PredicateAtom a1, PredicateAtom a2) {
		return Objects.requireNonNull(a1.getUnificationMapping(a2)).size();
	}
	
	@Test
	public void termTypeTest() throws ParserException, TermTypeException {
		// OntologyPredicateAtom a1 = fromDatalog(":J(IRI_FUNCT_1234 (\"http://example.com#Bob\"), x)");  // Mastro's version
		OntologyPredicateAtom a1 = fromDatalog(":J(<http://example.com#Bob>, x)");  // Mastro's version
		OntologyPredicateAtom a2 = fromDatalog(":J(x, \"http://example.com#Bob\")");
		Assert.assertEquals(Term.Type.OBJECT, a1.getTerm(0).getType());
		Assert.assertEquals(Term.Type.DATA,   a1.getTerm(1).getType());
		Assert.assertEquals(Term.Type.OBJECT, a2.getTerm(0).getType());
		Assert.assertEquals(Term.Type.DATA,   a2.getTerm(1).getType());
	}
	
	@Test
	public void applyUnification() throws OperationNotAllowedException, TermTypeException, PredicateArityException, URISyntaxException {
		OntologyPredicateAtom a = newRole(":R", "a", "b");
		assertNotEquals(a.getTerm(0), a.getTerm(1));
		a.multipleReplacement(Arrays.asList(
				var("a"),
				var("b"),
				var("c")));
		testEquality(a.getTerm(0), a.getTerm(1));
	}
	
	@Test
	public void cardinalityCheck() {
		// cardinality 0
		assertThrows(ParserException.class, () -> fromDatalog(":A()"));
		assertThrows(PredicateArityException.class, () -> newAtom(":A", Collections.emptyList(), CONCEPT));
		
		// cardinality 1
		assertDoesNotThrow(() -> fromDatalog(":A(x)"));
		assertDoesNotThrow(() -> newConcept(":A", "x"));
		assertThrows(ParserException.class, () -> fromDatalog(":R(x)"));
		assertThrows(ParserException.class, () -> fromDatalog(":J(x)"));
		assertThrows(PredicateArityException.class, () -> newAtom(":R", Collections.singletonList(var("x")), ROLE));
		assertThrows(PredicateArityException.class, () -> newAtom(":J", Collections.singletonList(var("x")), ATTRIBUTE));
		
		// cardinality 2
		assertThrows(ParserException.class, () -> fromDatalog(":C(x,y)"));
		assertDoesNotThrow(() -> fromDatalog(":R(x,y)"));
		assertDoesNotThrow(() -> fromDatalog(":J(x,y)"));
		assertDoesNotThrow(() -> newRole(":R", "x", "y"));
		assertDoesNotThrow(() -> newAttribute(":J", "x", "y"));
		
		// cardinality 3
		assertThrows(ParserException.class, () -> fromDatalog(":C(x,y,z)"));
		assertThrows(ParserException.class, () -> fromDatalog(":J(x,y,z)"));
		assertThrows(ParserException.class, () -> fromDatalog(":R(x,y,z)"));
		assertThrows(PredicateArityException.class, () -> newAtom(":C",
				Arrays.asList(var("x"), var("y"), var("z")), CONCEPT));
		assertThrows(PredicateArityException.class, () -> newAtom(":R",
				Arrays.asList(var("x"), var("y"), var("z")), ROLE));
		assertThrows(PredicateArityException.class, () -> newAtom(":J",
				Arrays.asList(var("x"), var("y"), var("z")), ATTRIBUTE));
	}
	
	@Test
	public void explicitVariables() throws PredicateArityException, TermTypeException, URISyntaxException {
		OntologyPredicateAtom a = new OntologyPredicateAtom("http://www.example.org/R",
				Arrays.asList(getUndistinguishedNonSharedVariable(), getUndistinguishedNonSharedVariable()), ROLE);
		a.explicitVariables(new HashSet<>(Arrays.asList("a", "b", "c")), new HashSet<>());
		assertNotEquals(a.getTerm(0), a.getTerm(1));
	}
	
	@Test
	public void separateConstantAssignment() throws ParserException, TermTypeException {
		OntologyPredicateAtom a = fromDatalog(":J(x,\"a\")");
		Formula result = a.explode(Formula.LC_LATIN_ALPHABET);
		System.out.println(result);
	}
	
	@Test
	public void cloneTest() throws TermTypeException, ParserException {
		OntologyPredicateAtom a1 = fromDatalog(":R(x,y)");
		OntologyPredicateAtom a2 = a1.clone();	// deep copy
		assertEquals(a1.hashCode(), a2.hashCode());
		
		a1.replaceVariable(var("x"), var("temp"));
		testInequality(a1, a2);
		
		a2.replaceVariable(var("x"), var("temp"));
		assertEquals(a1.hashCode(), a2.hashCode());
	}
	
	@SuppressWarnings("SameParameterValue")
	private static OntologyPredicateAtom newConcept(String prefixedIRI, String varName) throws PredicateArityException, TermTypeException, URISyntaxException {
		return newAtom(prefixedIRI,
				Collections.singletonList(var(varName)),
				CONCEPT);
	}
	
	@SuppressWarnings("SameParameterValue")
	private static OntologyPredicateAtom newRole(String prefixedIRI, String var1Name, String var2Name) throws PredicateArityException, TermTypeException, URISyntaxException {
		return newAtom(prefixedIRI,
				Arrays.asList(var(var1Name), var(var2Name)),
				ROLE);
	}
	
	@SuppressWarnings("SameParameterValue")
	private static OntologyPredicateAtom newAttribute(String prefixedIRI, String var1Name, String var2Name) throws PredicateArityException, TermTypeException, URISyntaxException {
		return newAtom(prefixedIRI,
				Arrays.asList(var(var1Name), var(var2Name)),
				ATTRIBUTE);
	}
	
	private static OntologyPredicateAtom newAtom(String prefixedIRI, List<Term> variables, OntologyPredicateAtom.Type type) throws PredicateArityException, URISyntaxException, TermTypeException {
		return new OntologyPredicateAtom(
				OntologyUtils.explicitIRIPrefix(prefixedIRI, TestUtils.ontology),
				variables, type);
	}
	
	public static OntologyPredicateAtom fromDatalog(String source) throws ParserException, TermTypeException {
		return TestUtils.datalogParser.parseAs(source, OntologyPredicateAtom.class);
	}
}
