package fol;

import org.junit.Test;
import igaedrewriter.Logger;
import igaedrewriter.db.SQLCompiler;
import igaedrewriter.fol.*;
import igaedrewriter.parser.ParserException;
import util.TestUtils;

import java.util.*;
import java.util.stream.Collectors;

import static db.SQLTestUtils.toSql;
import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;
import static igaedrewriter.util.Utils.filterByClass;
import static util.TestUtils.*;

public class PredicateAtomTest {
	/* For the moment, I've just moved here the test that was focusing on PredicateAtom's methods.
	   TODO: Implement other unit test for general PredicateAtoms. Suggestions:
	 *  - copy something from OntologyPredicateAtomTest
	 *  - use a DBSchema
	 *  - consider n-ary predicates (with n>2)
	 */
	
	@Test
	public void separateEqualVariables() {
		Conjunction c = conj(":R(x, x)", ":S(x, y)", ":T(y, y)");
		Set<String> reservedVariablesNames = new HashSet<>(c.getVariablesNames());
		c.replaceAll(f -> {
			if (f instanceof PredicateAtom) {
				return ((PredicateAtom) f).explode(reservedVariablesNames);
			}
			else return f;
		});
		assertEquals(3, c.size());
		
		Formula f = c.getPrenexForm(Formula.LC_LATIN_ALPHABET);
		f.flatten(true);
		c = (Conjunction) ((Exist) f).getContent();
		assertEquals(5, c.size());	// after being flattened, the conjunction contains 2 more subformulas
		assertEquals(3, filterByClass(c.getFormulas(), PredicateAtom.class, Collectors.toSet()).size());
		assertEquals(2, filterByClass(c.getFormulas(), Equality.class, Collectors.toSet()).size());
	}
	
	@Test
	public void equalsTest() {
		PredicateAtom pa1 = newPredicateAtom("R","x","y");
		PredicateAtom pa2 = newPredicateAtom("R","x","y");
		PredicateAtom pa3 = newPredicateAtom("R","y","x");
		assertEquals(pa1, pa2);
		assertEquals(pa1.hashCode(), pa2.hashCode());
		assertNotEquals(pa1, pa3);
		assertNotEquals(pa1.hashCode(), pa3.hashCode());
	}
	
	@Test
	public void toSqlTest() throws SQLCompiler.SQLificationException {
		PredicateAtom a = newPredicateAtom("R", "x", "y");
		String select = toSql(a),
				selectBool = toSql(a, "x", "y"),
				selectX = toSql(a,"x"),
				selectZ = toSql(a,"z");
		//selectStar = toSql(a, "*");
		
		Logger.debug(select);
		Logger.debug(selectBool);
		Logger.debug(selectX);
		Logger.debug(selectZ);
		
		assertTrue (select.contains(" AS x"));
		assertTrue (select.contains(" AS y"));
		
		assertTrue (selectBool.contains("SELECT " + SQLCompiler.BOOLEAN_WILDCARD) || selectBool.contains(" AS x"));
		assertTrue (selectBool.contains("SELECT " + SQLCompiler.BOOLEAN_WILDCARD) || selectBool.contains(" AS y"));
		
		assertFalse(selectX.contains(" AS x"));
		assertTrue (selectX.contains(" AS y"));
		
		assertTrue (selectZ.contains(" AS x"));
		assertTrue (selectZ.contains(" AS y"));
	}
	
	private static PredicateAtom newPredicateAtom(String predicateName, List<Term> terms) {
		return new PredicateAtom(predicateName, terms);
	}
	
	private static PredicateAtom newPredicateAtom(String predicateName, String... variables) {
		return new PredicateAtom(predicateName, variablesList(variables));
	}
	
	public static PredicateAtom fromDatalog(String source) throws ParserException, Term.TermTypeException {
		return TestUtils.datalogParser.parseAs(source, PredicateAtom.class);
	}
}
