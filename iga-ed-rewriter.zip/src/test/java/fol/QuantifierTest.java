package fol;

import org.junit.Test;
import igaedrewriter.Logger;
import igaedrewriter.fol.*;
import util.TestUtils;

import static fol.FormulaTest.pa;

public class QuantifierTest {
	@Test
	public void flatteningTest() {
		PredicateAtom a = pa("R(x,y)");
		Variable x = new Variable("x"),
				y = new Variable("y");
		Formula f2 = new Exist(new Exist(a,x),y);
		Formula f1 = new Exist(new ForAll(a,x),y);
		Formula f3 = new Exist(a,x,y);
		
		f1.flatten(true);
		f2.flatten(true);
		
		Logger.debug("f1: " + f1);
		Logger.debug("f2: " + f2);
		Logger.debug("f3: " + f3);
		TestUtils.testEquality(f3,f2);
		TestUtils.testInequality(f3,f1);
	}
}
