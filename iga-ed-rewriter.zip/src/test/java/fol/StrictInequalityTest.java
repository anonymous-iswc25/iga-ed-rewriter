package fol;

import igaedrewriter.fol.Term.TermTypeException;
import igaedrewriter.parser.ParserException;
import igaedrewriter.fol.StrictInequality;
import org.junit.Test;
import util.TestUtils;

import static fol.TermTest.var;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static util.TestUtils.testEquality;
import static util.TestUtils.testInequality;

public class StrictInequalityTest {
	
	@Test
	public void parsingTest() throws ParserException, TermTypeException {
		StrictInequality si1 = new StrictInequality(var("x"), var("y"));
		StrictInequality si2 = fromDatalog("y\\=   x");
		StrictInequality si3 = fromDatalog("not  (   x  =y)");
		StrictInequality si4 = fromDatalog("x\\=z");
		
		System.out.println(si1);
		System.out.println(si2);
		System.out.println(si3);
		System.out.println(si4);
		
		// test equalities
		testEquality(si1, si1);
		testEquality(si1, si2);
		testEquality(si1, si3);
		testEquality(si2, si3);
		testInequality(si1, si4);
		
		// test parsing exceptions
		assertThrows(ParserException.class, () -> fromDatalog(""));
		assertThrows(ParserException.class, () -> fromDatalog("a"));
		assertThrows(ParserException.class, () -> fromDatalog("a=b"));
		assertThrows(ParserException.class, () -> fromDatalog("not a=b"));
	}
	
	@Test
	public void cloneTest() {
		StrictInequality si1 = new StrictInequality(var("x"), var("y"));
		StrictInequality si2 = si1.clone();	// deep copy
		testEquality(si1.hashCode(), si2.hashCode());
		
		si1.replaceVariable(var("x"), var("temp"));
		testInequality(si1, si2);
		
		si2.replaceVariable(var("x"), var("temp"));
		testEquality(si1.hashCode(), si2.hashCode());
	}
	
	protected static StrictInequality fromDatalog(String source) throws ParserException, TermTypeException {
		return TestUtils.datalogParser.parseAs(source, StrictInequality.class);
	}
}
