package fol;

import org.junit.Test;
import igaedrewriter.fol.*;
import igaedrewriter.fol.ObjectConstant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static igaedrewriter.fol.Datatype.XSD_STRING;
import static util.TestUtils.testInequality;

public class TermTest {
	
	@Test
	public void equalityTest() throws DataConstant.DatatypeNoMatchException {
		Term vx = var("x");
		Term vy = var("y");
		Term oc = new ObjectConstant("x");
		Term dc = new DataConstant("x", XSD_STRING);
		
		testInequality(vx.toString(), vy.toString());
		assertEquals(vx.toString(), oc.toString());
		testInequality(vx.toString(), dc.toString());
		testInequality(oc.toString(), dc.toString());
		testInequality(vx, vy);
		testInequality(vx, oc);
		testInequality(vx, dc);
		testInequality(oc, dc);
	}
	
	protected static Variable var(String name) {
		return new Variable(name);
	}
}
