package fol;

import org.junit.Test;
import igaedrewriter.fol.False;
import igaedrewriter.fol.True;

import static util.TestUtils.testEquality;
import static util.TestUtils.testInequality;

public class TrueFalseTest {
	
	@Test
	public void equalityTest() {
		testInequality(True.getInstance(), False.getInstance());
		testEquality(True.getInstance().negate(), False.getInstance());
		testEquality(True.getInstance(), False.getInstance().negate());
	}
}
