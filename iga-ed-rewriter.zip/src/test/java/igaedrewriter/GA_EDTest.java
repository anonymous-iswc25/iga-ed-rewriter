package igaedrewriter;

import org.junit.Test;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.xml.sax.SAXException;
import igaedrewriter.db.SQLCompiler;
import igaedrewriter.fol.PredicateAtom;
import igaedrewriter.fol.Term;
import igaedrewriter.parser.ParserException;
import igaedrewriter.policy.OntologyConjunctiveQuery;
import igaedrewriter.util.IOUtils;
import igaedrewriter.util.Utils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.Arrays;

public class GA_EDTest {
	
	boolean STORE_LOG = true;
	boolean STORE_RESULTS = false;
	
	private static Configuration conf;
	private static String performancesFilepath;
	private static boolean headerPrinted = false;
	
	@Test
	public void main() throws OWLOntologyCreationException, URISyntaxException, ClassNotFoundException, IllegalAccessException, SAXException, SQLException, InterruptedException, IOException, ParserException, PredicateAtom.PredicateArityException, Term.TermTypeException, SQLCompiler.SQLificationException, OntologyConjunctiveQuery.UnsafePolicyException, OWLOntologyStorageException, AtomRewriter.AtomRewriterException {
		conf = new Configuration("src/test/resources/owl2bench/config.ini");
		if (STORE_LOG) Logger.setLogPath(conf.inputPath);
		String policyName = conf.policyFilename;
		int startIndex = policyName.indexOf("/");
		int endIndex = policyName.indexOf(".json");
		policyName = policyName.substring(startIndex+1, endIndex);
		performancesFilepath = conf.prependInputPath(conf.dbName + "_" + policyName + "_performances.tsv");
		
		/*===============*
		 *  START TESTS  *
		 *===============*/

		runTest(1, "test");
		
		Logger.info("Done");
	}
	
	private static void runTest(int testNum, String testName) throws OWLOntologyCreationException, URISyntaxException, ClassNotFoundException, SAXException, SQLException, IllegalAccessException, IOException, ParserException, PredicateAtom.PredicateArityException, Term.TermTypeException, SQLCompiler.SQLificationException, InterruptedException, OWLOntologyStorageException, AtomRewriter.AtomRewriterException {
		executeQueries(testName, false);
	}
	
	@SuppressWarnings("SameParameterValue")
	private static void executeQueries(String testName, boolean forceDistinct) throws OWLOntologyCreationException, ClassNotFoundException, IOException, SQLException, ParserException, Term.TermTypeException, PredicateAtom.PredicateArityException, URISyntaxException, AtomRewriter.AtomRewriterException, SQLCompiler.SQLificationException {
		final int[] queriesToRun;
		//queriesToRun = new int[]{1,2,3,4,5,6,7,8,9,10};
		queriesToRun = new int[]{1};
		if(!headerPrinted) {
			IOUtils.writeFile(performancesFilepath,
					String.join("\t",
							Arrays.asList("test type", "q", "Rtime", "Etime", "results", "paddings", "timestamp")));
			headerPrinted = true;
		}
		for (int q : queriesToRun) {
			conf.queryFilename = "test_queries/" + q + ".sparql";
			QueryChecker qc = new QueryChecker(conf);
			final long start1 = System.currentTimeMillis();
			String rewriting = qc.igaEntails();
			final long end1 = System.currentTimeMillis();
			final long rewritingTime = end1 - start1;
			final long start2 = System.currentTimeMillis();
			Logger.info("EXECUTING Q: " + q);
			int outputSize = qc.sqlExecution(rewriting);
			final long end2 = System.currentTimeMillis();
			final long executionTime = end2 - start2;

			String relevantPaddings = qc.getRelevantPaddings().toString();
			IOUtils.writeLine(performancesFilepath, String.join("\t", Arrays.asList(
					testName, "" + q, "" + rewritingTime, "" + executionTime, "" + outputSize, relevantPaddings, Utils.getTimestamp(true))));
		}
	}
}
