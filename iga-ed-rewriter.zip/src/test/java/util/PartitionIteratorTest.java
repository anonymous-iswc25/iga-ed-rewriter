package util;

import org.junit.Test;

import igaedrewriter.util.PartitionIterator;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class PartitionIteratorTest {
	@Test
	public void countTest() {
		List<Integer> input = new ArrayList<>();
		for (int i = 1; i < 10; i++ ) {
			input.add(i);
			PartitionIterator<Integer> it = new PartitionIterator<>(input);
			int count = 0;
			while(it.hasNext()) {
				it.next();
				count++;
			}
			System.out.println("i: " + i);
			System.out.println("total: " + count);
			assertEquals(BellNumber(i), count);
		}
	}
	
	private static int BellNumber(int n) {
		int[][] bellTriangle = new int[n + 1][n + 1];
		bellTriangle[0][0] = 1;
		
		for (int i = 1; i <= n; i++) {
			bellTriangle[i][0] = bellTriangle[i - 1][i - 1];
			
			for (int j = 1; j <= i; j++) {
				bellTriangle[i][j] = bellTriangle[i - 1][j - 1] + bellTriangle[i][j - 1];
			}
		}
		return bellTriangle[n][0];
	}
}
