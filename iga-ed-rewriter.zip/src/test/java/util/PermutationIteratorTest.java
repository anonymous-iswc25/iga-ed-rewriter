package util;

import org.junit.Test;

import igaedrewriter.Logger;
import igaedrewriter.util.PermutationIterator;

import java.util.*;

import static org.junit.Assert.assertEquals;

public class PermutationIteratorTest {
	@Test
	public void generationTest() {
		List<Integer> input = Arrays.asList(1, 2, 3, 1);
		
		List<List<Integer>> permutations = new ArrayList<>();
		PermutationIterator<Integer> it = new PermutationIterator<>(input);
		while(it.hasNext()) {
			permutations.add(it.next());
		}
		
		List<List<Integer>> expectedPermutations = Arrays.asList(
				Arrays.asList(1,2,3,1),
				Arrays.asList(2,1,3,1),
				Arrays.asList(3,1,2,1),
				Arrays.asList(1,3,2,1),
				Arrays.asList(2,3,1,1),
				Arrays.asList(3,2,1,1),
				Arrays.asList(3,2,1,1),
				Arrays.asList(2,3,1,1),
				Arrays.asList(1,3,2,1),
				Arrays.asList(3,1,2,1),
				Arrays.asList(2,1,3,1),
				Arrays.asList(1,2,3,1),
				Arrays.asList(1,1,3,2),
				Arrays.asList(1,1,3,2),
				Arrays.asList(3,1,1,2),
				Arrays.asList(1,3,1,2),
				Arrays.asList(1,3,1,2),
				Arrays.asList(3,1,1,2),
				Arrays.asList(2,1,1,3),
				Arrays.asList(1,2,1,3),
				Arrays.asList(1,2,1,3),
				Arrays.asList(2,1,1,3),
				Arrays.asList(1,1,2,3),
				Arrays.asList(1,1,2,3)
		);
		assertEquals(new HashSet<>(expectedPermutations), new HashSet<>(permutations));
		assertEquals(expectedPermutations.size(), permutations.size());
		
		// Since there is one duplicate in the input list,
		// each entry in the output list should appear exactly twice.
		Integer permutationOccurrence = 2;
		Map<List<Integer>,Integer> countMap = new HashMap<>();
		for (List<Integer> permutation : permutations) {
			int count = countMap.getOrDefault(permutation, 0);
			countMap.put(permutation, count+1);
		}
		for (Integer count : countMap.values()) {
			assertEquals(permutationOccurrence, count);
		}
	}
	
	@Test
	public void countTest() {
		List<Integer> input = new ArrayList<>();
		for (int i = 1; i < 10; i++ ) {
			input.add(i);
			PermutationIterator<Integer> it = new PermutationIterator<>(input);
			int count = 0;
			while(it.hasNext()) {
				it.next();
				count++;
			}
			Logger.info("i: " + i);
			Logger.info("total: " + count);
			assertEquals(factorial(i), count);
		}
	}
	
	private static long factorial(int number) {
		long result = 1;
		for (int factor = 2; factor <= number; factor++) {
			result *= factor;
		}
		return result;
	}
}
