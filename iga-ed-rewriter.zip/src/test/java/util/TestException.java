package util;

/**
 * Unchecked exception to be used only for unit tests.
 */
public class TestException extends RuntimeException {
	public TestException() {
		super();
	}
	public TestException(String s) {
		super(s);
	}
	public TestException(Throwable t) {
		super(t);
	}
}
