package util;

@SuppressWarnings("unused")
public class TestInputException extends TestException {
	public TestInputException() {
		super();
	}
	public TestInputException(String s) {
		super(s);
	}
	public TestInputException(Throwable t) {
		super(t);
	}
}
