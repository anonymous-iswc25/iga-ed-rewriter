package util;

import igaedrewriter.fol.*;
import igaedrewriter.fol.Term.TermTypeException;
import igaedrewriter.parser.DatalogBCQParser;
import igaedrewriter.parser.BCQParser;
import igaedrewriter.parser.ParserException;
import igaedrewriter.util.OntologyUtils;
import igaedrewriter.util.Utils;
import org.junit.Test;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;

import igaedrewriter.Configuration;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.Assert.*;

public class TestUtils {
	public static OWLOntology ontology;
	static {
		try {
			ontology = OWLManager
					.createOWLOntologyManager()
					.loadOntologyFromOntologyDocument(
							new File(TestUtils.class.getResource("/dummy-ontology/dummy-ont.owl").toURI())
					);
		} catch (OWLOntologyCreationException | URISyntaxException e) {
			e.printStackTrace();
		}
	}

	public static Configuration conf;
	static {
		try {
			conf = new Configuration("src/test/resources/dummy-ontology/config.ini");
		} catch (IOException e) {
			throw new TestInputException(e);
		}
	}
	
	public static BCQParser datalogParser = new DatalogBCQParser(ontology);

	public static String explicitIRIPrefix(String s) {
		return OntologyUtils.explicitIRIPrefix(s, ontology);
	}
	
	/**
	 * Use this method if you don't care about catching parsing exceptions.
	 * Otherwise, use TestUtils.datalogParser.parseAs().
 	 */
	public static <T> T parseAs(String source, Class<T> tClass) {
		try {
			return datalogParser.parseAs(source, tClass);
		} catch (ParserException | TermTypeException e) {
			throw new TestException(e);
		}
	}
	
	/**
	 * Use this method if you don't care about catching parsing exceptions.
	 * Otherwise, use TestUtils.datalogParser.parseAs().
	 */
	public static Formula parse(String source) {
		for (Class<? extends Cloneable> c : BCQParser.parsableClasses) {
			if (datalogParser.canBeParsedAs(source, c)) {
				Cloneable o;
				try {
					o = datalogParser.parseAs(source, c);
				} catch (ParserException | TermTypeException e) {
					throw new TestException(e);
				}
				if (o instanceof Formula) return (Formula) o;
			}
		}
		throw new TestInputException("Cannot parse string: " + source);
	}
	
	public static Collection<Formula> parse(String... sources) {
		Collection<Formula> result = new LinkedList<>();
		for (String s : sources) result.add(parse(s));
		return result;
	}
	
	public static Conjunction conj(String... sources) {
		return new Conjunction(parse(sources));
	}
	
	public static Disjunction disj(String... sources) {
		return new Disjunction(parse(sources));
	}
	
	public static List<Variable> variablesList(String... varNames) {
		return Arrays.stream(varNames).map(Variable::new).collect(Collectors.toList());
	}
	
	public static Variable[] variablesArray(String... varNames) {
		return Arrays.stream(varNames).map(Variable::new).toArray(Variable[]::new);
	}
	
	@Test
	public void firstMatchingGroup() {
		assertEquals("E", Utils.getFirstMatchingGroup("A(B)C|D(E)F", "DEF"));
		assertNull(Utils.getFirstMatchingGroup("A(B)C|D(E)F", "DEFG"));
		assertNull(Utils.getFirstMatchingGroup("A(B)C|D(E)FG", "DEF"));
		assertNull(Utils.getFirstMatchingGroup("A(B)C|D(E)FG", "F"));
	}
	
	public static void testEquality(Object o1, Object o2) {
		assert o1.equals(o2);
		assert o2.equals(o1); // this is not strictly redundant, e.g., the equals() method may differ depending on the subclass
		assert o1.hashCode() == o2.hashCode();
	}
	
	public static void testInequality(Object o1, Object o2) {
		assert !o1.equals(o2);
		assert !o2.equals(o1); // this is not strictly redundant, e.g., the equals() method may differ depending on the subclass
		assert o1.hashCode() != o2.hashCode();
	}
}
