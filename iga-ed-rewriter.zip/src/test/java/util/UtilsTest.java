package util;

import org.junit.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static igaedrewriter.util.Utils.*;

public class UtilsTest {
	
	@Test
	public void cartesianProductTest() {
		Set<Integer>
				setA = new HashSet<>(Arrays.asList(1,2)),
				setB = new HashSet<>(Arrays.asList(3,4));
		
		Set<List<Integer>> result0 = new HashSet<>();
		Set<List<Integer>> result1 = new HashSet<>();
		Set<List<Integer>> result2 = new HashSet<>();
		
		result0.add(new ArrayList<>());
		
		result1.add(Collections.singletonList(1));
		result1.add(Collections.singletonList(2));
		
		result2.add(Arrays.asList(1,3));
		result2.add(Arrays.asList(1,4));
		result2.add(Arrays.asList(2,3));
		result2.add(Arrays.asList(2,4));
		
		assertEquals(result0, cartesianProduct());
		assertEquals(result1, cartesianProduct(setA));
		assertEquals(result2, cartesianProduct(setA, setB));
	}
}
