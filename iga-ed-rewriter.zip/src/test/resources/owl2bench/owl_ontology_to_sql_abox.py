import rdflib
from rdflib import RDF, RDFS, OWL
import argparse
import sys


def get_local(uri):
    """
	Extract the local name from a URIRef by splitting at '#' or '/'.
	"""
    u = str(uri)
    if '#' in u:
        return u.split('#')[-1]
    return u.rstrip('/').rsplit('/', 1)[-1]


def main():
    parser = argparse.ArgumentParser(
        description="Convert an RDF/XML ontology of NamedIndividuals into SQL DDL/DML statements"
    )
    parser.add_argument(
        'input', help="Path to the input RDF/XML file containing NamedIndividual axioms"
    )
    parser.add_argument(
        '-db', help="Name of the SQL database (e.g. db5 or db10)"
    )
    parser.add_argument(
        '-o', '--output', help="File to write SQL statements to (defaults to stdout)",
        metavar='FILE', default=None
    )
    args = parser.parse_args()

    # Determine output destination
    out = open(args.output, 'w') if args.output else sys.stdout

    # Parse the RDF/XML
    g = rdflib.Graph()
    g.parse(args.input, format='application/rdf+xml')

    dbname = args.dbname

    # Collect all NamedIndividuals
    individuals = set(g.subjects(RDF.type, OWL.NamedIndividual))

    # Maps for classes and properties
    classes = {}	   # class_name -> list of individual names
    properties = {}	# prop_name -> list of (subject_name, object_name)
    class_names = set()	# known classes from TBox
    property_names = set() # known properties from TBox

    # Collect TBox axioms
    for cls in g.subjects(RDF.type, OWL.Class):
        class_names.add(get_local(cls))
    for prop in g.subjects(RDF.type, OWL.ObjectProperty):
        property_names.add(get_local(prop))
    for prop in g.subjects(RDF.type, RDF.Property):
        property_names.add(get_local(prop))

    # Extract from individuals
    for subj in individuals:
        subj_name = get_local(subj)
        for pred, obj in g.predicate_objects(subj):
            if pred == RDF.type:
                # Skip the OWL.NamedIndividual typing
                if obj == OWL.NamedIndividual:
                    continue
                cls_name = get_local(obj)
                class_names.add(cls_name)
                classes.setdefault(cls_name, []).append(subj_name)
            else:
                prop_name = get_local(pred)
                obj_name = get_local(obj)
                property_names.add(prop_name)
                properties.setdefault(prop_name, []).append((subj_name, obj_name))

    # Emit SQL DDL
    print(f"CREATE DATABASE {dbname};", file=out)
    for cls in sorted(class_names):
        print(f"CREATE TABLE {dbname}.{cls}(attr1 VARCHAR(255));", file=out)
    for prop in sorted(property_names):
        print(f"CREATE TABLE {dbname}.{prop}(attr1 VARCHAR(255), attr2 VARCHAR(255));", file=out)
    print(file=out)

    # Emit SQL DML for class membership
    for cls in sorted(classes):
        values = ",\n	".join(f"('{ind}')" for ind in classes[cls])
        print(f"INSERT INTO {dbname}.{cls} VALUES\n	{values};", file=out)
    print(file=out)

    # Emit SQL DML for property assertions
    for prop in sorted(properties):
        values = ",\n	".join(f"('{s}', '{o}')" for s, o in properties[prop])
        print(f"INSERT INTO {dbname}.{prop} VALUES\n	{values};", file=out)

    # Close file if opened
    if args.output:
        out.close()

if __name__ == '__main__':
    main()
